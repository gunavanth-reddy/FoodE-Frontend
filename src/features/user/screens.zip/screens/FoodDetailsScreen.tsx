import React, {useState, useRef} from 'react';
import {
  ActivityIndicator,
  Animated,
  Image,
  Pressable,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from 'react-native';
import {useNavigation, useRoute} from '@react-navigation/native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';
import {
  ArrowLeft,
  Heart,
  Star,
  Clock,
  ForkKnife,
  Plus,
  Minus,
  ShoppingCart,
  CheckCircle,
  Fire,
  Sparkle,
} from 'phosphor-react-native';

import {useCart} from '../../../context/CartContext';
import {useFavorites} from '../../../context/FavoritesContext';
import {Food} from '../../restaurant/services/foodService';

const PRIMARY_ORANGE = '#FF6B00';
const GREEN = '#16A34A';
const RED = '#DC2626';

const SPICE_LEVELS = ['Mild 🌿', 'Medium 🌶️', 'Hot 🔥', 'Extra Hot ⚡'];

const FoodDetailsScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const route = useRoute<any>();
  const insets = useSafeAreaInsets();
  const {width} = useWindowDimensions();

  const food: Food = route.params?.food || {
    _id: 'default',
    name: 'Delicious Dish',
    description: 'Freshly prepared with authentic ingredients.',
    price: 199,
    category: 'Special',
  };

  const {addItem} = useCart();
  const {favoriteFoods, toggleFoodFavorite} = useFavorites();

  const isFavorite = favoriteFoods.some(item => item._id === food._id);

  const [quantity, setQuantity] = useState(1);
  const [selectedSpice, setSelectedSpice] = useState(SPICE_LEVELS[1]);
  const [specialNotes, setSpecialNotes] = useState('');
  const [imageError, setImageError] = useState(false);
  const [addedSuccess, setAddedSuccess] = useState(false);

  const quantityScale = useRef(new Animated.Value(1)).current;
  const buttonScale = useRef(new Animated.Value(1)).current;

  const isVeg =
    food.isVegetarian === true ||
    food.foodType === 'veg' ||
    (food as any).isVeg === true;

  const currentPrice =
    typeof food.discountedPrice === 'number' && food.discountedPrice > 0
      ? food.discountedPrice
      : food.price || 0;

  const originalPrice = food.price || currentPrice;
  const hasDiscount =
    typeof food.discountedPrice === 'number' &&
    food.discountedPrice > 0 &&
    food.discountedPrice < originalPrice;

  const savings = hasDiscount ? originalPrice - currentPrice : 0;
  const totalPrice = currentPrice * quantity;

  const animateQuantity = () => {
    quantityScale.setValue(0.85);
    Animated.spring(quantityScale, {
      toValue: 1,
      friction: 4,
      tension: 60,
      useNativeDriver: true,
    }).start();
  };

  const handleIncrement = () => {
    setQuantity(prev => Math.min(prev + 1, 20));
    animateQuantity();
  };

  const handleDecrement = () => {
    if (quantity > 1) {
      setQuantity(prev => prev - 1);
      animateQuantity();
    }
  };

  const handleAddToCart = async () => {
    try {
      Animated.sequence([
        Animated.timing(buttonScale, {
          toValue: 0.94,
          duration: 90,
          useNativeDriver: true,
        }),
        Animated.spring(buttonScale, {
          toValue: 1,
          friction: 4,
          useNativeDriver: true,
        }),
      ]).start();

      await addItem(food, quantity);
      setAddedSuccess(true);
      setTimeout(() => setAddedSuccess(false), 2400);
    } catch (error) {
      console.log('Failed to add to cart:', error);
    }
  };

  const foodImage =
    (food as any).image ||
    (food as any).imageUrl ||
    (food as any).coverImage ||
    null;

  const restaurantName =
    (food as any).restaurantName ||
    (typeof food.restaurant === 'object' && food.restaurant?.name) ||
    'Campus Kitchen';

  return (
    <View style={styles.screen}>
      <StatusBar hidden={true} />

      {/* Scrollable Body */}
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={[
          styles.scrollContainer,
          {paddingBottom: insets.bottom + 100},
        ]}
        bounces={true}>
        {/* Hero Image Section */}
        <View style={styles.heroContainer}>
          {foodImage && !imageError ? (
            <Image
              source={{uri: foodImage}}
              style={styles.heroImage}
              resizeMode="cover"
              onError={() => setImageError(true)}
            />
          ) : (
            <View style={styles.fallbackHero}>
              <ForkKnife size={64} color="#FFA566" weight="duotone" />
              <Text style={styles.fallbackBrand}>FoodE Specialty</Text>
            </View>
          )}

          {/* Floating Top Nav (Back & Favorite) */}
          <View style={[styles.topControls, {top: insets.top + 12}]}>
            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => navigation.goBack()}
              style={styles.floatingButton}>
              <ArrowLeft size={22} color="#1E232C" weight="bold" />
            </TouchableOpacity>

            <TouchableOpacity
              activeOpacity={0.8}
              onPress={() => toggleFoodFavorite(food)}
              style={styles.floatingButton}>
              <Heart
                size={22}
                color={isFavorite ? PRIMARY_ORANGE : '#1E232C'}
                weight={isFavorite ? 'fill' : 'regular'}
              />
            </TouchableOpacity>
          </View>
        </View>

        {/* Content Card */}
        <View style={styles.mainContent}>
          {/* Header Row: Badges & Tags */}
          <View style={styles.badgesRow}>
            <View
              style={[
                styles.vegIndicator,
                {borderColor: isVeg ? GREEN : RED},
              ]}>
              <View
                style={[
                  styles.vegDot,
                  {backgroundColor: isVeg ? GREEN : RED},
                ]}
              />
            </View>
            <Text style={[styles.vegLabel, {color: isVeg ? GREEN : RED}]}>
              {isVeg ? 'Pure Veg' : 'Non-Veg'}
            </Text>

            {Boolean(food.category) && (
              <View style={styles.categoryBadge}>
                <Sparkle size={12} color={PRIMARY_ORANGE} weight="fill" />
                <Text style={styles.categoryText}>
                  {typeof food.category === 'object' && food.category !== null
                    ? (food.category as any).name || ''
                    : String(food.category || '')}
                </Text>
              </View>
            )}

            {food.rating ? (
              <View style={styles.ratingBadge}>
                <Star size={12} color="#FFFFFF" weight="fill" />
                <Text style={styles.ratingText}>{food.rating.toFixed(1)}</Text>
              </View>
            ) : null}
          </View>

          {/* Dish Title */}
          <Text style={styles.dishName}>{food.name}</Text>

          {/* Restaurant Subtitle */}
          <Text style={styles.restaurantName}>By {restaurantName}</Text>

          {/* Price & Savings Row */}
          <View style={styles.priceRow}>
            <Text style={styles.currentPrice}>₹{currentPrice}</Text>
            {hasDiscount && (
              <Text style={styles.originalPrice}>₹{originalPrice}</Text>
            )}
            {hasDiscount && (
              <View style={styles.discountPill}>
                <Text style={styles.discountText}>Save ₹{savings}</Text>
              </View>
            )}
          </View>

          {/* Quick Metrics (Prep Time, Delivery) */}
          <View style={styles.metricsContainer}>
            <View style={styles.metricItem}>
              <Clock size={18} color={PRIMARY_ORANGE} weight="duotone" />
              <Text style={styles.metricLabel}>Prep Time</Text>
              <Text style={styles.metricValue}>
                {food.preparationTime || 20} mins
              </Text>
            </View>
            <View style={styles.metricDivider} />
            <View style={styles.metricItem}>
              <Fire size={18} color="#EA580C" weight="duotone" />
              <Text style={styles.metricLabel}>Freshness</Text>
              <Text style={styles.metricValue}>100% Cooked to Order</Text>
            </View>
          </View>

          {/* Description */}
          {Boolean(food.description) && (
            <View style={styles.section}>
              <Text style={styles.sectionTitle}>About this dish</Text>
              <Text style={styles.descriptionText}>{food.description}</Text>
            </View>
          )}

          {/* Interactive Spice Level Selection */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Spice Level</Text>
            <View style={styles.spiceRow}>
              {SPICE_LEVELS.map(level => {
                const selected = selectedSpice === level;
                return (
                  <TouchableOpacity
                    key={level}
                    activeOpacity={0.75}
                    onPress={() => setSelectedSpice(level)}
                    style={[
                      styles.spiceChip,
                      selected && styles.spiceChipActive,
                    ]}>
                    <Text
                      style={[
                        styles.spiceText,
                        selected && styles.spiceTextActive,
                      ]}>
                      {level}
                    </Text>
                  </TouchableOpacity>
                );
              })}
            </View>
          </View>

          {/* Quantity Selector */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Select Quantity</Text>
            <View style={styles.quantityContainer}>
              <TouchableOpacity
                activeOpacity={0.75}
                onPress={handleDecrement}
                style={[
                  styles.qtyButton,
                  quantity === 1 && styles.qtyButtonDisabled,
                ]}>
                <Minus
                  size={18}
                  color={quantity === 1 ? '#A0A7B5' : '#1E232C'}
                  weight="bold"
                />
              </TouchableOpacity>

              <Animated.View
                style={[
                  styles.qtyNumberHolder,
                  {transform: [{scale: quantityScale}]},
                ]}>
                <Text style={styles.qtyNumber}>{quantity}</Text>
              </Animated.View>

              <TouchableOpacity
                activeOpacity={0.75}
                onPress={handleIncrement}
                style={styles.qtyButton}>
                <Plus size={18} color="#1E232C" weight="bold" />
              </TouchableOpacity>
            </View>
          </View>

          {/* Kitchen Note / Instructions */}
          <View style={styles.section}>
            <Text style={styles.sectionTitle}>Special Instructions</Text>
            <TextInput
              value={specialNotes}
              onChangeText={setSpecialNotes}
              placeholder="e.g. Less oil, extra napkins, cutlery required..."
              placeholderTextColor="#9CA3AF"
              style={styles.notesInput}
              multiline
              numberOfLines={3}
            />
          </View>
        </View>
      </ScrollView>

      {/* Sticky Bottom Action Dock */}
      <View
        style={[
          styles.bottomDock,
          {paddingBottom: Math.max(insets.bottom, 12)},
        ]}>
        <View style={styles.totalInfo}>
          <Text style={styles.totalLabel}>Total Price</Text>
          <Text style={styles.totalAmount}>₹{totalPrice}</Text>
        </View>

        <Animated.View
          style={[
            styles.addButtonContainer,
            {transform: [{scale: buttonScale}]},
          ]}>
          <TouchableOpacity
            activeOpacity={0.88}
            onPress={handleAddToCart}
            style={[
              styles.addCartButton,
              addedSuccess && styles.addCartSuccess,
            ]}>
            {addedSuccess ? (
              <>
                <CheckCircle size={22} color="#FFFFFF" weight="fill" />
                <Text style={styles.addCartText}>Added to Cart!</Text>
              </>
            ) : (
              <>
                <ShoppingCart size={22} color="#FFFFFF" weight="bold" />
                <Text style={styles.addCartText}>Add to Cart</Text>
              </>
            )}
          </TouchableOpacity>
        </Animated.View>
      </View>
    </View>
  );
};

export default FoodDetailsScreen;

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#F8F9FB',
  },
  scrollContainer: {
    flexGrow: 1,
  },
  heroContainer: {
    width: '100%',
    height: 310,
    position: 'relative',
    backgroundColor: '#1E232C',
  },
  heroImage: {
    width: '100%',
    height: '100%',
  },
  fallbackHero: {
    width: '100%',
    height: '100%',
    backgroundColor: '#262A34',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  fallbackBrand: {
    color: '#FFFFFF',
    fontSize: 18,
    fontWeight: '700',
    letterSpacing: 0.5,
  },
  topControls: {
    position: 'absolute',
    left: 16,
    right: 16,
    flexDirection: 'row',
    justifyContent: 'space-between',
    zIndex: 10,
  },
  floatingButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: 'rgba(255, 255, 255, 0.92)',
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.15,
    shadowRadius: 6,
    elevation: 4,
  },
  mainContent: {
    flex: 1,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 30,
    borderTopRightRadius: 30,
    marginTop: -26,
    paddingHorizontal: 20,
    paddingTop: 24,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: -3},
    shadowOpacity: 0.05,
    shadowRadius: 10,
    elevation: 4,
  },
  badgesRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 10,
  },
  vegIndicator: {
    width: 16,
    height: 16,
    borderWidth: 1.5,
    borderRadius: 4,
    alignItems: 'center',
    justifyContent: 'center',
  },
  vegDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  vegLabel: {
    fontSize: 12,
    fontWeight: '700',
  },
  categoryBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#FFF2E6',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  categoryText: {
    color: PRIMARY_ORANGE,
    fontSize: 11,
    fontWeight: '700',
  },
  ratingBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#16A34A',
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
    marginLeft: 'auto',
  },
  ratingText: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '800',
  },
  dishName: {
    fontSize: 24,
    fontWeight: '800',
    color: '#1A1D26',
    lineHeight: 30,
  },
  restaurantName: {
    fontSize: 13,
    fontWeight: '600',
    color: '#717886',
    marginTop: 4,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginTop: 14,
  },
  currentPrice: {
    fontSize: 26,
    fontWeight: '900',
    color: PRIMARY_ORANGE,
  },
  originalPrice: {
    fontSize: 18,
    fontWeight: '500',
    color: '#9CA3AF',
    textDecorationLine: 'line-through',
  },
  discountPill: {
    backgroundColor: '#DCFCE7',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 6,
  },
  discountText: {
    color: '#15803D',
    fontSize: 11,
    fontWeight: '700',
  },
  metricsContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#F8F9FB',
    borderRadius: 16,
    paddingVertical: 14,
    paddingHorizontal: 16,
    marginTop: 18,
  },
  metricItem: {
    flex: 1,
    alignItems: 'center',
    gap: 3,
  },
  metricLabel: {
    fontSize: 11,
    color: '#717886',
    fontWeight: '600',
  },
  metricValue: {
    fontSize: 13,
    color: '#1A1D26',
    fontWeight: '800',
  },
  metricDivider: {
    width: 1,
    height: 36,
    backgroundColor: '#E5E7EB',
  },
  section: {
    marginTop: 22,
  },
  sectionTitle: {
    fontSize: 15,
    fontWeight: '800',
    color: '#1A1D26',
    marginBottom: 10,
  },
  descriptionText: {
    fontSize: 14,
    lineHeight: 22,
    color: '#555C68',
  },
  spiceRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  spiceChip: {
    paddingHorizontal: 14,
    paddingVertical: 9,
    borderRadius: 12,
    backgroundColor: '#F3F4F6',
    borderWidth: 1,
    borderColor: '#E5E7EB',
  },
  spiceChipActive: {
    backgroundColor: '#FFF2E6',
    borderColor: PRIMARY_ORANGE,
  },
  spiceText: {
    fontSize: 13,
    fontWeight: '600',
    color: '#4B5563',
  },
  spiceTextActive: {
    color: PRIMARY_ORANGE,
    fontWeight: '800',
  },
  quantityContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 16,
  },
  qtyButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#F3F4F6',
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyButtonDisabled: {
    opacity: 0.45,
  },
  qtyNumberHolder: {
    minWidth: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  qtyNumber: {
    fontSize: 20,
    fontWeight: '800',
    color: '#1A1D26',
  },
  notesInput: {
    backgroundColor: '#F9FAFB',
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#E5E7EB',
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 13,
    color: '#1A1D26',
    textAlignVertical: 'top',
    minHeight: 70,
  },
  bottomDock: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 24,
    borderTopRightRadius: 24,
    paddingTop: 14,
    paddingHorizontal: 20,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#000',
    shadowOffset: {width: 0, height: -4},
    shadowOpacity: 0.1,
    shadowRadius: 12,
    elevation: 12,
  },
  totalInfo: {
    justifyContent: 'center',
  },
  totalLabel: {
    fontSize: 11,
    color: '#717886',
    fontWeight: '600',
  },
  totalAmount: {
    fontSize: 22,
    fontWeight: '900',
    color: '#1A1D26',
  },
  addButtonContainer: {
    flex: 1,
    maxWidth: 220,
    marginLeft: 18,
  },
  addCartButton: {
    backgroundColor: PRIMARY_ORANGE,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    height: 52,
    borderRadius: 18,
    shadowColor: PRIMARY_ORANGE,
    shadowOffset: {width: 0, height: 4},
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 6,
  },
  addCartSuccess: {
    backgroundColor: GREEN,
    shadowColor: GREEN,
  },
  addCartText: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '800',
  },
});
