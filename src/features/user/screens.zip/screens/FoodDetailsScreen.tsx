import React from 'react';
import {SafeAreaView, Text, StyleSheet} from 'react-native';

const FoodDetailsScreen = () => {
  return (
    <SafeAreaView style={styles.container}>
      <Text>Food Details Screen</Text>
    </SafeAreaView>
  );
};

export default FoodDetailsScreen;
const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
});
