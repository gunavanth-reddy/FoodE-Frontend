import React from 'react';

import {
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {
  ShieldCheck, Storefront, UsersThree, UserCircle, Receipt, Clock, Star,
  CaretRight, CalendarBlank, TrendUp, Info,
} from 'phosphor-react-native';

interface AdminHeaderProps {
  adminName?: string;
}

const AdminHeader = ({
  adminName = 'Admin',
}: AdminHeaderProps) => {
  return (
    <View style={styles.container}>
      {/* LEFT */}
      <View style={styles.leftSection}>
        <View style={styles.avatar}>
          <Text style={styles.avatarText}>
            A
          </Text>
        </View>

        <View>
          <Text style={styles.greeting}>
            Welcome back
          </Text>

          <Text style={styles.name}>
            {adminName}
          </Text>
        </View>
      </View>

      {/* RIGHT */}
      <View style={styles.adminBadge}>
        <ShieldCheck size={16} color="#FF7A00" weight="bold" />

        <Text style={styles.adminText}>
          ADMIN
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 28,
  },

  leftSection: {
    flexDirection: 'row',
    alignItems: 'center',
  },

  avatar: {
    width: 48,
    height: 48,
    borderRadius: 16,
    backgroundColor: '#FF7A00',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },

  avatarText: {
    fontSize: 20,
    fontWeight: '900',
    color: '#FFFFFF',
  },

  greeting: {
    fontSize: 13,
    color: '#777777',
    marginBottom: 3,
  },

  name: {
    fontSize: 20,
    fontWeight: '900',
    color: '#17171B',
  },

  adminBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 11,
    paddingVertical: 8,
    borderRadius: 12,
    backgroundColor: '#FFF3E8',
  },

  adminIcon: {
    marginRight: 5,
  },

  adminText: {
    fontSize: 10,
    fontWeight: '900',
    color: '#FF7A00',
  },
});

export default AdminHeader;

