const API_BASE_URL = 'https://foode-backend-vn67.onrender.com/api';

export interface AdminDashboardStats {
  totalUsers: number;
  totalRestaurantOwners: number;
  totalRestaurants: number;
  pendingRestaurants: number;
  approvedRestaurants: number;
  activeRestaurants: number;
}

export interface AdminOrderStats {
  orders: {total: number; today: number; active: number; delivered: number; cancelled: number};
  revenue: {today: number; total: number};
}

interface ApiResponse<T> {success?: boolean; stats?: T; message?: string}

const request = async <T>(endpoint: string, token: string, timeout = 12000): Promise<T | null> => {
  if (!token) throw new Error('Authentication token is missing.');
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeout);

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'GET',
      headers: {Accept: 'application/json', Authorization: `Bearer ${token}`},
      signal: controller.signal,
    });

    let data: any = null;
    try { data = await response.json(); } catch { data = null; }

    if (response.status === 401) throw new Error('Session expired. Please login again.');
    if (response.status === 403) throw new Error('You are not authorized to access this admin data.');
    if (!response.ok) throw new Error(data?.message || `Request failed (${response.status}).`);
    return data as T;
  } catch (error: any) {
    if (error?.name === 'AbortError') throw new Error('Request timed out. Please try again.');
    if (String(error?.message || '').includes('Network request failed')) throw new Error('Unable to connect to FoodE server.');
    throw error;
  } finally {
    clearTimeout(timer);
  }
};

export const getAdminDashboardStats = async (token: string): Promise<AdminDashboardStats> => {
  const data = await request<ApiResponse<AdminDashboardStats>>('/admin/dashboard', token);
  if (!data?.success || !data.stats) throw new Error(data?.message || 'Failed to load admin dashboard.');
  return data.stats;
};

export const getAdminOrderStats = async (token: string): Promise<AdminOrderStats> => {
  try {
    const data = await request<ApiResponse<AdminOrderStats>>('/admin/dashboard/orders', token);
    if (!data?.success || !data.stats) {
      throw new Error(data?.message || 'Failed to load order statistics.');
    }
    return data.stats;
  } catch (error: any) {
    // Keep dashboard usable if this optional endpoint has not been deployed.
    if (String(error?.message || '').includes('(404)')) {
      return {orders: {total: 0, today: 0, active: 0, delivered: 0, cancelled: 0}, revenue: {today: 0, total: 0}};
    }
    throw error;
  }
};
