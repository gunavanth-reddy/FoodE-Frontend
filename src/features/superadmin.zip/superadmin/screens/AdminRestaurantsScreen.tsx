import React, {useCallback, useEffect, useState} from 'react';
import {ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {
  ShieldCheck, Storefront, UsersThree, UserCircle, Receipt, Clock, Cash, Star,
  CaretRight, CalendarBlank, TrendUp, Info,
} from 'phosphor-react-native';
import {useAuth} from '../../../context/AuthContext';
import {getRestaurantAnalytics, RestaurantAnalytics} from '../services/adminAnalyticsService';

const money = (n=0) => `₹${Number(n||0).toLocaleString('en-IN')}`;
const AdminRestaurantsScreen = ({navigation}: any) => {
 const {token}=useAuth(); const [items,setItems]=useState<RestaurantAnalytics[]>([]); const [loading,setLoading]=useState(true); const [refreshing,setRefreshing]=useState(false);
 const load=useCallback(async()=>{if(!token)return;try{setItems(await getRestaurantAnalytics(token));}catch(e){console.log(e)}finally{setLoading(false);setRefreshing(false)}},[token]);
 useEffect(()=>{load()},[load]);
 if(loading)return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#FF7A00"/></SafeAreaView>;
 return <SafeAreaView style={styles.container}><ScrollView refreshControl={<RefreshControl refreshing={refreshing} onRefresh={()=>{setRefreshing(true);load()}} tintColor="#FF7A00"/>} contentContainerStyle={styles.content}>
 <Text style={styles.eyebrow}>FOODE ADMIN</Text><Text style={styles.title}>Restaurants</Text><Text style={styles.subtitle}>Performance of every restaurant.</Text>
 {items.map(item=><TouchableOpacity key={item.restaurant.id} style={styles.card} activeOpacity={.85} onPress={()=>navigation.navigate('AdminRestaurantAnalytics',{restaurantId:item.restaurant.id})}><View style={styles.row}><View style={styles.icon}><Storefront size={21} color="#FF7A00" weight="duotone"/></View><View style={{flex:1}}><Text style={styles.name} numberOfLines={1}>{item.restaurant.name}</Text><Text style={styles.owner}>{item.owner.name}</Text></View><CaretRight size={19} color="#A0A4AC" weight="bold"/></View><View style={styles.metrics}><Metric label="Week orders" value={item.thisWeek.orders}/><Metric label="Week revenue" value={money(item.thisWeek.sales)}/><Metric label="Month" value={item.thisMonth.orders}/></View></TouchableOpacity>)}
 {items.length===0&&<View style={styles.empty}><Text style={styles.emptyTitle}>No restaurant analytics</Text><Text style={styles.emptyText}>Restaurant data will appear here when the admin analytics API returns it.</Text></View>}
 </ScrollView></SafeAreaView>;
};
const Metric=({label,value}:any)=><View style={{flex:1}}><Text style={styles.metricValue}>{value}</Text><Text style={styles.metricLabel}>{label}</Text></View>;
export default AdminRestaurantsScreen;
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#F8F8FA'},content:{padding:18,paddingBottom:30},center:{flex:1,alignItems:'center',justifyContent:'center'},eyebrow:{fontSize:9,fontWeight:'900',letterSpacing:1,color:'#FF7A00'},title:{fontSize:29,fontWeight:'900',color:'#17171B',marginTop:3},subtitle:{fontSize:12,color:'#7B8089',marginBottom:17},card:{backgroundColor:'#FFF',borderRadius:20,padding:15,marginBottom:12},row:{flexDirection:'row',alignItems:'center'},icon:{width:44,height:44,borderRadius:14,backgroundColor:'#FFF3E8',alignItems:'center',justifyContent:'center',marginRight:10},name:{fontSize:15,fontWeight:'900',color:'#252831'},owner:{fontSize:11,color:'#8A8F98',marginTop:3},metrics:{flexDirection:'row',gap:8,borderTopWidth:1,borderTopColor:'#F0F1F3',marginTop:13,paddingTop:12},metricValue:{fontSize:13,fontWeight:'900',color:'#FF7A00'},metricLabel:{fontSize:9,color:'#8A8F98',marginTop:3,fontWeight:'700'},empty:{backgroundColor:'#FFF',padding:25,borderRadius:20,alignItems:'center'},emptyTitle:{fontWeight:'900',fontSize:16,color:'#17171B'},emptyText:{textAlign:'center',marginTop:6,color:'#8A8F98',fontSize:12,lineHeight:18}});
