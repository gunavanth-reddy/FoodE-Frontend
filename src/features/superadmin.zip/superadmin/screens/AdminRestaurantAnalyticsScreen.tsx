import React, {useCallback, useEffect, useMemo, useState} from 'react';
import {ActivityIndicator, RefreshControl, ScrollView, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Storefront, Receipt, Cash, TrendUp, Info} from 'phosphor-react-native';
import {useRoute} from '@react-navigation/native';
import {useAuth} from '../../../context/AuthContext';
import {getSingleRestaurantAnalytics, SingleRestaurantAnalytics} from '../services/adminAnalyticsService';

const money = (value: number = 0) => `₹${Number(value || 0).toLocaleString('en-IN')}`;

const AdminRestaurantAnalyticsScreen: React.FC = () => {
  const {token} = useAuth();
  const route = useRoute<any>();
  const restaurantId = route.params?.restaurantId as string;
  const [data, setData] = useState<SingleRestaurantAnalytics | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  const load = useCallback(async (loader = true) => {
    if (!token || !restaurantId) return;
    if (loader) setLoading(true);
    try {
      setData(await getSingleRestaurantAnalytics(token, restaurantId));
    } catch (error) {
      console.log('Restaurant analytics error:', error);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, [restaurantId, token]);

  useEffect(() => {load(true);}, [load]);

  const dailyRows = useMemo(() => {
    const anyData = data as any;
    return Array.isArray(anyData?.days) ? anyData.days : [];
  }, [data]);

  if (loading) return <SafeAreaView style={styles.center}><ActivityIndicator size="large" color="#FF7A00" /><Text style={styles.loading}>Loading restaurant analytics...</Text></SafeAreaView>;

  return (
    <SafeAreaView style={styles.container}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        refreshControl={<RefreshControl refreshing={refreshing} onRefresh={() => {setRefreshing(true); load(false);}} tintColor="#FF7A00" />}
        contentContainerStyle={styles.content}>
        <View style={styles.topRow}>
          <View style={styles.icon}><Storefront size={25} color="#FF7A00" weight="duotone" /></View>
          <View style={styles.nameWrap}><Text style={styles.eyebrow}>RESTAURANT ANALYTICS</Text><Text style={styles.title}>{data?.restaurant?.name || 'Restaurant'}</Text><Text style={styles.owner}>Owner: {data?.owner?.name || '—'}</Text></View>
        </View>

        <View style={styles.kpiGrid}>
          <Kpi label="This Month Orders" value={data?.monthly?.orders || 0} icon="receipt-outline" />
          <Kpi label="This Month Revenue" value={money(data?.monthly?.sales)} icon="cash-outline" />
          <Kpi label="FoodE Earnings" value={money(data?.monthly?.foodEarnings)} icon="trending-up-outline" />
        </View>

        {dailyRows.length > 0 && <>
          <Text style={styles.sectionTitle}>Daily performance</Text>
          <View style={styles.card}>
            {dailyRows.map((day: any, index: number) => (
              <View key={`${day.date || index}`} style={[styles.dayRow, index > 0 && styles.borderTop]}>
                <View style={{flex: 1}}><Text style={styles.day}>{day.date || day.day || 'Day'}</Text><Text style={styles.muted}>{Number(day.orders || 0)} successful orders</Text></View>
                <View style={styles.dayRight}><Text style={styles.dayRevenue}>{money(day.sales || day.revenue || 0)}</Text><Text style={styles.muted}>Revenue</Text></View>
              </View>
            ))}
          </View>
        </>}

        <Text style={styles.sectionTitle}>Weekly performance</Text>
        <View style={styles.card}>
          {(data?.weeks || []).map((week, index) => (
            <View key={`${week.week}-${index}`} style={[styles.dayRow, index > 0 && styles.borderTop]}>
              <View style={{flex: 1}}><Text style={styles.day}>Week {week.week}</Text><Text style={styles.muted}>{week.from} → {week.to}</Text></View>
              <View style={styles.dayRight}><Text style={styles.dayRevenue}>{week.orders} orders</Text><Text style={styles.muted}>{money(week.sales)}</Text></View>
            </View>
          ))}
          {(!data?.weeks || data.weeks.length === 0) && <Text style={styles.empty}>Weekly analytics are not available yet.</Text>}
        </View>

        <View style={styles.note}><Info size={19} color="#FF7A00" weight="bold" /><Text style={styles.noteText}>The daily section uses the backend's daily analytics when available. The frontend is ready for daily, weekly and monthly restaurant metrics.</Text></View>
      </ScrollView>
    </SafeAreaView>
  );
};

const Kpi = ({label, value, icon}: any) => <View style={styles.kpi}><View style={styles.kpiIcon}>{icon === 'receipt-outline' ? <Receipt size={19} color="#FF7A00" weight="duotone" /> : icon === 'cash-outline' ? <Cash size={19} color="#FF7A00" weight="duotone" /> : <TrendUp size={19} color="#FF7A00" weight="duotone" />}</View><Text style={styles.kpiLabel}>{label}</Text><Text style={styles.kpiValue}>{value}</Text></View>;

export default AdminRestaurantAnalyticsScreen;

const styles = StyleSheet.create({
  container: {flex: 1, backgroundColor: '#F8F8FA'}, content: {padding: 18, paddingBottom: 34}, center: {flex: 1, alignItems: 'center', justifyContent: 'center', backgroundColor: '#F8F8FA'}, loading: {marginTop: 10, color: '#6B7280', fontWeight: '700'}, topRow: {flexDirection: 'row', alignItems: 'center', marginBottom: 18}, icon: {width: 56, height: 56, borderRadius: 18, backgroundColor: '#FFF1E5', alignItems: 'center', justifyContent: 'center', marginRight: 12}, nameWrap: {flex: 1}, eyebrow: {fontSize: 9, letterSpacing: 1, fontWeight: '900', color: '#FF7A00'}, title: {fontSize: 25, fontWeight: '900', color: '#17171B', marginTop: 2}, owner: {fontSize: 12, color: '#7B8089', marginTop: 2}, kpiGrid: {flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between'}, kpi: {width: '48%', backgroundColor: '#FFFFFF', borderRadius: 19, padding: 15, marginBottom: 12, minHeight: 130}, kpiIcon: {width: 38, height: 38, borderRadius: 12, backgroundColor: '#FFF3E8', alignItems: 'center', justifyContent: 'center'}, kpiLabel: {fontSize: 11, color: '#7B8089', fontWeight: '700', marginTop: 10}, kpiValue: {fontSize: 19, color: '#17171B', fontWeight: '900', marginTop: 4}, sectionTitle: {fontSize: 18, fontWeight: '900', color: '#17171B', marginTop: 16, marginBottom: 11}, card: {backgroundColor: '#FFFFFF', borderRadius: 20, paddingHorizontal: 15, overflow: 'hidden'}, dayRow: {minHeight: 68, flexDirection: 'row', alignItems: 'center'}, borderTop: {borderTopWidth: 1, borderTopColor: '#F0F1F3'}, day: {fontSize: 13, fontWeight: '900', color: '#252831'}, muted: {fontSize: 11, color: '#8A8F98', marginTop: 3}, dayRight: {alignItems: 'flex-end'}, dayRevenue: {fontSize: 13, fontWeight: '900', color: '#FF7A00'}, empty: {paddingVertical: 24, textAlign: 'center', color: '#8A8F98', fontWeight: '600'}, note: {marginTop: 15, padding: 14, borderRadius: 16, backgroundColor: '#FFF7EF', flexDirection: 'row', gap: 8}, noteText: {flex: 1, fontSize: 11, lineHeight: 17, color: '#7B5B3B', fontWeight: '600'},
});
