import React, {
  useCallback,
  useEffect,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Alert,
  RefreshControl,
  SafeAreaView,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

// =====================================================
// AUTH
// =====================================================

import {useAuth} from '../../../context/AuthContext';

import {
  CurrencyCircleDollar,
  CalendarBlank,
  ChartBar,
  Receipt,
  Lightning,
  CheckCircle,
  Storefront,
  CaretRight,
  SignOut,
} from 'phosphor-react-native';

// =====================================================
// COMPONENTS
// =====================================================

import AdminHeader from '../components/AdminHeader';
import AdminStatCard from '../components/AdminStatCard';
import AdminQuickActions from '../components/AdminQuickActions';

// =====================================================
// EXISTING ADMIN SERVICE
// =====================================================

import {
  getAdminDashboardStats,
  getAdminOrderStats,
  AdminDashboardStats,
  AdminOrderStats,
} from '../services/adminService';

// =====================================================
// ANALYTICS SERVICE
// =====================================================

import {
  getAdminOverview,
  getRestaurantAnalytics,
  AdminOverview,
  RestaurantAnalytics,
} from '../services/adminAnalyticsService';

// =====================================================
// SCREEN
// =====================================================

const AdminDashboardScreen = ({
  navigation,
}: any) => {
  const {
    token,
    logout,
  } = useAuth();

  // ===================================================
  // EXISTING DASHBOARD STATE
  // ===================================================

  const [
    dashboardStats,
    setDashboardStats,
  ] = useState<AdminDashboardStats | null>(
    null,
  );

  const [
    orderStats,
    setOrderStats,
  ] = useState<AdminOrderStats | null>(
    null,
  );

  // ===================================================
  // ANALYTICS STATE
  // ===================================================

  const [
    analyticsOverview,
    setAnalyticsOverview,
  ] = useState<AdminOverview | null>(
    null,
  );

  const [
    restaurantAnalytics,
    setRestaurantAnalytics,
  ] = useState<RestaurantAnalytics[]>(
    [],
  );

  // ===================================================
  // LOADING
  // ===================================================

  const [
    loading,
    setLoading,
  ] = useState(true);

  const [
    refreshing,
    setRefreshing,
  ] = useState(false);

  const [
    loggingOut,
    setLoggingOut,
  ] = useState(false);

  // ===================================================
  // FORMAT CURRENCY
  // ===================================================

  const formatCurrency = (
    value: number = 0,
  ) => {
    return `₹${Number(value || 0).toLocaleString(
      'en-IN',
    )}`;
  };

  // ===================================================
  // LOAD DASHBOARD
  // ===================================================

  const loadDashboard = useCallback(
    async (
      showLoader = true,
    ) => {
      if (!token) {
        setLoading(false);
        return;
      }

      try {
        if (showLoader) {
          setLoading(true);
        }

        // ==========================================
        // LOAD EVERYTHING TOGETHER
        // ==========================================

        const results = await Promise.allSettled([
          getAdminDashboardStats(token),
          getAdminOrderStats(token),
          getAdminOverview(token),
          getRestaurantAnalytics(token),
        ]);

        const [dashboardResult, ordersResult, analyticsResult, restaurantsResult] = results;

        if (dashboardResult.status === 'fulfilled') {
          setDashboardStats(dashboardResult.value);
        }

        if (ordersResult.status === 'fulfilled') {
          setOrderStats(ordersResult.value);
        }

        if (analyticsResult.status === 'fulfilled') {
          setAnalyticsOverview(analyticsResult.value);
        }

        if (restaurantsResult.status === 'fulfilled') {
          setRestaurantAnalytics(restaurantsResult.value);
        }

        const failures = results.filter(result => result.status === 'rejected');
        if (failures.length > 0) {
          console.log('Some admin dashboard endpoints are unavailable:', failures);
        }
      } catch (error: any) {
        console.log(
          'Admin Dashboard Error:',
          error,
        );

        Alert.alert(
          'Dashboard Error',
          error?.message ||
            'Failed to load admin dashboard.',
        );
      } finally {
        if (showLoader) {
          setLoading(false);
        }
      }
    },
    [token],
  );

  // ===================================================
  // INITIAL LOAD
  // ===================================================

  useEffect(() => {
    loadDashboard(true);
  }, [loadDashboard]);

  // ===================================================
  // REFRESH
  // ===================================================

  const handleRefresh = async () => {
    try {
      setRefreshing(true);

      await loadDashboard(false);
    } finally {
      setRefreshing(false);
    }
  };

  // ===================================================
  // LOGOUT
  // ===================================================

  const handleLogout = () => {
    if (loggingOut) {
      return;
    }

    Alert.alert(
      'Logout',
      'Are you sure you want to logout?',
      [
        {
          text: 'Cancel',
          style: 'cancel',
        },

        {
          text: 'Logout',
          style: 'destructive',

          onPress: async () => {
            try {
              setLoggingOut(true);

              await logout();

              navigation.reset({
                index: 0,

                routes: [
                  {
                    name: 'Login',
                  },
                ],
              });
            } catch (error) {
              console.log(
                'Admin Logout Error:',
                error,
              );

              setLoggingOut(false);

              Alert.alert(
                'Logout Failed',
                'Something went wrong while logging out.',
              );
            }
          },
        },
      ],
    );
  };

  // ===================================================
  // QUICK ACTIONS
  // ===================================================

  const handleUsersPress = () => {
    navigation.navigate(
      'AdminUsers',
    );
  };

  const handleRestaurantsPress = () => {
    navigation.navigate(
      'AdminRestaurants',
    );
  };

  const handleOrdersPress = () => {
    navigation.navigate(
      'AdminOrders',
    );
  };

  const handleReviewsPress = () => {
    navigation.navigate(
      'AdminReviews',
    );
  };

  // ===================================================
  // RESTAURANT ANALYTICS
  // ===================================================

  const handleRestaurantAnalyticsPress = (
    restaurantId: string,
  ) => {
    navigation.navigate(
      'AdminRestaurantAnalytics',
      {
        restaurantId,
      },
    );
  };

  // ===================================================
  // LOADING
  // ===================================================

  if (loading) {
    return (
      <SafeAreaView
        style={
          styles.loadingContainer
        }>
        <StatusBar
          barStyle="dark-content"
          backgroundColor="#F8F8FA"
        />

        <ActivityIndicator
          size="large"
          color="#FF7A00"
        />

        <Text
          style={
            styles.loadingText
          }>
          Loading admin dashboard...
        </Text>
      </SafeAreaView>
    );
  }

  // ===================================================
  // MAIN
  // ===================================================

  return (
    <SafeAreaView
      style={styles.container}>

      <StatusBar
        barStyle="dark-content"
        backgroundColor="#F8F8FA"
      />

      <ScrollView
        showsVerticalScrollIndicator={
          false
        }
        refreshControl={
          <RefreshControl
            refreshing={
              refreshing
            }
            onRefresh={
              handleRefresh
            }
            tintColor="#FF7A00"
          />
        }
        contentContainerStyle={
          styles.content
        }>

        {/* =========================================
            HEADER
        ========================================= */}

        <AdminHeader
          adminName="Admin"
        />

        {/* =========================================
            OVERVIEW
        ========================================= */}

        <Text
          style={
            styles.sectionTitle
          }>
          Overview
        </Text>

        <View
          style={
            styles.statsGrid
          }>

          <AdminStatCard
            icon="people-outline"
            title="Users"
            value={
              dashboardStats
                ?.totalUsers || 0
            }
            subtitle="Registered users"
          />

          <AdminStatCard
            icon="person-outline"
            title="Owners"
            value={
              dashboardStats
                ?.totalRestaurantOwners ||
              0
            }
            subtitle="Restaurant owners"
          />

          <AdminStatCard
            icon="restaurant-outline"
            title="Restaurants"
            value={
              dashboardStats
                ?.totalRestaurants ||
              0
            }
            subtitle="Total restaurants"
          />

          <AdminStatCard
            icon="time-outline"
            title="Pending"
            value={
              dashboardStats
                ?.pendingRestaurants ||
              0
            }
            subtitle="Awaiting approval"
          />

          <AdminStatCard
            icon="receipt-outline"
            title="Orders"
            value={
              orderStats
                ?.orders.total ||
              0
            }
            subtitle="All orders"
          />

          <AdminStatCard
            icon="cash-outline"
            title="Revenue"
            value={formatCurrency(
              orderStats
                ?.revenue.total ||
                0,
            )}
            subtitle="Total revenue"
          />

        </View>

        {/* =========================================
            FOODE REVENUE ANALYTICS
        ========================================= */}

        <Text
          style={
            styles.sectionTitle
          }>
          FoodE Revenue Analytics
        </Text>

        {/* =========================================
            ALL TIME
        ========================================= */}

        <View
          style={
            styles.analyticsCard
          }>

          <View
            style={
              styles.analyticsHeader
            }>

            <View>
              <Text
                style={
                  styles.analyticsTitle
                }>
                All Time
              </Text>

              <Text
                style={
                  styles.analyticsSubtitle
                }>
                Delivered orders
              </Text>
            </View>

            <CurrencyCircleDollar
              size={27}
              color="#FF7A00"
            />

          </View>

          <View
            style={
              styles.analyticsRow
            }>

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.analyticsValue
                }>
                {
                  analyticsOverview
                    ?.overview
                    ?.allTime
                    ?.orders ||
                  0
                }
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                Orders
              </Text>
            </View>

            <View
              style={
                styles.analyticsVerticalDivider
              }
            />

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.analyticsValue
                }>
                {formatCurrency(
                  analyticsOverview
                    ?.overview
                    ?.allTime
                    ?.sales ||
                  0,
                )}
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                Restaurant Sales
              </Text>
            </View>

            <View
              style={
                styles.analyticsVerticalDivider
              }
            />

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.commissionValue
                }>
                {formatCurrency(
                  analyticsOverview
                    ?.overview
                    ?.allTime
                    ?.foodEarnings ||
                  0,
                )}
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                FoodE Earnings
              </Text>
            </View>

          </View>
        </View>

        {/* =========================================
            THIS WEEK
        ========================================= */}

        <View
          style={
            styles.analyticsCard
          }>

          <View
            style={
              styles.analyticsHeader
            }>

            <View>
              <Text
                style={
                  styles.analyticsTitle
                }>
                This Week
              </Text>

              <Text
                style={
                  styles.analyticsSubtitle
                }>
                Monday - Sunday
              </Text>
            </View>

            <CalendarBlank
              size={27}
              color="#FF7A00"
            />

          </View>

          <View
            style={
              styles.analyticsRow
            }>

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.analyticsValue
                }>
                {
                  analyticsOverview
                    ?.overview
                    ?.thisWeek
                    ?.orders ||
                  0
                }
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                Orders
              </Text>
            </View>

            <View
              style={
                styles.analyticsVerticalDivider
              }
            />

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.analyticsValue
                }>
                {formatCurrency(
                  analyticsOverview
                    ?.overview
                    ?.thisWeek
                    ?.sales ||
                  0,
                )}
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                Sales
              </Text>
            </View>

            <View
              style={
                styles.analyticsVerticalDivider
              }
            />

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.commissionValue
                }>
                {formatCurrency(
                  analyticsOverview
                    ?.overview
                    ?.thisWeek
                    ?.foodEarnings ||
                  0,
                )}
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                FoodE Earnings
              </Text>
            </View>

          </View>
        </View>

        {/* =========================================
            THIS MONTH
        ========================================= */}

        <View
          style={
            styles.analyticsCard
          }>

          <View
            style={
              styles.analyticsHeader
            }>

            <View>
              <Text
                style={
                  styles.analyticsTitle
                }>
                This Month
              </Text>

              <Text
                style={
                  styles.analyticsSubtitle
                }>
                Current month
              </Text>
            </View>

            <ChartBar
              size={27}
              color="#FF7A00"
            />

          </View>

          <View
            style={
              styles.analyticsRow
            }>

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.analyticsValue
                }>
                {
                  analyticsOverview
                    ?.overview
                    ?.thisMonth
                    ?.orders ||
                  0
                }
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                Orders
              </Text>
            </View>

            <View
              style={
                styles.analyticsVerticalDivider
              }
            />

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.analyticsValue
                }>
                {formatCurrency(
                  analyticsOverview
                    ?.overview
                    ?.thisMonth
                    ?.sales ||
                  0,
                )}
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                Sales
              </Text>
            </View>

            <View
              style={
                styles.analyticsVerticalDivider
              }
            />

            <View
              style={
                styles.analyticsStat
              }>
              <Text
                style={
                  styles.commissionValue
                }>
                {formatCurrency(
                  analyticsOverview
                    ?.overview
                    ?.thisMonth
                    ?.foodEarnings ||
                  0,
                )}
              </Text>

              <Text
                style={
                  styles.analyticsLabel
                }>
                FoodE Earnings
              </Text>
            </View>

          </View>
        </View>

        {/* =========================================
            COMMISSION INFO
        ========================================= */}

        <View
          style={
            styles.commissionCard
          }>

          <View
            style={
              styles.commissionIconContainer
            }>
            <Receipt
              size={25}
              color="#C2410C"
            />
          </View>

          <View
            style={
              styles.commissionInfo
            }>

            <Text
              style={
                styles.commissionTitle
              }>
              FoodE Commission
            </Text>

            <Text
              style={
                styles.commissionDescription
              }>
              FoodE earns{' '}
              <Text
                style={
                  styles.commissionBold
                }>
                ₹
                {
                  analyticsOverview
                    ?.commissionPerOrder ||
                  10
                }
              </Text>{' '}
              from every delivered order.
            </Text>

          </View>

        </View>

        {/* =========================================
            ORDER OVERVIEW
        ========================================= */}

        <Text
          style={
            styles.sectionTitle
          }>
          Order Overview
        </Text>

        <View
          style={
            styles.orderCard
          }>

          {/* TODAY */}

          <View
            style={
              styles.orderRow
            }>

            <View>
              <Text
                style={
                  styles.orderLabel
                }>
                Today's Orders
              </Text>

              <Text
                style={
                  styles.orderValue
                }>
                {
                  orderStats
                    ?.orders.today ||
                  0
                }
              </Text>
            </View>

            <CalendarBlank
              size={25}
              color="#FF7A00"
            />

          </View>

          <View
            style={
              styles.divider
            }
          />

          {/* ACTIVE */}

          <View
            style={
              styles.orderRow
            }>

            <View>
              <Text
                style={
                  styles.orderLabel
                }>
                Active Orders
              </Text>

              <Text
                style={
                  styles.orderValue
                }>
                {
                  orderStats
                    ?.orders.active ||
                  0
                }
              </Text>
            </View>

            <Lightning
              size={25}
              color="#FF7A00"
            />

          </View>

          <View
            style={
              styles.divider
            }
          />

          {/* DELIVERED */}

          <View
            style={
              styles.orderRow
            }>

            <View>
              <Text
                style={
                  styles.orderLabel
                }>
                Delivered
              </Text>

              <Text
                style={
                  styles.orderValue
                }>
                {
                  orderStats
                    ?.orders.delivered ||
                  0
                }
              </Text>
            </View>

            <CheckCircle
              size={25}
              color="#16A34A"
            />

          </View>

        </View>

        {/* =========================================
            RESTAURANT OVERVIEW
        ========================================= */}

        <Text
          style={
            styles.sectionTitle
          }>
          Restaurant Overview
        </Text>

        <View
          style={
            styles.restaurantCard
          }>

          <View
            style={
              styles.restaurantStat
            }>

            <Text
              style={
                styles.restaurantValue
              }>
              {
                dashboardStats
                  ?.pendingRestaurants ||
                0
              }
            </Text>

            <Text
              style={
                styles.restaurantLabel
              }>
              Pending
            </Text>

          </View>

          <View
            style={
              styles.verticalDivider
            }
          />

          <View
            style={
              styles.restaurantStat
            }>

            <Text
              style={
                styles.restaurantValue
              }>
              {
                dashboardStats
                  ?.approvedRestaurants ||
                0
              }
            </Text>

            <Text
              style={
                styles.restaurantLabel
              }>
              Approved
            </Text>

          </View>

          <View
            style={
              styles.verticalDivider
            }
          />

          <View
            style={
              styles.restaurantStat
            }>

            <Text
              style={
                styles.restaurantValue
              }>
              {
                dashboardStats
                  ?.activeRestaurants ||
                0
              }
            </Text>

            <Text
              style={
                styles.restaurantLabel
              }>
              Active
            </Text>

          </View>

        </View>

        {/* =========================================
            RESTAURANT PERFORMANCE
        ========================================= */}

        <View
          style={
            styles.restaurantAnalyticsHeader
          }>

          <View>
            <Text
              style={
                styles.sectionTitleNoMargin
              }>
              Restaurant Performance
            </Text>

            <Text
              style={
                styles.sectionSubtitle
              }>
              Revenue and FoodE earnings
            </Text>
          </View>

          <Text
            style={
              styles.restaurantCount
            }>
            {
              restaurantAnalytics.length
            }
          </Text>

        </View>

        {restaurantAnalytics.length ===
        0 ? (
          <View
            style={
              styles.emptyCard
            }>
            <Storefront
              size={34}
              color="#FF7A00"
              style={styles.emptyIcon}
            />

            <Text
              style={
                styles.emptyTitle
              }>
              No restaurant data
            </Text>

            <Text
              style={
                styles.emptyText
              }>
              Restaurant analytics will
              appear here.
            </Text>
          </View>
        ) : (
          restaurantAnalytics.map(
            restaurant => {

              const weekly =
                restaurant
                  ?.thisWeek;

              const monthly =
                restaurant
                  ?.thisMonth;

              return (
                <TouchableOpacity
                  key={
                    restaurant
                      .restaurant
                      .id
                  }
                  activeOpacity={0.85}
                  onPress={() =>
                    handleRestaurantAnalyticsPress(
                      restaurant
                        .restaurant
                        .id,
                    )
                  }
                  style={
                    styles.restaurantAnalyticsCard
                  }>

                  {/* HEADER */}

                  <View
                    style={
                      styles.restaurantAnalyticsTop
                    }>

                    <View
                      style={
                        styles.restaurantLogoPlaceholder
                      }>
                      <Storefront
                        size={24}
                        color="#FF7A00"
                      />
                    </View>

                    <View
                      style={
                        styles.restaurantNameContainer
                      }>

                      <Text
                        numberOfLines={
                          1
                        }
                        style={
                          styles.restaurantAnalyticsName
                        }>
                        {
                          restaurant
                            .restaurant
                            .name
                        }
                      </Text>

                      <Text
                        numberOfLines={
                          1
                        }
                        style={
                          styles.ownerName
                        }>
                        Owner:{' '}
                        {
                          restaurant
                            .owner
                            .name
                        }
                      </Text>

                    </View>

                    <CaretRight
                      size={22}
                      color="#AAAAAA"
                    />

                  </View>

                  <View
                    style={
                      styles.divider
                    }
                  />

                  {/* WEEK */}

                  <Text
                    style={
                      styles.analyticsPeriodTitle
                    }>
                    This Week
                  </Text>

                  <View
                    style={
                      styles.restaurantMetricsRow
                    }>

                    <View
                      style={
                        styles.restaurantMetric
                      }>

                      <Text
                        style={
                          styles.metricValue
                        }>
                        {
                          weekly
                            ?.orders ||
                          0
                        }
                      </Text>

                      <Text
                        style={
                          styles.metricLabel
                        }>
                        Orders
                      </Text>

                    </View>

                    <View
                      style={
                        styles.metricDivider
                      }
                    />

                    <View
                      style={
                        styles.restaurantMetric
                      }>

                      <Text
                        style={
                          styles.metricValue
                        }>
                        {formatCurrency(
                          weekly
                            ?.sales ||
                          0,
                        )}
                      </Text>

                      <Text
                        style={
                          styles.metricLabel
                        }>
                        Sales
                      </Text>

                    </View>

                    <View
                      style={
                        styles.metricDivider
                      }
                    />

                    <View
                      style={
                        styles.restaurantMetric
                      }>

                      <Text
                        style={
                          styles.metricCommission
                        }>
                        {formatCurrency(
                          weekly
                            ?.foodEarnings ||
                          0,
                        )}
                      </Text>

                      <Text
                        style={
                          styles.metricLabel
                        }>
                        FoodE
                      </Text>

                    </View>

                  </View>

                  {/* MONTH */}

                  <View
                    style={
                      styles.monthRow
                    }>

                    <Text
                      style={
                        styles.monthLabel
                      }>
                      This Month
                    </Text>

                    <View
                      style={
                        styles.monthValues
                      }>

                      <Text
                        style={
                          styles.monthValue
                        }>
                        {
                          monthly
                            ?.orders ||
                          0
                        }{' '}
                        orders
                      </Text>

                      <Text
                        style={
                          styles.monthDot
                        }>
                        •
                      </Text>

                      <Text
                        style={
                          styles.monthValue
                        }>
                        {formatCurrency(
                          monthly
                            ?.sales ||
                          0,
                        )}
                      </Text>

                      <Text
                        style={
                          styles.monthDot
                        }>
                        •
                      </Text>

                      <Text
                        style={
                          styles.monthCommission
                        }>
                        {formatCurrency(
                          monthly
                            ?.foodEarnings ||
                          0,
                        )}
                      </Text>

                    </View>

                  </View>

                </TouchableOpacity>
              );
            },
          )
        )}

        {/* =========================================
            QUICK ACTIONS
        ========================================= */}

        <AdminQuickActions
          onUsersPress={
            handleUsersPress
          }
          onRestaurantsPress={
            handleRestaurantsPress
          }
          onOrdersPress={
            handleOrdersPress
          }
          onReviewsPress={
            handleReviewsPress
          }
        />

        {/* =========================================
            LOGOUT
        ========================================= */}

        <TouchableOpacity
          activeOpacity={0.85}
          onPress={
            handleLogout
          }
          disabled={
            loggingOut
          }
          style={
            styles.logoutButton
          }>

          {loggingOut ? (
            <ActivityIndicator
              size="small"
              color="#DC2626"
            />
          ) : (
            <>
              <SignOut
                size={20}
                color="#DC2626"
                style={styles.logoutIcon}
              />

              <Text
                style={
                  styles.logoutText
                }>
                Logout
              </Text>
            </>
          )}

        </TouchableOpacity>

        <View
          style={
            styles.bottomSpace
          }
        />

      </ScrollView>
    </SafeAreaView>
  );
};

// =====================================================
// STYLES
// =====================================================

const styles =
  StyleSheet.create({

    container: {
      flex: 1,
      backgroundColor:
        '#F8F8FA',
    },

    content: {
      paddingHorizontal: 20,
      paddingTop: 24,
      paddingBottom: 40,
    },

    // =================================================
    // LOADING
    // =================================================

    loadingContainer: {
      flex: 1,
      backgroundColor:
        '#F8F8FA',
      alignItems: 'center',
      justifyContent:
        'center',
    },

    loadingText: {
      marginTop: 12,
      fontSize: 14,
      color: '#777777',
    },

    // =================================================
    // SECTION
    // =================================================

    sectionTitle: {
      fontSize: 19,
      fontWeight: '900',
      color: '#17171B',
      marginBottom: 14,
      marginTop: 4,
    },

    sectionTitleNoMargin: {
      fontSize: 19,
      fontWeight: '900',
      color: '#17171B',
    },

    sectionSubtitle: {
      fontSize: 12,
      color: '#777777',
      marginTop: 4,
    },

    // =================================================
    // STATS
    // =================================================

    statsGrid: {
      flexDirection: 'row',
      flexWrap: 'wrap',
      justifyContent:
        'space-between',
      marginBottom: 18,
    },

    // =================================================
    // ANALYTICS
    // =================================================

    analyticsCard: {
      backgroundColor:
        '#FFFFFF',
      borderRadius: 20,
      padding: 18,
      marginBottom: 14,
      elevation: 2,
    },

    analyticsHeader: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:
        'space-between',
      marginBottom: 18,
    },

    analyticsTitle: {
      fontSize: 17,
      fontWeight: '900',
      color: '#17171B',
    },

    analyticsSubtitle: {
      fontSize: 12,
      color: '#888888',
      marginTop: 3,
    },

    analyticsRow: {
      flexDirection: 'row',
      alignItems: 'center',
    },

    analyticsStat: {
      flex: 1,
      alignItems: 'center',
    },

    analyticsValue: {
      fontSize: 17,
      fontWeight: '900',
      color: '#17171B',
      textAlign: 'center',
    },

    commissionValue: {
      fontSize: 17,
      fontWeight: '900',
      color: '#FF7A00',
      textAlign: 'center',
    },

    analyticsLabel: {
      fontSize: 10,
      color: '#777777',
      marginTop: 5,
      textAlign: 'center',
    },

    analyticsVerticalDivider: {
      width: 1,
      height: 38,
      backgroundColor:
        '#EEEEEE',
    },

    // =================================================
    // COMMISSION
    // =================================================

    commissionCard: {
      backgroundColor:
        '#FFF7ED',
      borderRadius: 20,
      padding: 17,
      marginBottom: 24,
      flexDirection: 'row',
      alignItems: 'center',
      borderWidth: 1,
      borderColor:
        '#FED7AA',
    },

    commissionIconContainer: {
      width: 48,
      height: 48,
      borderRadius: 15,
      backgroundColor:
        '#FFEDD5',
      alignItems: 'center',
      justifyContent:
        'center',
      marginRight: 13,
    },

    commissionInfo: {
      flex: 1,
    },

    commissionTitle: {
      fontSize: 15,
      fontWeight: '900',
      color: '#9A3412',
    },

    commissionDescription: {
      fontSize: 12,
      color: '#9A3412',
      marginTop: 4,
      lineHeight: 18,
    },

    commissionBold: {
      fontWeight: '900',
    },

    // =================================================
    // ORDERS
    // =================================================

    orderCard: {
      backgroundColor:
        '#FFFFFF',
      borderRadius: 20,
      paddingHorizontal: 18,
      marginBottom: 24,
      elevation: 2,
    },

    orderRow: {
      minHeight: 76,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:
        'space-between',
    },

    orderLabel: {
      fontSize: 13,
      color: '#777777',
      marginBottom: 4,
    },

    orderValue: {
      fontSize: 22,
      fontWeight: '900',
      color: '#17171B',
    },

    divider: {
      height: 1,
      backgroundColor:
        '#F0F0F0',
    },

    // =================================================
    // RESTAURANTS
    // =================================================

    restaurantCard: {
      backgroundColor:
        '#FFFFFF',
      borderRadius: 20,
      paddingVertical: 20,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:
        'space-around',
      marginBottom: 24,
      elevation: 2,
    },

    restaurantStat: {
      flex: 1,
      alignItems: 'center',
    },

    restaurantValue: {
      fontSize: 23,
      fontWeight: '900',
      color: '#17171B',
    },

    restaurantLabel: {
      fontSize: 12,
      color: '#777777',
      marginTop: 4,
    },

    verticalDivider: {
      width: 1,
      height: 42,
      backgroundColor:
        '#EEEEEE',
    },

    // =================================================
    // RESTAURANT PERFORMANCE
    // =================================================

    restaurantAnalyticsHeader: {
      flexDirection: 'row',
      alignItems: 'flex-end',
      justifyContent:
        'space-between',
      marginBottom: 14,
      marginTop: 2,
    },

    restaurantCount: {
      minWidth: 30,
      height: 30,
      borderRadius: 15,
      backgroundColor:
        '#FFF0E6',
      color: '#FF7A00',
      fontSize: 13,
      fontWeight: '900',
      textAlign: 'center',
      textAlignVertical: 'center',
      paddingTop: 6,
    },

    restaurantAnalyticsCard: {
      backgroundColor:
        '#FFFFFF',
      borderRadius: 20,
      padding: 17,
      marginBottom: 14,
      elevation: 2,
    },

    restaurantAnalyticsTop: {
      flexDirection: 'row',
      alignItems: 'center',
    },

    restaurantLogoPlaceholder: {
      width: 48,
      height: 48,
      borderRadius: 15,
      backgroundColor:
        '#FFF3E8',
      alignItems: 'center',
      justifyContent:
        'center',
    },

    restaurantLogoText: {
      fontSize: 23,
    },

    restaurantNameContainer: {
      flex: 1,
      marginLeft: 12,
      marginRight: 8,
    },

    restaurantAnalyticsName: {
      fontSize: 16,
      fontWeight: '900',
      color: '#17171B',
    },

    ownerName: {
      fontSize: 11,
      color: '#777777',
      marginTop: 4,
    },

    arrow: {
      fontSize: 30,
      color: '#AAAAAA',
      fontWeight: '300',
    },

    analyticsPeriodTitle: {
      fontSize: 12,
      fontWeight: '800',
      color: '#777777',
      marginTop: 14,
      marginBottom: 10,
    },

    restaurantMetricsRow: {
      flexDirection: 'row',
      alignItems: 'center',
      backgroundColor:
        '#FAFAFA',
      borderRadius: 14,
      paddingVertical: 13,
    },

    restaurantMetric: {
      flex: 1,
      alignItems: 'center',
    },

    metricValue: {
      fontSize: 14,
      fontWeight: '900',
      color: '#17171B',
      textAlign: 'center',
    },

    metricCommission: {
      fontSize: 14,
      fontWeight: '900',
      color: '#FF7A00',
      textAlign: 'center',
    },

    metricLabel: {
      fontSize: 10,
      color: '#888888',
      marginTop: 4,
    },

    metricDivider: {
      width: 1,
      height: 30,
      backgroundColor:
        '#E5E5E5',
    },

    monthRow: {
      marginTop: 13,
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:
        'space-between',
    },

    monthLabel: {
      fontSize: 11,
      fontWeight: '800',
      color: '#777777',
    },

    monthValues: {
      flexDirection: 'row',
      alignItems: 'center',
      flexShrink: 1,
    },

    monthValue: {
      fontSize: 11,
      fontWeight: '700',
      color: '#444444',
    },

    monthCommission: {
      fontSize: 11,
      fontWeight: '800',
      color: '#FF7A00',
    },

    monthDot: {
      fontSize: 12,
      color: '#BBBBBB',
      marginHorizontal: 5,
    },

    // =================================================
    // EMPTY
    // =================================================

    emptyCard: {
      backgroundColor:
        '#FFFFFF',
      borderRadius: 20,
      paddingVertical: 30,
      paddingHorizontal: 20,
      alignItems: 'center',
      marginBottom: 24,
      elevation: 2,
    },

    emptyIcon: {
      fontSize: 32,
      marginBottom: 8,
    },

    emptyTitle: {
      fontSize: 15,
      fontWeight: '900',
      color: '#17171B',
    },

    emptyText: {
      fontSize: 12,
      color: '#888888',
      marginTop: 5,
    },

    // =================================================
    // LOGOUT
    // =================================================

    logoutButton: {
      height: 54,
      borderRadius: 17,
      backgroundColor:
        '#FFF1F2',
      borderWidth: 1,
      borderColor:
        '#FECACA',
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent:
        'center',
      marginTop: 12,
    },

    logoutIcon: {
      fontSize: 18,
      marginRight: 8,
    },

    logoutText: {
      fontSize: 16,
      fontWeight: '800',
      color: '#DC2626',
    },

    bottomSpace: {
      height: 30,
    },

  });

export default AdminDashboardScreen;
