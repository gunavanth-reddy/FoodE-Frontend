import React from 'react';
import {StyleSheet,Text,View} from 'react-native';
import {SafeAreaView} from 'react-native-safe-area-context';
import {Star} from 'phosphor-react-native';
const AdminReviewsScreen=()=> <SafeAreaView style={styles.container}><View style={styles.card}><View style={styles.icon}><Star size={28} color="#FF7A00" weight="duotone"/></View><Text style={styles.title}>Reviews overview</Text><Text style={styles.text}>The restaurant analytics foundation is ready. Review-level analytics can be connected here when the admin reviews endpoint is exposed by the backend.</Text></View></SafeAreaView>;
export default AdminReviewsScreen;
const styles=StyleSheet.create({container:{flex:1,backgroundColor:'#F8F8FA',alignItems:'center',justifyContent:'center',padding:22},card:{width:'100%',backgroundColor:'#FFF',borderRadius:24,padding:25,alignItems:'center'},icon:{width:58,height:58,borderRadius:19,backgroundColor:'#FFF3E8',alignItems:'center',justifyContent:'center'},title:{fontSize:21,fontWeight:'900',color:'#17171B',marginTop:15},text:{fontSize:13,lineHeight:20,color:'#7B8089',textAlign:'center',marginTop:8}});
