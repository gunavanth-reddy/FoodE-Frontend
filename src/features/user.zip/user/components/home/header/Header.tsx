import React from 'react';
import {StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {MapPin, UserCircle, ShoppingBagOpen} from 'phosphor-react-native';
import {useNavigation, CompositeNavigationProp} from '@react-navigation/native';
import {BottomTabNavigationProp} from '@react-navigation/bottom-tabs';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';
import NotificationButton from './NotificationButton';
import {useCart} from '../../../../../context/CartContext';
import {BottomTabParamList} from '../../../../../navigation/BottomTabNavigator';
import {RootStackParamList} from '../../../../../navigation/AppNavigator';

type HeaderNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<BottomTabParamList>,
  NativeStackNavigationProp<RootStackParamList>
>;

const Header: React.FC = () => {
  const navigation = useNavigation<HeaderNavigationProp>();
  const {items = []} = useCart();
  const cartCount = items.reduce((sum: number, item: any) => sum + Number(item.quantity || 0), 0);

  return (
    <View style={styles.header}>
        <View style={styles.locationSection}>
          <View style={styles.locationIcon}>
            <MapPin size={20} color="#FF7A00" weight="fill" />
          </View>
          <View style={styles.locationText}>
            <Text style={styles.eyebrow}>DELIVERING TO</Text>
            <Text style={styles.locationName} numberOfLines={1} adjustsFontSizeToFit>
              SRM AP University
            </Text>
            <Text style={styles.locationArea} numberOfLines={1}>Neerukonda</Text>
          </View>
        </View>

        <View style={styles.actions}>
          <TouchableOpacity
            activeOpacity={0.82}
            style={styles.actionButton}
            onPress={() => navigation.navigate('Cart')}>
            <ShoppingBagOpen size={22} color="#172033" weight="duotone" />
            {cartCount > 0 && (
              <View style={styles.cartBadge}>
                <Text style={styles.cartBadgeText}>
                  {cartCount > 99 ? '99+' : cartCount}
                </Text>
              </View>
            )}
          </TouchableOpacity>

          <NotificationButton />

          <TouchableOpacity
            activeOpacity={0.82}
            style={styles.actionButton}
            onPress={() => navigation.navigate('Profile')}>
            <UserCircle size={22} color="#172033" weight="duotone" />
          </TouchableOpacity>
        </View>
    </View>
  );
};

export default Header;

const styles = StyleSheet.create({
  header: {
    minHeight: 84,
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#FFFCF8',
    borderBottomLeftRadius: 24,
    borderBottomRightRadius: 24,
    shadowColor: '#000000',
    shadowOpacity: 0.055,
    shadowRadius: 10,
    shadowOffset: {width: 0, height: 4},
    elevation: 3,
  },
  locationSection: {flex: 1, minWidth: 0, flexDirection: 'row', alignItems: 'center', marginRight: 10},
  locationIcon: {width: 44, height: 44, borderRadius: 14, backgroundColor: '#FFF3E6', alignItems: 'center', justifyContent: 'center', marginRight: 10},
  locationText: {flex: 1, minWidth: 0, maxWidth: '100%'},
  eyebrow: {fontSize: 8, fontWeight: '900', letterSpacing: 0.7, color: '#A0A4AC', marginBottom: 2},
  locationName: {fontSize: 14, fontWeight: '900', color: '#172033', lineHeight: 19},
  locationArea: {fontSize: 11, fontWeight: '600', color: '#8A8F98', marginTop: 1},
  actions: {width: 128, flexShrink: 0, flexDirection: 'row', alignItems: 'center', justifyContent: 'flex-end', gap: 5},
  actionButton: {
    width: 38,
    height: 38,
    borderRadius: 14,
    backgroundColor: '#F7F8FA',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
    borderColor: '#EEF0F3',
  },
  cartBadge: {
    position: 'absolute',
    top: -4,
    right: -4,
    minWidth: 17,
    height: 17,
    paddingHorizontal: 4,
    borderRadius: 9,
    backgroundColor: '#FF7A00',
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
  cartBadgeText: {
    color: '#FFFFFF',
    fontSize: 8,
    fontWeight: '900',
  },
});
