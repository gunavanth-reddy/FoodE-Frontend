import React from 'react';
import {
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

import {
  Bell,
} from 'phosphor-react-native';

import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';

import {RootStackParamList} from '../../../../../navigation/AppNavigator';

type NavigationProp =
  NativeStackNavigationProp<RootStackParamList>;

const NotificationButton = () => {
  const navigation = useNavigation<NavigationProp>();

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      style={styles.container}
      onPress={() =>
        navigation.navigate('Notifications')
      }>

      <Bell
        size={21}
        color="#172033"
        weight="duotone"
      />

    </TouchableOpacity>
  );
};

export default NotificationButton;

const styles = StyleSheet.create({
  container: {
    width: 38,
    height: 38,
    borderRadius: 14,
    backgroundColor: '#F7F8FA',
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 1,
    borderColor: '#EEF0F3',
  },
});

export default NotificationButton;
