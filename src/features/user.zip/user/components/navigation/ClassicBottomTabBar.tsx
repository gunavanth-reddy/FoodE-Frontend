import React from 'react';
import {Platform, StyleSheet, Text, TouchableOpacity, View} from 'react-native';
import {House, MagnifyingGlass, Heart, Receipt, UserCircle} from 'phosphor-react-native';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

const ORANGE = '#FF6B00';
const MUTED = '#8B817A';

const ICONS: Record<string, any> = {
  Home: House,
  Search: MagnifyingGlass,
  Favorites: Heart,
  Orders: Receipt,
  Profile: UserCircle,
};

const LABELS: Record<string, string> = {
  Home: 'Home',
  Search: 'Search',
  Favorites: 'Favorites',
  Orders: 'Orders',
  Profile: 'Profile',
};

const ClassicBottomTabBar = ({state, descriptors, navigation}: any) => {
  const insets = useSafeAreaInsets();
  return (
    <View style={[styles.outer, {paddingBottom: Math.max(insets.bottom, 8)}]}>
      <View style={styles.bar}>
        {state.routes.map((route: any, index: number) => {
          const {options} = descriptors[route.key];
          const label = options.tabBarLabel ?? options.title ?? LABELS[route.name] ?? route.name;
          const focused = state.index === index;
          const Icon = ICONS[route.name] ?? House;
          const onPress = () => {
            const event = navigation.emit({type: 'tabPress', target: route.key, canPreventDefault: true});
            if (!focused && !event.defaultPrevented) navigation.navigate(route.name);
          };
          const onLongPress = () => navigation.emit({type: 'tabLongPress', target: route.key});
          return (
            <TouchableOpacity
              key={route.key}
              accessibilityRole="button"
              accessibilityState={focused ? {selected: true} : {}}
              accessibilityLabel={options.tabBarAccessibilityLabel ?? String(label)}
              testID={options.tabBarTestID}
              onPress={onPress}
              onLongPress={onLongPress}
              activeOpacity={0.8}
              style={[styles.item, focused && styles.activeItem]}>
              <Icon size={22} color={focused ? '#FFFFFF' : MUTED} weight={focused ? 'fill' : 'regular'} />
              {focused ? <Text numberOfLines={1} style={styles.activeLabel}>{label}</Text> : null}
            </TouchableOpacity>
          );
        })}
      </View>
    </View>
  );
};

export default ClassicBottomTabBar;

const styles = StyleSheet.create({
  outer: {
    backgroundColor: 'transparent',
    paddingHorizontal: 12,
    paddingTop: 7,
  },
  bar: {
    minHeight: 58,
    width: '100%',
    borderRadius: 32,
    backgroundColor: '#FFFFFF',
    borderWidth: 1,
    borderColor: '#F5E5D8',
    paddingHorizontal: 7,
    paddingVertical: 6,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    shadowColor: '#6A3B1D',
    shadowOpacity: 0.12,
    shadowRadius: 14,
    shadowOffset: {width: 0, height: 5},
    elevation: 9,
  },
  item: {
    flex: 1,
    minWidth: 0,
    height: 44,
    borderRadius: 24,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingHorizontal: 8,
  },
  activeItem: {
    flex: 1.35,
    backgroundColor: ORANGE,
    paddingHorizontal: 13,
  },
  activeLabel: {color: '#FFFFFF', fontSize: 12, fontWeight: '800'},
});
