
const UNAVAILABLE_MESSAGE =
  "SRM AP student verification is currently unavailable. Please try again later.";

/**
 * Verifies SRM AP student credentials for FoodE signup.
 *
 * Expected successful integration response:
 * {
 *   success: true,
 *   student: {
 *     studentName: "Student Name",
 *     registerNo: "APXXXXXXXX",
 *     institution: "SRM AP",
 *     program: "BTech",
 *     section: "Section"
 *   }
 * }
 *
 * Connect this function to an SRM AP-authorized verification
 * API or integration. Never save ERP passwords or session cookies.
 */
async function verifyERPStudent({ username, password } = {}) {
  const normalizedUsername =
    typeof username === "string" ? username.trim() : "";

  if (!normalizedUsername || typeof password !== "string" || !password) {
    return {
      success: false,
      message: "ERP username and password are required.",
    };
  }

  const verificationUrl = process.env.SRMAP_VERIFICATION_URL;

  if (!verificationUrl) {
    return {
      success: false,
      message: UNAVAILABLE_MESSAGE,
    };
  }

  try {
    const url = new URL(verificationUrl);

    if (url.protocol !== "https:") {
      throw new Error("Verification endpoint must use HTTPS.");
    }

    // This endpoint must be an authorized SRM AP verification API.
    // It must authenticate the student and return verified profile data.
    const response = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Accept: "application/json",
      },
      body: JSON.stringify({
        username: normalizedUsername,
        password,
      }),
      signal: AbortSignal.timeout(15000),
    });

    if (!response.ok) {
      return {
        success: false,
        message:
          response.status === 401 || response.status === 403
            ? "ERP verification failed. Check your credentials."
            : UNAVAILABLE_MESSAGE,
      };
    }

    const result = await response.json();

    if (result?.success !== true || !result?.student) {
      return {
        success: false,
        message: result?.message || "ERP verification failed.",
      };
    }

    const student = result.student;
    const registerNo = String(student.registerNo || "")
      .trim()
      .toUpperCase();

    if (!registerNo) {
      return {
        success: false,
        message: "Verified student registration number was not returned.",
      };
    }

    return {
      success: true,
      student: {
        studentName: String(student.studentName || "").trim(),
        registerNo,
        institution: String(student.institution || "SRM AP").trim(),
        program: String(student.program || "").trim(),
        section: String(student.section || "").trim(),
      },
    };
  } catch {
    // Do not log credentials, response bodies, or session data.
    return {
      success: false,
      message: UNAVAILABLE_MESSAGE,
    };
  }
}

module.exports = { verifyERPStudent };
