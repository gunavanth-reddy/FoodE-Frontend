
import React, {useState} from 'react';
import {
  View,
  Alert,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
} from 'react-native';

import {
  registerUser,
  verifySRMAPStudent,
} from '../../../api/auth';

import {
  AppInput,
  AppButton,
  AppText,
} from '../../../components';

const ORANGE = '#FF5A00';
const GREEN = '#16803D';

const RegisterScreen = ({navigation}: any) => {
  // SRM AP ERP verification
  const [erpUsername, setErpUsername] = useState('');
  const [erpPassword, setErpPassword] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [verificationToken, setVerificationToken] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState('');

  // FoodE account details
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const [nameError, setNameError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);

  // ==========================================
  // VERIFY SRM AP STUDENT
  // ==========================================

  const handleVerifyStudent = async () => {
    if (isVerifying || isVerified) {
      return;
    }

    if (!erpUsername.trim() || !erpPassword) {
      setVerificationError(
        'Enter your SRM AP ERP username and password.',
      );
      return;
    }

    setIsVerifying(true);
    setVerificationError('');
    setIsVerified(false);
    setVerificationToken('');

    try {
      const response = await verifySRMAPStudent({
        username: erpUsername.trim(),
        password: erpPassword,
      });

      if (!response?.success || !response?.verificationToken) {
        setVerificationError(
          response?.message || 'Student verification failed.',
        );
        return;
      }

      setVerificationToken(response.verificationToken);
      setIsVerified(true);

      // Do not retain the ERP password in screen state.
      setErpPassword('');

      Alert.alert(
        'Student Verified',
        'Your SRM AP student identity has been verified.',
      );
    } catch (error: any) {
      setVerificationError(
        error?.response?.data?.message ||
          'Unable to verify your student identity. Please try again.',
      );
    } finally {
      setIsVerifying(false);
    }
  };

  // ==========================================
  // REGISTER FOOD E ACCOUNT
  // ==========================================

  const handleRegister = async () => {
    if (!isVerified || !verificationToken) {
      Alert.alert(
        'Verification Required',
        'Verify your SRM AP student identity before creating your account.',
      );
      return;
    }

    if (isRegistering || isVerifying) {
      return;
    }

    const trimmedName = name.trim();
    const trimmedPhone = phone.trim();

    setNameError('');
    setPhoneError('');
    setPasswordError('');

    if (trimmedName.length < 2) {
      setNameError('Name must be at least 2 characters.');
      return;
    }

    if (!/^\d{10}$/.test(trimmedPhone)) {
      setPhoneError('Enter a valid 10-digit mobile number.');
      return;
    }

    if (password.length < 8) {
      setPasswordError('Password must be at least 8 characters.');
      return;
    }

    setIsRegistering(true);

    try {
      const response = await registerUser({
        name: trimmedName,
        phone: trimmedPhone,
        password,
        verificationToken,
      } as any);

      if (!response?.success) {
        Alert.alert(
          'Registration Failed',
          response?.message || 'Unable to create your account.',
        );
        return;
      }

      // Prevent this screen from reusing the verification result.
      setIsVerified(false);
      setVerificationToken('');

      Alert.alert(
        'Account Created',
        'Your FoodE account has been created. You can now log in using your mobile number and password.',
        [
          {
            text: 'OK',
            onPress: () => navigation.replace('Login'),
          },
        ],
      );
    } catch (error: any) {
      Alert.alert(
        'Registration Failed',
        error?.response?.data?.message ||
          'Unable to connect to the FoodE server.',
      );
    } finally {
      setIsRegistering(false);
    }
  };

  // Changing the ERP username invalidates the current verification.
  const handleERPUsernameChange = (text: string) => {
    if (isVerified) {
      return;
    }

    setErpUsername(text);
    setVerificationError('');
  };

  return (
    <View style={styles.screen}>
      <StatusBar
        barStyle="light-content"
        backgroundColor={ORANGE}
        translucent={false}
      />

      <KeyboardAvoidingView
        style={styles.keyboardContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>
        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          bounces={false}
          overScrollMode="never"
          contentContainerStyle={styles.scrollContent}>

          {/* HERO */}

          <View style={styles.hero}>
            <View style={styles.heroCircleLarge} />
            <View style={styles.heroCircleSmall} />
            <View style={styles.heroDot} />
            <View style={styles.heroLine} />

            <View style={styles.brand}>
              <AppText style={styles.brandText}>FoodE</AppText>
              <View style={styles.brandLine} />
              <AppText style={styles.brandTagline}>
                FOOD. FAST. FRESH.
              </AppText>
            </View>
          </View>

          {/* REGISTER CARD */}

          <View style={styles.registerCard}>
            <View style={styles.handle} />

            <View style={styles.header}>
              <AppText style={styles.title}>
                Create Account
              </AppText>

              <AppText style={styles.subtitle}>
                Verify your SRM AP student identity to join FoodE.
              </AppText>
            </View>

            {/* STEP 1: ERP VERIFICATION */}

            <View style={styles.sectionHeader}>
              <AppText style={styles.sectionTitle}>
                1. SRM AP Student Verification
              </AppText>
              <AppText style={styles.sectionSubtitle}>
                Use your college ERP credentials.
              </AppText>
            </View>

            <View style={styles.field}>
              <AppInput
                label="ERP Username"
                placeholder="Enter your ERP username"
                value={erpUsername}
                onChangeText={handleERPUsernameChange}
                autoCapitalize="none"
                editable={!isVerified && !isVerifying}
              />
            </View>

            <View style={styles.field}>
              <AppInput
                label="ERP Password"
                placeholder="Enter your ERP password"
                value={erpPassword}
                onChangeText={text => {
                  if (isVerified || isVerifying) {
                    return;
                  }

                  setErpPassword(text);
                  setVerificationError('');
                }}
                secureTextEntry
                autoCapitalize="none"
                editable={!isVerified && !isVerifying}
              />
            </View>

            <View
              pointerEvents={
                isVerifying || isVerified ? 'none' : 'auto'
              }
              style={
                isVerifying || isVerified
                  ? styles.disabledButton
                  : undefined
              }>
              <AppButton
                title={
                  isVerifying
                    ? 'Verifying Student...'
                    : 'Verify SRM AP Student'
                }
                onPress={handleVerifyStudent}
              />
            </View>

            {isVerified && (
              <View style={styles.verifiedBox}>
                <AppText style={styles.verifiedTitle}>
                  ✓ Verified SRM AP Student
                </AppText>
                <AppText style={styles.verifiedSubtitle}>
                  You can now create your FoodE account.
                </AppText>
              </View>
            )}

            {!!verificationError && (
              <AppText style={styles.errorText}>
                {verificationError}
              </AppText>
            )}

            {/* STEP 2: FOOD E ACCOUNT */}

            <View style={styles.sectionHeader}>
              <AppText style={styles.sectionTitle}>
                2. FoodE Account Details
              </AppText>
              <AppText style={styles.sectionSubtitle}>
                {isVerified
                  ? 'Complete your account details.'
                  : 'Complete verification to unlock these fields.'}
              </AppText>
            </View>

            <View
              pointerEvents={isVerified ? 'auto' : 'none'}
              style={!isVerified ? styles.disabledFields : undefined}>

              {/* NAME */}

              <View style={styles.field}>
                <AppInput
                  label="Full Name"
                  placeholder="Enter your full name"
                  value={name}
                  editable={isVerified}
                  onChangeText={text => {
                    setName(text);
                    setNameError('');
                  }}
                  leftIcon="person-outline"
                  autoCapitalize="words"
                />

                {!!nameError && (
                  <AppText style={styles.errorText}>
                    {nameError}
                  </AppText>
                )}
              </View>

              {/* MOBILE NUMBER */}

              <View style={styles.field}>
                <AppInput
                  label="Mobile Number"
                  placeholder="Enter your 10-digit mobile number"
                  value={phone}
                  editable={isVerified}
                  onChangeText={text => {
                    setPhone(text.replace(/\D/g, '').slice(0, 10));
                    setPhoneError('');
                  }}
                  leftIcon="call-outline"
                  keyboardType="phone-pad"
                  autoCapitalize="none"
                />

                {!!phoneError && (
                  <AppText style={styles.errorText}>
                    {phoneError}
                  </AppText>
                )}
              </View>

              {/* PASSWORD */}

              <View style={styles.field}>
                <AppInput
                  label="FoodE Password"
                  placeholder="Create a password (minimum 8 characters)"
                  value={password}
                  editable={isVerified}
                  onChangeText={text => {
                    setPassword(text);
                    setPasswordError('');
                  }}
                  leftIcon="lock-closed-outline"
                  secureTextEntry
                  autoCapitalize="none"
                />

                {!!passwordError && (
                  <AppText style={styles.errorText}>
                    {passwordError}
                  </AppText>
                )}
              </View>
            </View>

            {/* CREATE ACCOUNT */}

            <View
              pointerEvents={isVerified && !isRegistering ? 'auto' : 'none'}
              style={
                !isVerified || isRegistering
                  ? styles.disabledButton
                  : undefined
              }>
              <AppButton
                title={
                  isRegistering
                    ? 'Creating Account...'
                    : 'Create Account'
                }
                onPress={handleRegister}
              />
            </View>

            {/* LOGIN */}

            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.loginButton}
              onPress={() => navigation.navigate('Login')}>
              <AppText style={styles.loginText}>
                Already have an account?{' '}
                <AppText style={styles.loginHighlight}>
                  Sign In
                </AppText>
              </AppText>
            </TouchableOpacity>

            <AppText style={styles.version}>
              Version 1.0.0
            </AppText>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default RegisterScreen;

// ==========================================
// STYLES
// ==========================================

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  keyboardContainer: {
    flex: 1,
  },

  scrollContent: {
    flexGrow: 1,
    paddingBottom: 28,
  },

  hero: {
    minHeight: 190,
    backgroundColor: ORANGE,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },

  brand: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },

  brandText: {
    color: '#FFFFFF',
    fontSize: 56,
    fontWeight: '900',
    letterSpacing: -2.5,
  },

  brandLine: {
    width: 42,
    height: 4,
    borderRadius: 4,
    backgroundColor: '#FFFFFF',
    marginTop: 4,
  },

  brandTagline: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 2.2,
    marginTop: 8,
  },

  heroCircleLarge: {
    position: 'absolute',
    width: 190,
    height: 190,
    borderRadius: 95,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.12)',
    right: -80,
    top: -105,
  },

  heroCircleSmall: {
    position: 'absolute',
    width: 75,
    height: 75,
    borderRadius: 38,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.14)',
    left: -25,
    bottom: -30,
  },

  heroDot: {
    position: 'absolute',
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: 'rgba(255,255,255,0.25)',
    left: 65,
    top: 100,
  },

  heroLine: {
    position: 'absolute',
    width: 75,
    height: 1,
    backgroundColor: 'rgba(255,255,255,0.16)',
    right: 55,
    bottom: 65,
    transform: [{rotate: '-35deg'}],
  },

  registerCard: {
    width: '100%',
    maxWidth: 560,
    alignSelf: 'center',
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 34,
    borderTopRightRadius: 34,
    paddingHorizontal: 20,
    paddingTop: 13,
    paddingBottom: 30,
    marginTop: -28,
    elevation: 8,
    shadowColor: '#000000',
    shadowOffset: {width: 0, height: -4},
    shadowOpacity: 0.08,
    shadowRadius: 14,
  },

  handle: {
    width: 38,
    height: 4,
    borderRadius: 4,
    backgroundColor: '#E2E2E2',
    alignSelf: 'center',
    marginBottom: 18,
  },

  header: {
    marginBottom: 20,
  },

  title: {
    fontSize: 27,
    fontWeight: '800',
    color: '#161616',
    marginBottom: 5,
  },

  subtitle: {
    fontSize: 14,
    lineHeight: 20,
    color: '#777777',
  },

  sectionHeader: {
    marginTop: 8,
    marginBottom: 12,
  },

  sectionTitle: {
    fontSize: 16,
    fontWeight: '800',
    color: '#222222',
    marginBottom: 4,
  },

  sectionSubtitle: {
    fontSize: 12,
    lineHeight: 18,
    color: '#777777',
  },

  field: {
    marginBottom: 10,
  },

  disabledFields: {
    opacity: 0.45,
  },

  disabledButton: {
    opacity: 0.45,
  },

  verifiedBox: {
    backgroundColor: '#EAF7EE',
    borderColor: '#B7E4C7',
    borderWidth: 1,
    borderRadius: 12,
    paddingHorizontal: 14,
    paddingVertical: 12,
    marginTop: 12,
    marginBottom: 14,
  },

  verifiedTitle: {
    color: GREEN,
    fontSize: 14,
    fontWeight: '800',
  },

  verifiedSubtitle: {
    color: '#386747',
    fontSize: 12,
    marginTop: 4,
  },

  errorText: {
    color: '#E53935',
    fontSize: 13,
    fontWeight: '500',
    marginTop: 4,
    marginBottom: 8,
    marginLeft: 5,
  },

  loginButton: {
    alignItems: 'center',
    marginTop: 22,
  },

  loginText: {
    color: '#777777',
    fontSize: 14,
  },

  loginHighlight: {
    color: ORANGE,
    fontWeight: '800',
  },

  version: {
    color: '#AAAAAA',
    fontSize: 11,
    textAlign: 'center',
    marginTop: 20,
  },
});
