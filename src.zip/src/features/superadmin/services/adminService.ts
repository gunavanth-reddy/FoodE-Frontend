// =====================================================
// ADMIN SERVICE
// =====================================================

const API_BASE_URL =
  'https://foode-backend-vn67.onrender.com/api';

// =====================================================
// TYPES
// =====================================================

export interface AdminDashboardStats {
  totalUsers: number;
  totalRestaurantOwners: number;
  totalRestaurants: number;
  pendingRestaurants: number;
  approvedRestaurants: number;
  activeRestaurants: number;
}

export interface AdminOrderStats {
  orders: {
    total: number;
    today: number;
    active: number;
    delivered: number;
    cancelled: number;
  };

  revenue: {
    today: number;
    total: number;
  };
}

// =====================================================
// RESPONSE TYPES
// =====================================================

interface DashboardResponse {
  success: boolean;
  stats?: AdminDashboardStats;
  message?: string;
}

interface OrderStatsResponse {
  success: boolean;
  stats?: AdminOrderStats;
  message?: string;
}

// =====================================================
// FETCH WITH TIMEOUT
// =====================================================

const fetchWithTimeout = async (
  url: string,
  options: RequestInit = {},
  timeout = 10000,
): Promise<Response> => {
  const controller =
    new AbortController();

  const timeoutId = setTimeout(
    () => {
      controller.abort();
    },
    timeout,
  );

  try {
    return await fetch(url, {
      ...options,
      signal: controller.signal,
    });
  } finally {
    clearTimeout(timeoutId);
  }
};

// =====================================================
// GET DASHBOARD STATS
// =====================================================

export const getAdminDashboardStats =
  async (
    token: string,
  ): Promise<AdminDashboardStats> => {
    if (!token) {
      throw new Error(
        'Authentication token is missing.',
      );
    }

    try {
      const response =
        await fetchWithTimeout(
          `${API_BASE_URL}/admin/dashboard`,
          {
            method: 'GET',

            headers: {
              Accept:
                'application/json',

              Authorization:
                `Bearer ${token}`,
            },
          },
        );

      const data =
        (await response.json()) as DashboardResponse;

      console.log(
        'Admin Dashboard Status:',
        response.status,
      );

      console.log(
        'Admin Dashboard Response:',
        data,
      );

      if (
        response.status === 401
      ) {
        throw new Error(
          'Authentication expired. Please login again.',
        );
      }

      if (
        response.status === 403
      ) {
        throw new Error(
          'You are not authorized to access the admin dashboard.',
        );
      }

      if (!response.ok) {
        throw new Error(
          data.message ||
            'Failed to fetch admin dashboard.',
        );
      }

      if (
        !data.success ||
        !data.stats
      ) {
        throw new Error(
          data.message ||
            'Failed to fetch admin dashboard.',
        );
      }

      return data.stats;
    } catch (error: any) {
      console.log(
        'getAdminDashboardStats error:',
        error,
      );

      if (
        error?.name ===
        'AbortError'
      ) {
        throw new Error(
          'Dashboard request timed out. Make sure the backend is running.',
        );
      }

      throw error;
    }
  };

// =====================================================
// GET ORDER / REVENUE STATS
// =====================================================

export const getAdminOrderStats =
  async (
    token: string,
  ): Promise<AdminOrderStats> => {
    if (!token) {
      throw new Error(
        'Authentication token is missing.',
      );
    }

    try {
      const response =
        await fetchWithTimeout(
          `${API_BASE_URL}/admin/dashboard/orders`,
          {
            method: 'GET',

            headers: {
              Accept:
                'application/json',

              Authorization:
                `Bearer ${token}`,
            },
          },
        );

      const data =
        (await response.json()) as OrderStatsResponse;

      console.log(
        'Admin Order Stats Status:',
        response.status,
      );

      console.log(
        'Admin Order Stats Response:',
        data,
      );

      if (
        response.status === 401
      ) {
        throw new Error(
          'Authentication expired. Please login again.',
        );
      }

      if (
        response.status === 403
      ) {
        throw new Error(
          'You are not authorized to access admin order statistics.',
        );
      }

      if (!response.ok) {
        throw new Error(
          data.message ||
            'Failed to fetch order statistics.',
        );
      }

      if (
        !data.success ||
        !data.stats
      ) {
        throw new Error(
          data.message ||
            'Failed to fetch order statistics.',
        );
      }

      return data.stats;
    } catch (error: any) {
      console.log(
        'getAdminOrderStats error:',
        error,
      );

      if (
        error?.name ===
        'AbortError'
      ) {
        throw new Error(
          'Order statistics request timed out. Make sure the backend is running.',
        );
      }

      throw error;
    }
  };
