import React from 'react';

import {
  StyleSheet,
  Text,
  View,
} from 'react-native';

import Ionicons from '@react-native-vector-icons/ionicons/static';

interface AdminStatCardProps {
  icon: string;
  title: string;
  value: string | number;
  subtitle?: string;
}

const AdminStatCard = ({
  icon,
  title,
  value,
  subtitle,
}: AdminStatCardProps) => {
  return (
    <View style={styles.card}>
      <View style={styles.iconContainer}>
        <Ionicons
          name={icon as any}
          size={21}
          color="#FF7A00"
        />
      </View>

      <Text style={styles.title}>
        {title}
      </Text>

      <Text style={styles.value}>
        {value}
      </Text>

      {subtitle ? (
        <Text style={styles.subtitle}>
          {subtitle}
        </Text>
      ) : null}
    </View>
  );
};

const styles = StyleSheet.create({
  card: {
    width: '48%',
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    padding: 16,
    marginBottom: 14,
    borderWidth: 1,
    borderColor: '#F1F1F1',
    elevation: 2,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.05,
    shadowRadius: 6,
  },

  iconContainer: {
    width: 44,
    height: 44,
    borderRadius: 14,
    backgroundColor: '#FFF3E8',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 13,
  },

  title: {
    fontSize: 13,
    fontWeight: '600',
    color: '#777777',
    marginBottom: 5,
  },

  value: {
    fontSize: 25,
    fontWeight: '900',
    color: '#17171B',
    lineHeight: 30,
  },

  subtitle: {
    fontSize: 11,
    fontWeight: '500',
    color: '#999999',
    marginTop: 5,
  },
});

export default AdminStatCard;

