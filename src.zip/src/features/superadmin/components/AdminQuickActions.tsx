import React from 'react';

import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import Ionicons from '@react-native-vector-icons/ionicons/static';

interface AdminQuickActionsProps {
  onUsersPress: () => void;
  onRestaurantsPress: () => void;
  onOrdersPress: () => void;
  onReviewsPress: () => void;
}

const AdminQuickActions = ({
  onUsersPress,
  onRestaurantsPress,
  onOrdersPress,
  onReviewsPress,
}: AdminQuickActionsProps) => {
  return (
    <View style={styles.container}>
      <Text style={styles.title}>
        Quick Actions
      </Text>

      <View style={styles.grid}>
        <TouchableOpacity
          activeOpacity={0.8}
          onPress={onUsersPress}
          style={styles.action}>
          <View style={styles.iconContainer}>
            <Ionicons
              name="people-outline"
              size={22}
              color="#FF7A00"
            />
          </View>

          <Text style={styles.actionText}>
            Users
          </Text>

          <Ionicons
            name="chevron-forward"
            size={18}
            color="#AAAAAA"
          />
        </TouchableOpacity>

        <TouchableOpacity
          activeOpacity={0.8}
          onPress={onRestaurantsPress}
          style={styles.action}>
          <View style={styles.iconContainer}>
            <Ionicons
              name="restaurant-outline"
              size={22}
              color="#FF7A00"
            />
          </View>

          <Text style={styles.actionText}>
            Restaurants
          </Text>

          <Ionicons
            name="chevron-forward"
            size={18}
            color="#AAAAAA"
          />
        </TouchableOpacity>

        <TouchableOpacity
          activeOpacity={0.8}
          onPress={onOrdersPress}
          style={styles.action}>
          <View style={styles.iconContainer}>
            <Ionicons
              name="receipt-outline"
              size={22}
              color="#FF7A00"
            />
          </View>

          <Text style={styles.actionText}>
            Orders
          </Text>

          <Ionicons
            name="chevron-forward"
            size={18}
            color="#AAAAAA"
          />
        </TouchableOpacity>

        <TouchableOpacity
          activeOpacity={0.8}
          onPress={onReviewsPress}
          style={styles.action}>
          <View style={styles.iconContainer}>
            <Ionicons
              name="star-outline"
              size={22}
              color="#FF7A00"
            />
          </View>

          <Text style={styles.actionText}>
            Reviews
          </Text>

          <Ionicons
            name="chevron-forward"
            size={18}
            color="#AAAAAA"
          />
        </TouchableOpacity>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    marginTop: 8,
  },

  title: {
    fontSize: 19,
    fontWeight: '900',
    color: '#17171B',
    marginBottom: 14,
  },

  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
  },

  action: {
    width: '48%',
    minHeight: 72,
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    borderWidth: 1,
    borderColor: '#F1F1F1',
    elevation: 1,
    shadowColor: '#000000',
    shadowOffset: {
      width: 0,
      height: 1,
    },
    shadowOpacity: 0.04,
    shadowRadius: 4,
  },

  iconContainer: {
    width: 42,
    height: 42,
    borderRadius: 13,
    backgroundColor: '#FFF3E8',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 10,
  },

  actionText: {
    flex: 1,
    fontSize: 14,
    fontWeight: '800',
    color: '#333333',
  },
});

export default AdminQuickActions;

