import {SafeAreaView} from 'react-native-safe-area-context';
import React, {
  useCallback,
  useEffect,
  useMemo,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Alert,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {useNavigation} from '@react-navigation/native';

import {
  NativeStackNavigationProp,
} from '@react-navigation/native-stack';

import {
  RootStackParamList,
} from '../../../navigation/AppNavigator';

import {useAuth} from '../../../context/AuthContext';
import {useCart} from '../../../context/CartContext';

import {
  createOrder,
  DeliveryAddress,
} from '../services/orderService';

// =====================================================
// NAVIGATION
// =====================================================

type CheckoutNavigationProp =
  NativeStackNavigationProp<
    RootStackParamList,
    'Checkout'
  >;

// =====================================================
// API
// =====================================================

const API_BASE_URL =
  'https://foode-backend-vn67.onrender.com/api';

// =====================================================
// DELIVERY SLOT
// =====================================================

interface AvailableDeliverySlot {
  _id: string;
  restaurant?: string;
  startTime: string;
  endTime: string;
  isActive: boolean;

  cutoffMinutes?: number;

  cutoffTime?: string;

  etaLabel?: string;

  estimatedDelivery?: {
    minMinutes: number;
    maxMinutes: number;
  };

  deliveryTime?: {
    min: number;
    max: number;
  };

  createdAt?: string;
  updatedAt?: string;
}

// =====================================================
// DELIVERY SLOT RESPONSE
// =====================================================

interface DeliverySlotsResponse {
  success?: boolean;
  message?: string;

  deliverySlots?: AvailableDeliverySlot[];

  restaurantId?: string;
  restaurantName?: string;

  // Backend provides this.
  // This is preferred over device time.
  currentIndiaMinutes?: number;
}

// =====================================================
// CART ITEM
// =====================================================

interface CheckoutCartItem {
  id?: string;
  _id?: string;
  foodId?: string;

  name?: string;

  quantity?: number;

  price?: number;

  discountedPrice?: number | null;

  restaurantId?: string;

  restaurant?:
    | string
    | {
        _id?: string;
        name?: string;
      };
}

// =====================================================
// TIME HELPERS
// =====================================================

const timeToMinutes = (
  time: string,
): number => {
  if (
    typeof time !== 'string' ||
    !/^([01]\d|2[0-3]):[0-5]\d$/.test(
      time,
    )
  ) {
    return -1;
  }

  const [hours, minutes] =
    time.split(':').map(Number);

  return hours * 60 + minutes;
};

// =====================================================
// CURRENT INDIA TIME
// =====================================================

const getCurrentIndiaMinutes = (): number => {
  try {
    const formatter =
      new Intl.DateTimeFormat(
        'en-IN',
        {
          timeZone: 'Asia/Kolkata',
          hour: '2-digit',
          minute: '2-digit',
          hour12: false,
        },
      );

    const parts =
      formatter.formatToParts(
        new Date(),
      );

    let hour = Number(
      parts.find(
        part => part.type === 'hour',
      )?.value || 0,
    );

    const minute = Number(
      parts.find(
        part => part.type === 'minute',
      )?.value || 0,
    );

    if (hour === 24) {
      hour = 0;
    }

    return hour * 60 + minute;
  } catch {
    return -1;
  }
};

// =====================================================
// VALID SLOT
// =====================================================

const isValidDeliverySlot = (
  slot: AvailableDeliverySlot,
): boolean => {
  if (!slot) {
    return false;
  }

  if (!slot._id) {
    return false;
  }

  if (!slot.isActive) {
    return false;
  }

  const startMinutes =
    timeToMinutes(
      slot.startTime,
    );

  const endMinutes =
    timeToMinutes(
      slot.endTime,
    );

  if (
    startMinutes < 0 ||
    endMinutes < 0
  ) {
    return false;
  }

  // Every FoodE slot must be exactly 30 minutes.
  if (
    endMinutes - startMinutes !== 30
  ) {
    return false;
  }

  return true;
};

// =====================================================
// CHECK WHETHER SLOT IS BOOKABLE
// =====================================================
//
// Example:
//
// 12:00 - 12:30
// cutoff = 10
//
// 11:49 -> AVAILABLE
// 11:50 -> CLOSED
//
// =====================================================

const isDeliverySlotBookable = (
  slot: AvailableDeliverySlot,
  currentMinutes: number,
): boolean => {
  if (
    !isValidDeliverySlot(slot)
  ) {
    return false;
  }

  if (
    currentMinutes < 0 ||
    currentMinutes >= 24 * 60
  ) {
    return false;
  }

  const startMinutes =
    timeToMinutes(
      slot.startTime,
    );

  if (startMinutes < 0) {
    return false;
  }

  // Backend is configured for 10 minutes.
  // Respect a valid backend value if supplied.
  const cutoffMinutes =
    Number.isFinite(
      Number(slot.cutoffMinutes),
    )
      ? Number(slot.cutoffMinutes)
      : 10;

  // Safety.
  const safeCutoff = Math.max(
    0,
    cutoffMinutes,
  );

  const bookingCloseMinutes =
    startMinutes - safeCutoff;

  // ---------------------------------------------------
  // NORMAL SAME-DAY CASE
  // ---------------------------------------------------
  //
  // 12:00 - 10 = 11:50
  //
  // Current 11:49 -> true
  // Current 11:50 -> false
  //

  if (
    bookingCloseMinutes >= 0
  ) {
    return (
      currentMinutes <
      bookingCloseMinutes
    );
  }

  // ---------------------------------------------------
  // CUTOFF FALLS ON PREVIOUS DAY
  // ---------------------------------------------------
  //
  // Since the app currently does not have a delivery
  // date associated with a slot, a slot whose cutoff
  // falls on the previous day is not bookable today.
  //

  return false;
};

// =====================================================
// GET BOOKING CUTOFF TIME
// =====================================================

const getSlotCutoffTime = (
  slot: AvailableDeliverySlot,
): string => {
  const startMinutes =
    timeToMinutes(
      slot.startTime,
    );

  if (startMinutes < 0) {
    return '--';
  }

  const cutoffMinutes =
    Number.isFinite(
      Number(slot.cutoffMinutes),
    )
      ? Number(slot.cutoffMinutes)
      : 10;

  let cutoff =
    startMinutes -
    Math.max(0, cutoffMinutes);

  if (cutoff < 0) {
    cutoff += 24 * 60;
  }

  const hours =
    Math.floor(cutoff / 60);

  const minutes =
    cutoff % 60;

  return `${String(hours).padStart(
    2,
    '0',
  )}:${String(minutes).padStart(
    2,
    '0',
  )}`;
};

// =====================================================
// SCREEN
// =====================================================

const CheckoutScreen = () => {
  const navigation =
    useNavigation<CheckoutNavigationProp>();

  // ===================================================
  // AUTH
  // ===================================================

  const {
    user,
    token,
    isLoggedIn,
  } = useAuth();

  // ===================================================
  // CART
  // ===================================================

  const {
    items,
    subtotal,
    deliveryFee,
    clearCart,
  } = useCart();

  // ===================================================
  // TOTAL
  // ===================================================

  const grandTotal =
    Number(subtotal || 0) +
    Number(deliveryFee || 0);

  // ===================================================
  // STATE
  // ===================================================

  const [
    isPlacingOrder,
    setIsPlacingOrder,
  ] = useState(false);

  const [
    deliverySlots,
    setDeliverySlots,
  ] = useState<
    AvailableDeliverySlot[]
  >([]);

  const [
    selectedDeliverySlot,
    setSelectedDeliverySlot,
  ] =
    useState<
      AvailableDeliverySlot | null
    >(null);

  const [
    loadingSlots,
    setLoadingSlots,
  ] = useState(false);

  const [
    slotError,
    setSlotError,
  ] = useState('');

  // ===================================================
  // DELIVERY ADDRESS
  // ===================================================

  const deliveryAddress: DeliveryAddress = {
    name:
      user?.name ||
      'FoodE User',

    phone:
      user?.phone ||
      '',

    addressLine:
      'SRM AP University, Gate Number 3',

    city:
      'Neerukonda',

    state:
      'Andhra Pradesh',

    pincode:
      '',
  };

  // ===================================================
  // GET RESTAURANT ID
  // ===================================================

  const restaurantId =
    useMemo(() => {
      const firstItem =
        items?.[0] as
          | CheckoutCartItem
          | undefined;

      if (!firstItem) {
        return '';
      }

      // -----------------------------------------------
      // restaurantId
      // -----------------------------------------------

      if (
        typeof firstItem.restaurantId ===
          'string' &&
        firstItem.restaurantId.trim()
      ) {
        return firstItem.restaurantId.trim();
      }

      // -----------------------------------------------
      // restaurant._id
      // -----------------------------------------------

      if (
        firstItem.restaurant &&
        typeof firstItem.restaurant ===
          'object' &&
        typeof firstItem.restaurant._id ===
          'string' &&
        firstItem.restaurant._id.trim()
      ) {
        return firstItem.restaurant._id.trim();
      }

      // -----------------------------------------------
      // restaurant string
      // -----------------------------------------------

      if (
        typeof firstItem.restaurant ===
          'string' &&
        firstItem.restaurant.trim()
      ) {
        return firstItem.restaurant.trim();
      }

      return '';
    }, [items]);

  // ===================================================
  // LOAD DELIVERY SLOTS
  // ===================================================

  const loadDeliverySlots =
    useCallback(
      async (
        currentRestaurantId: string,
      ) => {
        if (!currentRestaurantId) {
          setDeliverySlots([]);
          setSelectedDeliverySlot(
            null,
          );

          setSlotError(
            'Restaurant information is missing from your cart.',
          );

          return;
        }

        try {
          setLoadingSlots(true);
          setSlotError('');
          setSelectedDeliverySlot(
            null,
          );

          console.log(
            '====================================',
          );

          console.log(
            'FoodE: Loading delivery slots',
          );

          console.log(
            'Restaurant ID:',
            currentRestaurantId,
          );

          const url =
            `${API_BASE_URL}/delivery-slots/restaurant/${currentRestaurantId}`;

          console.log(
            'Delivery Slot URL:',
            url,
          );

          // =========================================
          // REQUEST
          // =========================================

          const response =
            await fetch(url, {
              method: 'GET',

              headers: {
                Accept:
                  'application/json',
              },
            });

          // =========================================
          // RESPONSE
          // =========================================

          let data:
            DeliverySlotsResponse =
              {};

          try {
            data =
              (await response.json()) as
                DeliverySlotsResponse;
          } catch {
            data = {};
          }

          console.log(
            'Delivery slot status:',
            response.status,
          );

          console.log(
            'Delivery slot response:',
            data,
          );

          // =========================================
          // HTTP ERROR
          // =========================================

          if (!response.ok) {
            throw new Error(
              data.message ||
                `Failed to load delivery slots (${response.status})`,
            );
          }

          // =========================================
          // SUCCESS CHECK
          // =========================================

          if (
            data.success === false
          ) {
            throw new Error(
              data.message ||
                'Unable to load delivery slots.',
            );
          }

          // =========================================
          // RAW SLOTS
          // =========================================

          const rawSlots =
            Array.isArray(
              data.deliverySlots,
            )
              ? data.deliverySlots
              : [];

          console.log(
            'FoodE: Raw delivery slots:',
            rawSlots,
          );

          // =========================================
          // CURRENT INDIA TIME
          // =========================================
          //
          // Prefer backend time because backend is
          // the final authority.
          //

          const backendCurrentMinutes =
            Number(
              data.currentIndiaMinutes,
            );

          const currentMinutes =
            Number.isFinite(
              backendCurrentMinutes,
            )
              ? backendCurrentMinutes
              : getCurrentIndiaMinutes();

          console.log(
            'FoodE: Current India minutes:',
            currentMinutes,
          );

          // =========================================
          // VALIDATE SLOTS
          // =========================================

          const validSlots =
            rawSlots.filter(
              isValidDeliverySlot,
            );

          console.log(
            'FoodE: Valid slots:',
            validSlots,
          );

          // =========================================
          // FILTER BOOKABLE SLOTS
          // =========================================
          //
          // Backend already filters these.
          // Frontend checks again so stale data
          // cannot be selected.
          //

          const bookableSlots =
            validSlots.filter(
              slot =>
                isDeliverySlotBookable(
                  slot,
                  currentMinutes,
                ),
            );

          console.log(
            'FoodE: Bookable slots:',
            bookableSlots,
          );

          // =========================================
          // SORT
          // =========================================

          const sortedSlots =
            [...bookableSlots].sort(
              (a, b) => {
                const aStart =
                  timeToMinutes(
                    a.startTime,
                  );

                const bStart =
                  timeToMinutes(
                    b.startTime,
                  );

                return (
                  aStart - bStart
                );
              },
            );

          console.log(
            'FoodE: Final slots shown:',
            sortedSlots,
          );

          // =========================================
          // SET STATE
          // =========================================

          setDeliverySlots(
            sortedSlots,
          );

          // =========================================
          // NO SLOTS
          // =========================================

          if (
            sortedSlots.length === 0
          ) {
            setSlotError(
              'No delivery slots are currently available for this restaurant.',
            );
          } else {
            setSlotError('');
          }
        } catch (error: any) {
          console.log(
            'FoodE: Delivery slot error:',
            error,
          );

          setDeliverySlots([]);
          setSelectedDeliverySlot(
            null,
          );

          setSlotError(
            error?.message ||
              'Unable to load delivery slots.',
          );
        } finally {
          setLoadingSlots(false);

          console.log(
            '====================================',
          );
        }
      },
      [],
    );

  // ===================================================
  // LOAD SLOTS WHEN RESTAURANT CHANGES
  // ===================================================

  useEffect(() => {
    if (
      !items ||
      items.length === 0
    ) {
      setDeliverySlots([]);
      setSelectedDeliverySlot(
        null,
      );
      setSlotError('');

      return;
    }

    if (!restaurantId) {
      setDeliverySlots([]);
      setSelectedDeliverySlot(
        null,
      );

      setSlotError(
        'Unable to identify the restaurant for this cart.',
      );

      return;
    }

    loadDeliverySlots(
      restaurantId,
    );
  }, [
    restaurantId,
    items,
    loadDeliverySlots,
  ]);

  // ===================================================
  // FORMAT TIME
  // ===================================================

  const formatSlotTime = (
    time: string,
  ): string => {
    if (!time) {
      return '--';
    }

    const parts =
      time.split(':');

    if (parts.length < 2) {
      return time;
    }

    const hour =
      Number(parts[0]);

    const minute =
      Number(parts[1]);

    if (
      Number.isNaN(hour) ||
      Number.isNaN(minute)
    ) {
      return time;
    }

    const period =
      hour >= 12
        ? 'PM'
        : 'AM';

    const displayHour =
      hour % 12 || 12;

    return `${displayHour}:${String(
      minute,
    ).padStart(
      2,
      '0',
    )} ${period}`;
  };

  // ===================================================
  // SLOT LABEL
  // ===================================================

  const getSlotLabel = (
    slot: AvailableDeliverySlot,
  ): string => {
    return `${formatSlotTime(
      slot.startTime,
    )} - ${formatSlotTime(
      slot.endTime,
    )}`;
  };

  // ===================================================
  // ETA LABEL
  // ===================================================

  const getEtaLabel = (
    slot: AvailableDeliverySlot,
  ): string => {
    if (slot.etaLabel) {
      return slot.etaLabel;
    }

    if (
      slot.estimatedDelivery
    ) {
      return `Delivery in ${slot.estimatedDelivery.minMinutes}–${slot.estimatedDelivery.maxMinutes} mins`;
    }

    if (slot.deliveryTime) {
      return `Delivery in ${slot.deliveryTime.min}–${slot.deliveryTime.max} mins`;
    }

    return 'Delivery in 20–35 mins';
  };

  // ===================================================
  // SELECT DELIVERY SLOT
  // ===================================================

  const handleSelectDeliverySlot =
    (
      slot: AvailableDeliverySlot,
    ) => {
      const currentMinutes =
        getCurrentIndiaMinutes();

      // -----------------------------------------------
      // FINAL CHECK
      // -----------------------------------------------

      if (
        !isDeliverySlotBookable(
          slot,
          currentMinutes,
        )
      ) {
        setSelectedDeliverySlot(
          null,
        );

        Alert.alert(
          'Delivery Slot Closed',
          'This delivery slot is no longer available. Please select another slot.',
        );

        if (restaurantId) {
          loadDeliverySlots(
            restaurantId,
          );
        }

        return;
      }

      setSelectedDeliverySlot(
        slot,
      );
    };

  // ===================================================
  // PLACE ORDER
  // ===================================================

  const handlePlaceOrder =
    async () => {
      // -----------------------------------------------
      // LOGIN
      // -----------------------------------------------

      if (
        !isLoggedIn ||
        !token
      ) {
        Alert.alert(
          'Login Required',
          'Please login before placing your order.',
        );

        return;
      }

      // -----------------------------------------------
      // CART
      // -----------------------------------------------

      if (
        !items ||
        items.length === 0
      ) {
        Alert.alert(
          'Cart Empty',
          'Please add food to your cart before placing an order.',
        );

        return;
      }

      // -----------------------------------------------
      // PHONE
      // -----------------------------------------------

      if (!user?.phone) {
        Alert.alert(
          'Phone Number Required',
          'Please add your phone number before placing the order.',
        );

        return;
      }

      // -----------------------------------------------
      // RESTAURANT
      // -----------------------------------------------

      if (!restaurantId) {
        Alert.alert(
          'Restaurant Error',
          'Unable to identify the restaurant for this order.',
        );

        return;
      }

      // -----------------------------------------------
      // SLOT
      // -----------------------------------------------

      if (
        !selectedDeliverySlot
      ) {
        Alert.alert(
          'Delivery Slot Required',
          'Please select a delivery time before placing your order.',
        );

        return;
      }

      // -----------------------------------------------
      // PREVENT DOUBLE TAP
      // -----------------------------------------------

      if (isPlacingOrder) {
        return;
      }

      // -----------------------------------------------
      // FINAL CUTOFF CHECK
      // -----------------------------------------------

      const currentMinutes =
        getCurrentIndiaMinutes();

      const slotStillBookable =
        isDeliverySlotBookable(
          selectedDeliverySlot,
          currentMinutes,
        );

      if (
        !slotStillBookable
      ) {
        setSelectedDeliverySlot(
          null,
        );

        Alert.alert(
          'Delivery Slot Closed',
          'This delivery slot is no longer available. Please select another slot.',
        );

        await loadDeliverySlots(
          restaurantId,
        );

        return;
      }

      try {
        setIsPlacingOrder(true);

        console.log(
          'FoodE: Creating order...',
        );

        console.log(
          'Restaurant:',
          restaurantId,
        );

        console.log(
          'Selected delivery slot:',
          selectedDeliverySlot,
        );

        // =============================================
        // CREATE ORDER
        // =============================================

        const order =
          await createOrder(
            token,
            {
              deliveryAddress,

              deliverySlot: {
                slotId:
                  selectedDeliverySlot._id,

                startTime:
                  selectedDeliverySlot.startTime,

                endTime:
                  selectedDeliverySlot.endTime,
              },

              paymentMethod:
                'COD',

              customerNote:
                '',
            },
          );

        console.log(
          'FoodE: Order created:',
          order,
        );

        // =============================================
        // CLEAR CART
        // =============================================

        await clearCart();

        // =============================================
        // SUCCESS
        // =============================================

        navigation.replace(
          'OrderSuccess',
          {
            order,
          },
        );
      } catch (error: any) {
        console.log(
          'FoodE: Place order error:',
          error,
        );

        Alert.alert(
          'Order Failed',
          error?.message ||
            'Unable to place your order. Please try again.',
        );
      } finally {
        setIsPlacingOrder(false);
      }
    };

  // ===================================================
  // LOGIN REQUIRED
  // ===================================================

  if (!isLoggedIn) {
    return (
      <SafeAreaView
        style={styles.container} edges={['top', 'left', 'right']}>
        <View
          style={
            styles.centerContainer
          }>
          <Text
            style={
              styles.centerTitle
            }>
            Login Required
          </Text>

          <Text
            style={
              styles.centerDescription
            }>
            Please login to continue
            with your order.
          </Text>

          <Pressable
            style={
              styles.primaryButton
            }
            onPress={() =>
              navigation.goBack()
            }>
            <Text
              style={
                styles.primaryButtonText
              }>
              Go Back
            </Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  // ===================================================
  // EMPTY CART
  // ===================================================

  if (
    !items ||
    items.length === 0
  ) {
    return (
      <SafeAreaView
        style={styles.container} edges={['top', 'left', 'right']}>
        <View
          style={
            styles.centerContainer
          }>
          <Text
            style={
              styles.centerTitle
            }>
            Your Cart is Empty
          </Text>

          <Text
            style={
              styles.centerDescription
            }>
            Add some delicious food
            before checking out.
          </Text>

          <Pressable
            style={
              styles.primaryButton
            }
            onPress={() =>
              navigation.goBack()
            }>
            <Text
              style={
                styles.primaryButtonText
              }>
              Go Back
            </Text>
          </Pressable>
        </View>
      </SafeAreaView>
    );
  }

  // ===================================================
  // MAIN UI
  // ===================================================

  return (
    <SafeAreaView
      style={styles.container} edges={['top', 'left', 'right']}>
      <ScrollView
        showsVerticalScrollIndicator={
          false
        }
        contentContainerStyle={
          styles.scrollContent
        }>

        {/* HEADER */}

        <View
          style={styles.header}>
          <Text
            style={
              styles.headerTitle
            }>
            Checkout
          </Text>

          <Text
            style={
              styles.headerSubtitle
            }>
            Review your order before
            placing it
          </Text>
        </View>

        {/* DELIVERY ADDRESS */}

        <View
          style={styles.section}>
          <Text
            style={
              styles.sectionTitle
            }>
            Delivery Address
          </Text>

          <View
            style={styles.card}>
            <View
              style={
                styles.addressHeader
              }>
              <View
                style={
                  styles.locationIcon
                }>
                <Text
                  style={
                    styles.iconText
                  }>
                  📍
                </Text>
              </View>

              <View
                style={
                  styles.addressHeaderText
                }>
                <Text
                  style={
                    styles.addressTitle
                  }>
                  SRM AP University
                </Text>

                <Text
                  style={
                    styles.addressSubtitle
                  }>
                  Gate Number 3
                </Text>
              </View>
            </View>

            <View
              style={styles.divider}
            />

            <Text
              style={
                styles.addressName
              }>
              {user?.name ||
                'FoodE User'}
            </Text>

            <Text
              style={
                styles.addressDetail
              }>
              {user?.phone ||
                'Phone number unavailable'}
            </Text>

            <Text
              style={
                styles.addressDetail
              }>
              SRM AP University,
              {' '}Gate Number 3
            </Text>

            <Text
              style={
                styles.addressDetail
              }>
              Neerukonda,
              {' '}Andhra Pradesh
            </Text>

            <View
              style={
                styles.fixedAddressBadge
              }>
              <Text
                style={
                  styles.fixedAddressBadgeText
                }>
                Fixed delivery location
              </Text>
            </View>
          </View>
        </View>

        {/* DELIVERY TIME */}

        <View
          style={styles.section}>
          <View
            style={
              styles.slotTitleRow
            }>
            <View
              style={
                styles.slotTitleContainer
              }>
              <Text
                style={
                  styles.sectionTitle
                }>
                Delivery Time
              </Text>

              <Text
                style={
                  styles.slotSubtitle
                }>
                Choose when you want your
                order delivered
              </Text>
            </View>

            {loadingSlots && (
              <ActivityIndicator
                size="small"
                color="#FF5A00"
              />
            )}
          </View>

          {/* LOADING */}

          {loadingSlots ? (
            <View
              style={
                styles.slotLoadingCard
              }>
              <ActivityIndicator
                size="small"
                color="#FF5A00"
              />

              <Text
                style={
                  styles.slotLoadingText
                }>
                Loading available
                delivery times...
              </Text>
            </View>
          ) : deliverySlots.length >
            0 ? (
            <View>
              {deliverySlots.map(
                slot => {
                  const isSelected =
                    selectedDeliverySlot?._id ===
                    slot._id;

                  const cutoffTime =
                    getSlotCutoffTime(
                      slot,
                    );

                  return (
                    <Pressable
                      key={slot._id}
                      style={[
                        styles.slotCard,
                        isSelected &&
                          styles.slotCardSelected,
                      ]}
                      onPress={() =>
                        handleSelectDeliverySlot(
                          slot,
                        )
                      }>

                      <View
                        style={
                          styles.slotIcon
                        }>
                        <Text
                          style={
                            styles.iconText
                          }>
                          🚴
                        </Text>
                      </View>

                      <View
                        style={
                          styles.slotInfo
                        }>

                        <Text
                          style={[
                            styles.etaText,
                            isSelected &&
                              styles.etaTextSelected,
                          ]}>
                          {getEtaLabel(
                            slot,
                          )}
                        </Text>

                        <Text
                          style={[
                            styles.slotTime,
                            isSelected &&
                              styles.slotTimeSelected,
                          ]}>
                          {getSlotLabel(
                            slot,
                          )}
                        </Text>

                        <Text
                          style={
                            styles.slotAvailableText
                          }>
                          Book until{' '}
                          {formatSlotTime(
                            cutoffTime,
                          )}
                        </Text>
                      </View>

                      <View
                        style={[
                          styles.slotRadio,
                          isSelected &&
                            styles.slotRadioSelected,
                        ]}>
                        {isSelected && (
                          <View
                            style={
                              styles.slotRadioDot
                            }
                          />
                        )}
                      </View>
                    </Pressable>
                  );
                },
              )}
            </View>
          ) : (
            <View
              style={
                styles.slotEmptyCard
              }>
              <Text
                style={
                  styles.slotEmptyIcon
                }>
                🕐
              </Text>

              <Text
                style={
                  styles.slotEmptyTitle
                }>
                No delivery slots
                available
              </Text>

              <Text
                style={
                  styles.slotEmptyText
                }>
                {slotError ||
                  'Please try again later.'}
              </Text>

              {restaurantId && (
                <Pressable
                  style={
                    styles.retryButton
                  }
                  onPress={() =>
                    loadDeliverySlots(
                      restaurantId,
                    )
                  }>
                  <Text
                    style={
                      styles.retryButtonText
                    }>
                    Try Again
                  </Text>
                </Pressable>
              )}
            </View>
          )}

          {/* SELECTED SLOT */}

          {selectedDeliverySlot && (
            <View
              style={
                styles.selectedSlotBadge
              }>
              <Text
                style={
                  styles.selectedSlotBadgeText
                }>
                ✓{' '}
                {getEtaLabel(
                  selectedDeliverySlot,
                )}
              </Text>

              <Text
                style={
                  styles.selectedSlotTime
                }>
                {getSlotLabel(
                  selectedDeliverySlot,
                )}
              </Text>
            </View>
          )}
        </View>

        {/* PAYMENT */}

        <View
          style={styles.section}>
          <Text
            style={
              styles.sectionTitle
            }>
            Payment Method
          </Text>

          <View
            style={styles.card}>
            <View
              style={
                styles.paymentRow
              }>
              <View
                style={
                  styles.paymentIcon
                }>
                <Text
                  style={
                    styles.iconText
                  }>
                  💵
                </Text>
              </View>

              <View
                style={
                  styles.paymentInfo
                }>
                <Text
                  style={
                    styles.paymentTitle
                  }>
                  Cash on Delivery
                </Text>

                <Text
                  style={
                    styles.paymentSubtitle
                  }>
                  Pay when your order
                  arrives
                </Text>
              </View>

              <View
                style={
                  styles.paymentRadio
                }>
                <View
                  style={
                    styles.paymentRadioDot
                  }
                />
              </View>
            </View>
          </View>
        </View>

        {/* ORDER ITEMS */}

        <View
          style={styles.section}>
          <Text
            style={
              styles.sectionTitle
            }>
            Order Items
          </Text>

          <View
            style={styles.card}>
            {items.map(
              (rawItem, index) => {
                const item =
                  rawItem as CheckoutCartItem;

                const quantity =
                  Number(
                    item.quantity || 1,
                  );

                const originalPrice =
                  Number(
                    item.price || 0,
                  );

                const discountedPrice =
                  item.discountedPrice !==
                    null &&
                  item.discountedPrice !==
                    undefined
                    ? Number(
                        item.discountedPrice,
                      )
                    : null;

                const price =
                  discountedPrice !==
                    null &&
                  Number.isFinite(
                    discountedPrice,
                  ) &&
                  discountedPrice >= 0
                    ? discountedPrice
                    : originalPrice;

                const itemTotal =
                  price * quantity;

                return (
                  <View
                    key={String(
                      item.foodId ||
                        item.id ||
                        item._id ||
                        index,
                    )}
                    style={[
                      styles.itemRow,
                      index ===
                        items.length - 1 &&
                        styles.lastItemRow,
                    ]}>

                    <View
                      style={
                        styles.itemLeft
                      }>
                      <View
                        style={
                          styles.quantityBadge
                        }>
                        <Text
                          style={
                            styles.quantityText
                          }>
                          {quantity}x
                        </Text>
                      </View>

                      <View
                        style={
                          styles.itemInfo
                        }>
                        <Text
                          style={
                            styles.itemName
                          }
                          numberOfLines={2}>
                          {item.name ||
                            'Food Item'}
                        </Text>

                        <Text
                          style={
                            styles.itemUnitPrice
                          }>
                          ₹
                          {price.toFixed(
                            2,
                          )}{' '}
                          each
                        </Text>
                      </View>
                    </View>

                    <Text
                      style={
                        styles.itemTotal
                      }>
                      ₹
                      {itemTotal.toFixed(
                        2,
                      )}
                    </Text>
                  </View>
                );
              },
            )}
          </View>
        </View>

        {/* PRICE DETAILS */}

        <View
          style={styles.section}>
          <Text
            style={
              styles.sectionTitle
            }>
            Price Details
          </Text>

          <View
            style={styles.card}>
            <View
              style={styles.priceRow}>
              <Text
                style={
                  styles.priceLabel
                }>
                Subtotal
              </Text>

              <Text
                style={
                  styles.priceValue
                }>
                ₹
                {Number(
                  subtotal || 0,
                ).toFixed(2)}
              </Text>
            </View>

            <View
              style={styles.priceRow}>
              <Text
                style={
                  styles.priceLabel
                }>
                Delivery Fee
              </Text>

              <Text
                style={
                  styles.priceValue
                }>
                ₹
                {Number(
                  deliveryFee || 0,
                ).toFixed(2)}
              </Text>
            </View>

            <View
              style={styles.divider}
            />

            <View
              style={styles.totalRow}>
              <Text
                style={
                  styles.totalLabel
                }>
                Total
              </Text>

              <Text
                style={
                  styles.totalValue
                }>
                ₹
                {grandTotal.toFixed(
                  2,
                )}
              </Text>
            </View>
          </View>
        </View>

        {/* PLACE ORDER */}

        <Pressable
          style={[
            styles.placeOrderButton,
            (
              isPlacingOrder ||
              loadingSlots ||
              !selectedDeliverySlot
            ) &&
              styles.placeOrderDisabled,
          ]}
          onPress={
            handlePlaceOrder
          }
          disabled={
            isPlacingOrder ||
            loadingSlots ||
            !selectedDeliverySlot
          }>

          {isPlacingOrder ? (
            <>
              <ActivityIndicator
                size="small"
                color="#FFFFFF"
              />

              <Text
                style={
                  styles.placeOrderText
                }>
                Placing Order...
              </Text>
            </>
          ) : (
            <Text
              style={
                styles.placeOrderText
              }>
              {!selectedDeliverySlot
                ? 'Select Delivery Time'
                : `Place Order • ₹${grandTotal.toFixed(
                    2,
                  )}`}
            </Text>
          )}
        </Pressable>

        <Text
          style={
            styles.footerNote
          }>
          Your order will be delivered
          to SRM AP University, Gate
          Number 3.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

// =====================================================
// STYLES
// =====================================================

const styles =
  StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: '#F7F7F7',
    },

    scrollContent: {
      paddingBottom: 40,
    },

    // ================================================
    // HEADER
    // ================================================

    header: {
      backgroundColor: '#FFFFFF',
      paddingHorizontal: 20,
      paddingTop: 18,
      paddingBottom: 18,
      borderBottomWidth: 1,
      borderBottomColor: '#EEEEEE',
    },

    headerTitle: {
      fontSize: 25,
      fontWeight: '800',
      color: '#111111',
    },

    headerSubtitle: {
      marginTop: 5,
      fontSize: 13,
      color: '#777777',
    },

    // ================================================
    // SECTION
    // ================================================

    section: {
      marginTop: 18,
      paddingHorizontal: 16,
    },

    sectionTitle: {
      fontSize: 18,
      fontWeight: '700',
      color: '#111111',
      marginBottom: 10,
    },

    // ================================================
    // CARD
    // ================================================

    card: {
      backgroundColor: '#FFFFFF',
      borderRadius: 14,
      padding: 16,
      borderWidth: 1,
      borderColor: '#EEEEEE',
    },

    // ================================================
    // ADDRESS
    // ================================================

    addressHeader: {
      flexDirection: 'row',
      alignItems: 'center',
    },

    locationIcon: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: '#FFF2EA',
      alignItems: 'center',
      justifyContent: 'center',
    },

    iconText: {
      fontSize: 20,
    },

    addressHeaderText: {
      flex: 1,
      marginLeft: 12,
    },

    addressTitle: {
      fontSize: 16,
      fontWeight: '700',
      color: '#111111',
    },

    addressSubtitle: {
      marginTop: 3,
      fontSize: 13,
      color: '#FF5A00',
      fontWeight: '600',
    },

    addressName: {
      fontSize: 15,
      fontWeight: '700',
      color: '#222222',
      marginBottom: 5,
    },

    addressDetail: {
      fontSize: 14,
      color: '#666666',
      lineHeight: 21,
    },

    fixedAddressBadge: {
      alignSelf: 'flex-start',
      marginTop: 12,
      paddingHorizontal: 10,
      paddingVertical: 6,
      borderRadius: 7,
      backgroundColor: '#F3F8F4',
    },

    fixedAddressBadgeText: {
      fontSize: 12,
      fontWeight: '600',
      color: '#3A7D44',
    },

    divider: {
      height: 1,
      backgroundColor: '#EEEEEE',
      marginVertical: 12,
    },

    // ================================================
    // DELIVERY SLOT
    // ================================================

    slotTitleRow: {
      flexDirection: 'row',
      alignItems: 'flex-start',
      justifyContent: 'space-between',
    },

    slotTitleContainer: {
      flex: 1,
      paddingRight: 12,
    },

    slotSubtitle: {
      marginTop: -5,
      marginBottom: 10,
      fontSize: 12,
      color: '#888888',
      lineHeight: 18,
    },

    slotLoadingCard: {
      minHeight: 80,
      backgroundColor: '#FFFFFF',
      borderRadius: 14,
      borderWidth: 1,
      borderColor: '#EEEEEE',
      alignItems: 'center',
      justifyContent: 'center',
      padding: 16,
      flexDirection: 'row',
    },

    slotLoadingText: {
      marginLeft: 10,
      fontSize: 13,
      color: '#777777',
    },

    slotCard: {
      minHeight: 82,
      backgroundColor: '#FFFFFF',
      borderRadius: 14,
      borderWidth: 1.5,
      borderColor: '#EEEEEE',
      paddingHorizontal: 14,
      paddingVertical: 12,
      flexDirection: 'row',
      alignItems: 'center',
      marginBottom: 10,
    },

    slotCardSelected: {
      borderColor: '#FF5A00',
      backgroundColor: '#FFF8F4',
    },

    slotIcon: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: '#FFF2EA',
      alignItems: 'center',
      justifyContent: 'center',
    },

    slotInfo: {
      flex: 1,
      marginLeft: 12,
    },

    etaText: {
      fontSize: 15,
      fontWeight: '800',
      color: '#FF5A00',
      marginBottom: 3,
    },

    etaTextSelected: {
      color: '#FF5A00',
    },

    slotTime: {
      fontSize: 13,
      fontWeight: '600',
      color: '#333333',
    },

    slotTimeSelected: {
      color: '#FF5A00',
    },

    slotAvailableText: {
      marginTop: 4,
      fontSize: 12,
      color: '#3A7D44',
      fontWeight: '600',
    },

    slotRadio: {
      width: 22,
      height: 22,
      borderRadius: 11,
      borderWidth: 2,
      borderColor: '#CCCCCC',
      alignItems: 'center',
      justifyContent: 'center',
      marginLeft: 10,
    },

    slotRadioSelected: {
      borderColor: '#FF5A00',
    },

    slotRadioDot: {
      width: 10,
      height: 10,
      borderRadius: 5,
      backgroundColor: '#FF5A00',
    },

    slotEmptyCard: {
      backgroundColor: '#FFFFFF',
      borderRadius: 14,
      borderWidth: 1,
      borderColor: '#EEEEEE',
      paddingHorizontal: 20,
      paddingVertical: 24,
      alignItems: 'center',
    },

    slotEmptyIcon: {
      fontSize: 30,
      marginBottom: 8,
    },

    slotEmptyTitle: {
      fontSize: 15,
      fontWeight: '700',
      color: '#222222',
      textAlign: 'center',
    },

    slotEmptyText: {
      marginTop: 6,
      fontSize: 12,
      lineHeight: 18,
      color: '#888888',
      textAlign: 'center',
    },

    retryButton: {
      marginTop: 14,
      paddingHorizontal: 18,
      paddingVertical: 9,
      borderRadius: 9,
      backgroundColor: '#FFF2EA',
    },

    retryButtonText: {
      fontSize: 13,
      fontWeight: '700',
      color: '#FF5A00',
    },

    selectedSlotBadge: {
      marginTop: 2,
      paddingHorizontal: 12,
      paddingVertical: 10,
      borderRadius: 9,
      backgroundColor: '#F3F8F4',
      borderWidth: 1,
      borderColor: '#DDEBDD',
    },

    selectedSlotBadgeText: {
      fontSize: 13,
      fontWeight: '800',
      color: '#3A7D44',
    },

    selectedSlotTime: {
      marginTop: 3,
      fontSize: 12,
      fontWeight: '600',
      color: '#5D765F',
    },

    // ================================================
    // PAYMENT
    // ================================================

    paymentRow: {
      flexDirection: 'row',
      alignItems: 'center',
    },

    paymentIcon: {
      width: 42,
      height: 42,
      borderRadius: 21,
      backgroundColor: '#F3F8F4',
      alignItems: 'center',
      justifyContent: 'center',
    },

    paymentInfo: {
      flex: 1,
      marginLeft: 12,
    },

    paymentTitle: {
      fontSize: 15,
      fontWeight: '700',
      color: '#111111',
    },

    paymentSubtitle: {
      marginTop: 4,
      fontSize: 13,
      color: '#777777',
    },

    paymentRadio: {
      width: 22,
      height: 22,
      borderRadius: 11,
      borderWidth: 2,
      borderColor: '#FF5A00',
      alignItems: 'center',
      justifyContent: 'center',
    },

    paymentRadioDot: {
      width: 10,
      height: 10,
      borderRadius: 5,
      backgroundColor: '#FF5A00',
    },

    // ================================================
    // ITEMS
    // ================================================

    itemRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      paddingVertical: 12,
      borderBottomWidth: 1,
      borderBottomColor: '#EEEEEE',
    },

    lastItemRow: {
      borderBottomWidth: 0,
    },

    itemLeft: {
      flex: 1,
      flexDirection: 'row',
      alignItems: 'center',
      paddingRight: 12,
    },

    quantityBadge: {
      minWidth: 38,
      height: 30,
      borderRadius: 8,
      backgroundColor: '#FFF2EA',
      alignItems: 'center',
      justifyContent: 'center',
    },

    quantityText: {
      fontSize: 12,
      fontWeight: '700',
      color: '#FF5A00',
    },

    itemInfo: {
      flex: 1,
      marginLeft: 10,
    },

    itemName: {
      fontSize: 14,
      fontWeight: '600',
      color: '#222222',
    },

    itemUnitPrice: {
      marginTop: 4,
      fontSize: 12,
      color: '#888888',
    },

    itemTotal: {
      fontSize: 14,
      fontWeight: '700',
      color: '#111111',
    },

    // ================================================
    // PRICE
    // ================================================

    priceRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginBottom: 13,
    },

    priceLabel: {
      fontSize: 14,
      color: '#666666',
    },

    priceValue: {
      fontSize: 14,
      fontWeight: '600',
      color: '#222222',
    },

    totalRow: {
      flexDirection: 'row',
      alignItems: 'center',
      justifyContent: 'space-between',
      marginTop: 8,
    },

    totalLabel: {
      fontSize: 18,
      fontWeight: '800',
      color: '#111111',
    },

    totalValue: {
      fontSize: 20,
      fontWeight: '800',
      color: '#FF5A00',
    },

    // ================================================
    // PLACE ORDER
    // ================================================

    placeOrderButton: {
      marginHorizontal: 16,
      marginTop: 25,
      minHeight: 56,
      borderRadius: 14,
      backgroundColor: '#FF5A00',
      alignItems: 'center',
      justifyContent: 'center',
      flexDirection: 'row',
      paddingHorizontal: 18,
    },

    placeOrderDisabled: {
      opacity: 0.55,
    },

    placeOrderText: {
      fontSize: 16,
      fontWeight: '800',
      color: '#FFFFFF',
      textAlign: 'center',
      marginLeft: 8,
    },

    // ================================================
    // FOOTER
    // ================================================

    footerNote: {
      marginHorizontal: 30,
      marginTop: 12,
      textAlign: 'center',
      fontSize: 12,
      lineHeight: 18,
      color: '#888888',
    },

    // ================================================
    // CENTER STATES
    // ================================================

    centerContainer: {
      flex: 1,
      alignItems: 'center',
      justifyContent: 'center',
      paddingHorizontal: 30,
    },

    centerTitle: {
      fontSize: 24,
      fontWeight: '800',
      color: '#111111',
      textAlign: 'center',
    },

    centerDescription: {
      marginTop: 8,
      marginBottom: 25,
      fontSize: 15,
      lineHeight: 22,
      color: '#666666',
      textAlign: 'center',
    },

    primaryButton: {
      paddingHorizontal: 30,
      paddingVertical: 13,
      borderRadius: 10,
      backgroundColor: '#FF5A00',
    },

    primaryButtonText: {
      fontSize: 15,
      fontWeight: '700',
      color: '#FFFFFF',
    },
  });

export default CheckoutScreen;
