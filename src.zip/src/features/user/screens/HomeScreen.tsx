import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';

import {
  ActivityIndicator,
  Animated,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import {SafeAreaView} from 'react-native-safe-area-context';

import {
  ForkKnife,
  Storefront,
  Warning,
  Sparkle,
} from 'phosphor-react-native';

import {
  CompositeNavigationProp,
  useNavigation,
} from '@react-navigation/native';

import {
  NativeStackNavigationProp,
} from '@react-navigation/native-stack';

import {
  BottomTabNavigationProp,
} from '@react-navigation/bottom-tabs';

import {
  RootStackParamList,
} from '../../../navigation/AppNavigator';

import {
  BottomTabParamList,
} from '../../../navigation/BottomTabNavigator';

import Header from '../components/home/header/Header';

import SearchBar from '../components/home/header/SearchBar';

import BannerCarousel from '../components/home/banner/BannerCarousel';

import CategorySection from '../components/home/category/CategorySection';

import FoodList from '../components/home/food/FoodList';

import {
  Food,
  getAllFoods,
} from '../../restaurant/services/foodService';

import RestaurantList from '../components/home/restaurant/RestaurantList';

import {
  Restaurant,
} from '../components/home/restaurant/restaurantData';

import {
  getRestaurants,
} from '../services/restaurantService';

import AboutFoodE from '../components/home/AboutFoodE';

// =====================================================
// NAVIGATION TYPE
// =====================================================

type NavigationProp =
  CompositeNavigationProp<
    BottomTabNavigationProp<
      BottomTabParamList,
      'Home'
    >,
    NativeStackNavigationProp<
      RootStackParamList
    >
  >;

// =====================================================
// HEADER SPARKLE ANIMATION
// =====================================================

const AnimatedSparkle: React.FC = () => {
  const scale = useRef(
    new Animated.Value(0.82),
  ).current;

  const opacity = useRef(
    new Animated.Value(0.55),
  ).current;

  useEffect(() => {
    const animation = Animated.loop(
      Animated.parallel([
        Animated.sequence([
          Animated.timing(scale, {
            toValue: 1.12,
            duration: 900,
            useNativeDriver: true,
          }),
          Animated.timing(scale, {
            toValue: 0.82,
            duration: 900,
            useNativeDriver: true,
          }),
        ]),
        Animated.sequence([
          Animated.timing(opacity, {
            toValue: 1,
            duration: 900,
            useNativeDriver: true,
          }),
          Animated.timing(opacity, {
            toValue: 0.55,
            duration: 900,
            useNativeDriver: true,
          }),
        ]),
      ]),
    );

    animation.start();

    return () => {
      animation.stop();
    };
  }, [opacity, scale]);

  return (
    <Animated.View
      pointerEvents="none"
      style={[
        styles.headerSparkle,
        {
          transform: [{scale}],
          opacity,
        },
      ]}>
      <Sparkle
        size={21}
        color="#FF7A00"
        weight="fill"
      />
    </Animated.View>
  );
};

// =====================================================
// HOME SCREEN
// =====================================================

const HomeScreen: React.FC = () => {
  const navigation =
    useNavigation<NavigationProp>();

  // ===================================================
  // RESTAURANTS
  // ===================================================

  const [
    restaurants,
    setRestaurants,
  ] = useState<Restaurant[]>([]);

  const [
    loadingRestaurants,
    setLoadingRestaurants,
  ] = useState(true);

  const [
    restaurantError,
    setRestaurantError,
  ] = useState<string | null>(null);

  // ===================================================
  // FOODS
  // ===================================================

  const [
    foods,
    setFoods,
  ] = useState<Food[]>([]);

  const [
    loadingFoods,
    setLoadingFoods,
  ] = useState(true);

  const [
    foodError,
    setFoodError,
  ] = useState<string | null>(null);

  // ===================================================
  // REFRESH
  // ===================================================

  const [
    refreshing,
    setRefreshing,
  ] = useState(false);

  // ===================================================
  // LOAD RESTAURANTS
  // ===================================================

  const loadRestaurants =
    useCallback(async () => {
      try {
        setRestaurantError(null);

        const data =
          await getRestaurants();

        const formattedRestaurants: Restaurant[] =
          data.map(restaurant => {
            const raw =
              restaurant as Restaurant & {
                coverImage?: unknown;
                logo?: unknown;
                image?: unknown;
                imageUrl?: unknown;
                images?: {
                  coverImage?: unknown;
                  logo?: unknown;
                  image?: unknown;
                };
                cuisine?: unknown;
                cuisines?: unknown;
              };

            const getImageUrl = (
              value: unknown,
            ): string => {
              if (typeof value === 'string') {
                return value.trim();
              }

              if (
                value &&
                typeof value === 'object'
              ) {
                const imageObject =
                  value as {
                    url?: unknown;
                    uri?: unknown;
                  };

                if (
                  typeof imageObject.url ===
                  'string'
                ) {
                  return imageObject.url.trim();
                }

                if (
                  typeof imageObject.uri ===
                  'string'
                ) {
                  return imageObject.uri.trim();
                }
              }

              return '';
            };

            const restaurantImage =
              getImageUrl(
                raw.coverImage,
              ) ||
              getImageUrl(
                raw.images?.coverImage,
              ) ||
              getImageUrl(
                raw.image,
              ) ||
              getImageUrl(
                raw.imageUrl,
              ) ||
              getImageUrl(
                raw.images?.image,
              ) ||
              getImageUrl(
                raw.logo,
              ) ||
              getImageUrl(
                raw.images?.logo,
              );

            const rawCuisine =
              raw.cuisine ??
              raw.cuisines;

            const cuisineText =
              Array.isArray(rawCuisine)
                ? rawCuisine
                    .filter(Boolean)
                    .join(' • ')
                : typeof rawCuisine ===
                  'string'
                ? rawCuisine
                : 'Multi Cuisine';

            return {
              ...restaurant,

              _id: restaurant._id,

              image: restaurantImage,

              coverImage:
                getImageUrl(
                  raw.coverImage,
                ) ||
                getImageUrl(
                  raw.images?.coverImage,
                ) ||
                restaurantImage,

              logo:
                getImageUrl(
                  raw.logo,
                ) ||
                getImageUrl(
                  raw.images?.logo,
                ),

              cuisine: cuisineText,

              cuisines: cuisineText,

              rating:
                typeof restaurant.rating ===
                'number'
                  ? restaurant.rating
                  : 0,

              deliveryTime:
                restaurant.deliveryTime ||
                '20-30 min',

              address:
                restaurant.address ||
                (restaurant as any)
                  .location ||
                'SRM AP University, Neerukonda',

              isOpen:
                restaurant.isOpen !== false,

              isActive:
                restaurant.isActive !== false,
            } as Restaurant;
          });

        setRestaurants(
          formattedRestaurants,
        );
      } catch (error: any) {
        console.log(
          'Home restaurant error:',
          error,
        );

        setRestaurantError(
          error?.message ||
            'Unable to load restaurants.',
        );
      } finally {
        setLoadingRestaurants(false);
      }
    }, []);

  // ===================================================
  // LOAD FOODS
  // ===================================================

  const loadFoods =
    useCallback(async () => {
      try {
        setFoodError(null);

        const data =
          await getAllFoods();

        setFoods(data);
      } catch (error: any) {
        console.log(
          'Home food error:',
          error,
        );

        setFoodError(
          error?.message ||
            'Unable to load foods.',
        );
      } finally {
        setLoadingFoods(false);
      }
    }, []);

  // ===================================================
  // INITIAL LOAD
  // ===================================================

  useEffect(() => {
    loadRestaurants();
    loadFoods();
  }, [
    loadRestaurants,
    loadFoods,
  ]);

  // ===================================================
  // REFRESH
  // ===================================================

  const onRefresh =
    useCallback(async () => {
      setRefreshing(true);

      try {
        await Promise.all([
          loadRestaurants(),
          loadFoods(),
        ]);
      } finally {
        setRefreshing(false);
      }
    }, [
      loadRestaurants,
      loadFoods,
    ]);

  // ===================================================
  // UNDER 20 MINUTES
  // ===================================================

  const under20Minutes =
    useMemo(() => {
      return foods.filter(
        food =>
          food.isAvailable === true &&
          typeof food.preparationTime ===
            'number' &&
          food.preparationTime <= 20,
      );
    }, [foods]);

  // ===================================================
  // NON-VEG PICKS
  // ===================================================

  const nonVegPicks =
    useMemo(() => {
      return foods.filter(
        food =>
          food.isAvailable === true &&
          (
            food.foodType ===
              'non-veg' ||
            (
              food.foodType ===
                undefined &&
              food.isVegetarian ===
                false
            )
          ),
      );
    }, [foods]);

  // ===================================================
  // VEG PICKS
  // ===================================================

  const vegPicks =
    useMemo(() => {
      return foods.filter(
        food =>
          food.isAvailable === true &&
          (
            food.foodType ===
              'veg' ||
            food.isVegetarian ===
              true
          ),
      );
    }, [foods]);

  // ===================================================
  // TOP RATED RESTAURANTS
  // ===================================================

  const topRatedRestaurants =
    useMemo(() => {
      return [...restaurants].sort(
        (a, b) =>
          (b.rating || 0) -
          (a.rating || 0),
      );
    }, [restaurants]);

  // ===================================================
  // FIND RESTAURANT FROM FOOD
  // ===================================================

  const handleOpenRestaurantFromFood =
    (food: Food) => {
      console.log(
        'Opening restaurant for:',
        food.name,
      );

      const restaurantRef =
        food.restaurant as any;

      let restaurantId:
        | string
        | undefined;

      // ===============================================
      // RESTAURANT OBJECT
      // ===============================================

      if (
        restaurantRef &&
        typeof restaurantRef ===
          'object'
      ) {
        restaurantId =
          restaurantRef._id;
      }

      // ===============================================
      // RESTAURANT STRING
      // ===============================================

      if (
        typeof restaurantRef ===
        'string'
      ) {
        restaurantId =
          restaurantRef;
      }

      // ===============================================
      // FIND RESTAURANT
      // ===============================================

      let restaurant =
        restaurants.find(
          item =>
            item._id ===
            restaurantId,
        );

      // ===============================================
      // FALLBACK BY NAME
      // ===============================================

      if (
        !restaurant &&
        restaurantRef &&
        typeof restaurantRef ===
          'object'
      ) {
        restaurant =
          restaurants.find(
            item =>
              item.name ===
              restaurantRef.name,
          );
      }

      // ===============================================
      // NAVIGATE
      // ===============================================

      if (restaurant) {
        navigation.navigate(
          'RestaurantDetails',
          {
            restaurant,
          },
        );

        return;
      }

      console.log(
        'Restaurant not found for food:',
        food.name,
        restaurantRef,
      );
    };

  // ===================================================
  // FOOD PRESS
  // ===================================================

  const handleFoodPress = (
    food: Food,
  ) => {
    handleOpenRestaurantFromFood(
      food,
    );
  };

  // ===================================================
  // RETRY FOODS
  // ===================================================

  const handleRetryFoods = () => {
    setLoadingFoods(true);

    loadFoods();
  };

  // ===================================================
  // RETRY RESTAURANTS
  // ===================================================

  const handleRetryRestaurants =
    () => {
      setLoadingRestaurants(true);

      loadRestaurants();
    };

  // ===================================================
  // RENDER
  // ===================================================

  return (
    <SafeAreaView
      style={styles.container}
      edges={['top', 'left', 'right']}>

      {/* =================================================
          STATUS BAR
      ================================================= */}

      <StatusBar
        barStyle="dark-content"
        backgroundColor="#FFFFFF"
      />

      {/* ======= ==========================================
          SCROLL
      ================================================= */}

      <ScrollView
        showsVerticalScrollIndicator={
          false
        }
        bounces
        contentContainerStyle={
          styles.scrollContent
        }
        refreshControl={
          <RefreshControl
            refreshing={
              refreshing
            }
            onRefresh={
              onRefresh
            }
            colors={[
              '#FF7A00',
            ]}
            tintColor="#FF7A00"
          />
        }>

        {/* =================================================
            HEADER
        ================================================= */}

        <View
          style={
            styles.headerContainer
          }>

          <Header />

        </View>

        {/* =================================================
            SEARCH
        ================================================= */}

        <View
          style={
            styles.searchContainer
          }>

          <SearchBar
            onPress={() =>
              navigation.navigate(
                'Search',
              )
            }
          />

        </View>

        {/* =================================================
            BANNER
        ================================================= */}

        <BannerCarousel />

        {/* =================================================
            CATEGORIES
        ================================================= */}

        <CategorySection />

        {/* =================================================
            FOOD SECTIONS
        ================================================= */}

        {loadingFoods ? (
          <View
            style={
              styles.foodLoading
            }>

            <ActivityIndicator
              size="small"
              color="#FF7A00"
            />

            <Text
              style={
                styles.loadingText
              }>
              Loading foods...
            </Text>

          </View>
        ) : foodError ? (
          <View
            style={
              styles.foodState
            }>

            <View style={styles.stateIcon}>
              <Warning
                size={30}
                color="#FF7A00"
                weight="duotone"
              />
            </View>

            <Text
              style={
                styles.stateTitle
              }>
              Unable to load foods
            </Text>

            <Text
              style={
                styles.stateText
              }>
              {foodError}
            </Text>

            <TouchableOpacity
              activeOpacity={0.8}
              style={
                styles.retryButton
              }
              onPress={
                handleRetryFoods
              }>

              <Text
                style={
                  styles.retryText
                }>
                Retry
              </Text>

            </TouchableOpacity>

          </View>
        ) : (
          <>
            {/* =========================================
                UNDER 20 MINUTES
            ========================================= */}

            {under20Minutes.length >
              0 && (
              <View style={styles.foodSectionWrapper}>
                <FoodList
                  title="Under 20 Minutes"
                  data={
                    under20Minutes
                  }
                  accentColor="#F59E0B"
                  onFoodPress={
                    handleFoodPress
                  }
                  onAddPress={
                    handleOpenRestaurantFromFood
                  }
                />
                <AnimatedSparkle />
              </View>
            )}

            {/* =========================================
                NON VEG
            ========================================= */}

            {nonVegPicks.length >
              0 && (
              <View style={styles.foodSectionWrapper}>
                <FoodList
                  title="Non-Veg Picks"
                  data={
                    nonVegPicks
                  }
                  accentColor="#B91C1C"
                  onFoodPress={
                    handleFoodPress
                  }
                  onAddPress={
                    handleOpenRestaurantFromFood
                  }
                />
                <AnimatedSparkle />
              </View>
            )}

            {/* =========================================
                VEG
            ========================================= */}

            {vegPicks.length >
              0 && (
              <View style={styles.foodSectionWrapper}>
                <FoodList
                  title="Veg Picks"
                  data={
                    vegPicks
                  }
                  accentColor="#16A34A"
                  onFoodPress={
                    handleFoodPress
                  }
                  onAddPress={
                    handleOpenRestaurantFromFood
                  }
                />
                <AnimatedSparkle />
              </View>
            )}
          </>
        )}

        {/* =================================================
            RESTAURANTS
        ================================================= */}

        {loadingRestaurants ? (
          <View
            style={
              styles.restaurantLoading
            }>

            <ActivityIndicator
              size="small"
              color="#FF7A00"
            />

            <Text
              style={
                styles.loadingText
              }>
              Loading restaurants...
            </Text>

          </View>
        ) : restaurantError ? (
          <View
            style={
              styles.restaurantState
            }>

            <View style={styles.stateIcon}>
              <Storefront
                size={30}
                color="#FF7A00"
                weight="duotone"
              />
            </View>

            <Text
              style={
                styles.stateTitle
              }>
              Unable to load restaurants
            </Text>

            <Text
              style={
                styles.stateText
              }>
              {restaurantError}
            </Text>

            <TouchableOpacity
              activeOpacity={0.8}
              style={
                styles.retryButton
              }
              onPress={
                handleRetryRestaurants
              }>

              <Text
                style={
                  styles.retryText
                }>
                Retry
              </Text>

            </TouchableOpacity>

          </View>
        ) : restaurants.length ===
          0 ? (
          <View
            style={
              styles.restaurantState
            }>

            <View style={styles.stateIcon}>
              <Storefront
                size={30}
                color="#FF7A00"
                weight="duotone"
              />
            </View>

            <Text
              style={
                styles.stateTitle
              }>
              No restaurants yet
            </Text>

            <Text
              style={
                styles.stateText
              }>
              Restaurants will appear here
              when they are created.
            </Text>

          </View>
        ) : (
          <RestaurantList
            title="Restaurants"
            data={
              topRatedRestaurants
            }
            onRestaurantPress={
              restaurant =>
                navigation.navigate(
                  'RestaurantDetails',
                  {
                    restaurant,
                  },
                )
            }
          />
        )}

        {/* =================================================
            ABOUT FOOD-E
        ================================================= */}

        <AboutFoodE />

        {/* =================================================
            BOTTOM SPACE
        ================================================= */}

        <View
          style={
            styles.bottomSpacing
          }
        />

      </ScrollView>

    </SafeAreaView>
  );
};

export default HomeScreen;

// =====================================================
// STYLES
// =====================================================

const styles =
  StyleSheet.create({

    // =================================================
    // CONTAINER
    // =================================================

    container: {
      flex: 1,

      backgroundColor: '#F7F8FA',
    },

    scrollContent: {
      paddingBottom: 32,
    },

    // =================================================
    // HEADER
    // =================================================

    headerContainer: {
      backgroundColor: '#FFFFFF',

      paddingTop: 0,

      paddingBottom: 0,

      borderBottomLeftRadius: 24,

      borderBottomRightRadius: 24,

      overflow: 'hidden',

      shadowColor: '#000',

      shadowOffset: {
        width: 0,
        height: 3,
      },

      shadowOpacity: 0.06,

      shadowRadius: 8,

      elevation: 4,
    },

    // =================================================
    // SEARCH
    // =================================================

    searchContainer: {
      backgroundColor: '#F7F8FA',

      paddingTop: 2,

      paddingBottom: 4,
    },

    // =================================================
    // FOOD SECTION
    // =================================================

    foodSectionWrapper: {
      position: 'relative',
    },

    headerSparkle: {
      position: 'absolute',
      top: 14,
      right: 24,
      width: 28,
      height: 28,
      alignItems: 'center',
      justifyContent: 'center',
    },

    // =================================================
    // FOOD LOADING
    // =================================================

    foodLoading: {
      minHeight: 110,

      alignItems: 'center',

      justifyContent: 'center',
    },

    loadingText: {
      marginTop: 8,

      fontSize: 12,

      color: '#888888',
    },

    // =================================================
    // FOOD ERROR
    // =================================================

    foodState: {
      marginHorizontal: 20,

      marginVertical: 15,

      paddingVertical: 30,

      paddingHorizontal: 20,

      backgroundColor: '#FFFFFF',

      borderRadius: 18,

      alignItems: 'center',
    },

    // =================================================
    // RESTAURANT LOADING
    // =================================================

    restaurantLoading: {
      minHeight: 110,

      alignItems: 'center',

      justifyContent: 'center',
    },

    // =================================================
    // RESTAURANT STATE
    // =================================================

    restaurantState: {
      marginHorizontal: 20,

      marginVertical: 15,

      paddingVertical: 30,

      paddingHorizontal: 20,

      backgroundColor: '#FFFFFF',

      borderRadius: 18,

      alignItems: 'center',
    },

    // =================================================
    // STATE ICON
    // =================================================

    stateIcon: {
      width: 44,
      height: 44,
      alignItems: 'center',
      justifyContent: 'center',
      marginBottom: 8,
    },

    // =================================================
    // STATE TITLE
    // =================================================

    stateTitle: {
      fontSize: 15,

      fontWeight: '700',

      color: '#17171B',

      textAlign: 'center',
    },

    // =================================================
    // STATE TEXT
    // =================================================

    stateText: {
      marginTop: 6,

      fontSize: 12,

      lineHeight: 18,

      color: '#888888',

      textAlign: 'center',
    },

    // =================================================
    // RETRY
    // =================================================

    retryButton: {
      marginTop: 16,

      paddingHorizontal: 24,

      paddingVertical: 9,

      borderRadius: 12,

      backgroundColor: '#FF7A00',
    },

    retryText: {
      color: '#FFFFFF',

      fontSize: 13,

      fontWeight: '700',
    },

    // =================================================
    // BOTTOM SPACE
    // =================================================

    bottomSpacing: {
      height: 120,
    },
  });