import React from 'react';
import {
  View,
  Text,
  StyleSheet,
} from 'react-native';

import Ionicons from '@react-native-vector-icons/ionicons/static';

const EmptyOrders = () => {
  return (
    <View style={styles.container}>

      <Ionicons
        name="receipt-outline"
        size={90}
        color="#D1D5DB"
      />

      <Text style={styles.title}>
        No Orders Yet
      </Text>

      <Text style={styles.subtitle}>
        Looks like you haven't ordered
        anything yet.
      </Text>

    </View>
  );
};

export default EmptyOrders;

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 40,
    paddingTop: 120,
  },

  title: {
    marginTop: 18,
    fontSize: 22,
    fontWeight: '700',
    color: '#111827',
  },

  subtitle: {
    marginTop: 10,
    fontSize: 15,
    color: '#6B7280',
    textAlign: 'center',
    lineHeight: 22,
  },
});
