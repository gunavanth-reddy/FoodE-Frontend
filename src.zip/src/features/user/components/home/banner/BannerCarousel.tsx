import React, {
  useCallback,
  useEffect,
  useRef,
  useState,
} from 'react';

import {
  Animated,
  Dimensions,
  FlatList,
  NativeScrollEvent,
  NativeSyntheticEvent,
  StyleSheet,
  View,
} from 'react-native';

import BannerCard from './BannerCard';

const {width} = Dimensions.get('window');

const AUTO_SCROLL_INTERVAL = 3500;

// =====================================================
// BANNER DATA
// =====================================================

const bannerData = [
  {
    id: 'banner1',
    image: require('../../../../../assets/images/categories/banner1.png'),
  },
  {
    id: 'banner2',
    image: require('../../../../../assets/images/categories/banner2.png'),
  },
  {
    id: 'banner3',
    image: require('../../../../../assets/images/categories/banner3.png'),
  },
  {
    id: 'banner4',
    image: require('../../../../../assets/images/categories/banner4.png'),
  },
];

// =====================================================
// COMPONENT
// =====================================================

const BannerCarousel: React.FC = () => {
  const flatListRef = useRef<FlatList>(null);

  const scrollX = useRef(
    new Animated.Value(0),
  ).current;

  const currentIndex = useRef(0);

  const [activeIndex, setActiveIndex] =
    useState(0);

  const timer = useRef<
    ReturnType<typeof setInterval> | null
  >(null);

  // =====================================================
  // STOP AUTO SCROLL
  // =====================================================

  const stopAutoScroll = useCallback(() => {
    if (timer.current !== null) {
      clearInterval(timer.current);
      timer.current = null;
    }
  }, []);

  // =====================================================
  // START AUTO SCROLL
  // =====================================================

  const startAutoScroll = useCallback(() => {
    stopAutoScroll();

    if (bannerData.length <= 1) {
      return;
    }

    timer.current = setInterval(() => {
      let nextIndex =
        currentIndex.current + 1;

      if (nextIndex >= bannerData.length) {
        nextIndex = 0;
      }

      currentIndex.current = nextIndex;
      setActiveIndex(nextIndex);

      flatListRef.current?.scrollToIndex({
        index: nextIndex,
        animated: true,
      });
    }, AUTO_SCROLL_INTERVAL);
  }, [stopAutoScroll]);

  // =====================================================
  // AUTO SCROLL LIFECYCLE
  // =====================================================

  useEffect(() => {
    startAutoScroll();

    return () => {
      stopAutoScroll();
    };
  }, [startAutoScroll, stopAutoScroll]);

  // =====================================================
  // MOMENTUM SCROLL
  // =====================================================

  const onMomentumScrollEnd = (
    event: NativeSyntheticEvent<NativeScrollEvent>,
  ) => {
    const offsetX =
      event.nativeEvent.contentOffset.x;

    const index = Math.round(
      offsetX / width,
    );

    const safeIndex = Math.max(
      0,
      Math.min(
        index,
        bannerData.length - 1,
      ),
    );

    currentIndex.current = safeIndex;
    setActiveIndex(safeIndex);

    startAutoScroll();
  };

  // =====================================================
  // RENDER
  // =====================================================

  return (
    <View style={styles.container}>
      <Animated.FlatList
        ref={flatListRef}
        data={bannerData}
        horizontal
        pagingEnabled
        bounces={false}
        showsHorizontalScrollIndicator={false}
        decelerationRate="fast"
        keyExtractor={item => item.id}
        renderItem={({item}) => (
          <BannerCard image={item.image} />
        )}
        onScrollBeginDrag={stopAutoScroll}
        onMomentumScrollEnd={
          onMomentumScrollEnd
        }
        scrollEventThrottle={16}
        onScroll={Animated.event(
          [
            {
              nativeEvent: {
                contentOffset: {
                  x: scrollX,
                },
              },
            },
          ],
          {
            useNativeDriver: false,
          },
        )}
        getItemLayout={(_, index) => ({
          length: width,
          offset: width * index,
          index,
        })}
        onScrollToIndexFailed={info => {
          setTimeout(() => {
            flatListRef.current?.scrollToIndex({
              index: info.index,
              animated: true,
            });
          }, 300);
        }}
      />

      {/* PAGINATION DOTS */}

      {bannerData.length > 1 && (
        <View style={styles.pagination}>
          {bannerData.map((item, index) => (
            <View
              key={item.id}
              style={[
                styles.dot,
                index === activeIndex &&
                  styles.activeDot,
              ]}
            />
          ))}
        </View>
      )}
    </View>
  );
};

export default BannerCarousel;

// =====================================================
// STYLES
// =====================================================

const styles = StyleSheet.create({
  container: {
    width: '100%',
    position: 'relative',
    marginBottom: 8,
  },

  pagination: {
    position: 'absolute',
    bottom: 10,
    left: 0,
    right: 0,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
  },

  dot: {
    width: 6,
    height: 6,
    borderRadius: 3,
    marginHorizontal: 3,
    backgroundColor:
      'rgba(255,255,255,0.55)',
  },

  activeDot: {
    width: 18,
    backgroundColor: '#FFFFFF',
  },
});