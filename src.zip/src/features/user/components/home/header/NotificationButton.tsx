import React from 'react';
import {
  TouchableOpacity,
  View,
  StyleSheet,
} from 'react-native';

import {
  Bell,
} from 'phosphor-react-native';

import {useNavigation} from '@react-navigation/native';
import {NativeStackNavigationProp} from '@react-navigation/native-stack';

import {RootStackParamList} from '../../../../../navigation/AppNavigator';

type NavigationProp =
  NativeStackNavigationProp<RootStackParamList>;

const NotificationButton = () => {
  const navigation = useNavigation<NavigationProp>();

  return (
    <TouchableOpacity
      activeOpacity={0.8}
      style={styles.container}
      onPress={() =>
        navigation.navigate('Notifications')
      }>

      <Bell
        size={24}
        color="#222222"
        weight="regular"
      />

      {/* Notification Badge */}
      <View style={styles.badge} />

    </TouchableOpacity>
  );
};

export default NotificationButton;

const styles = StyleSheet.create({
  container: {
    width: 48,
    height: 48,
    borderRadius: 24,

    backgroundColor: '#FFFFFF',

    justifyContent: 'center',
    alignItems: 'center',

    elevation: 4,

    shadowColor: '#000',
    shadowOpacity: 0.08,
    shadowRadius: 8,
    shadowOffset: {
      width: 0,
      height: 3,
    },
  },

  badge: {
    position: 'absolute',
    top: 10,
    right: 12,

    width: 10,
    height: 10,
    borderRadius: 5,

    backgroundColor: '#FF3B30',

    borderWidth: 2,
    borderColor: '#FFFFFF',
  },
});