import React from 'react';
import {
  StyleSheet,
  Text,
  View,
  TouchableOpacity,
} from 'react-native';

import {SafeAreaView} from 'react-native-safe-area-context';

import {
  MapPin,
  UserCircle,
} from 'phosphor-react-native';

import {
  useNavigation,
  CompositeNavigationProp,
} from '@react-navigation/native';

import {
  BottomTabNavigationProp,
} from '@react-navigation/bottom-tabs';

import {
  NativeStackNavigationProp,
} from '@react-navigation/native-stack';

import NotificationButton from './NotificationButton';

import {
  BottomTabParamList,
} from '../../../../../navigation/BottomTabNavigator';

import {
  RootStackParamList,
} from '../../../../../navigation/AppNavigator';


// =====================================================
// NAVIGATION TYPE
// =====================================================

type HeaderNavigationProp = CompositeNavigationProp<
  BottomTabNavigationProp<BottomTabParamList>,
  NativeStackNavigationProp<RootStackParamList>
>;


// =====================================================
// HEADER
// =====================================================

const Header: React.FC = () => {
  const navigation =
    useNavigation<HeaderNavigationProp>();


  // ===================================================
  // PROFILE PRESS
  // ===================================================

  const handleProfilePress = () => {
    navigation.navigate('Profile');
  };


  return (
    <SafeAreaView
      style={styles.safeArea}
      edges={['top']}>

      <View style={styles.header}>

        {/* ===========================================
            LOCATION
        =========================================== */}

        <View style={styles.locationSection}>

          <View style={styles.locationIcon}>
            <MapPin
              size={21}
              color="#FF7A00"
              weight="fill"
            />
          </View>

          <View style={styles.locationText}>

            <Text
              style={styles.locationName}
              numberOfLines={1}>
              SRM AP University
            </Text>

            <Text style={styles.locationArea}>
              Neerukonda
            </Text>

          </View>

        </View>


        {/* ===========================================
            ACTIONS
        =========================================== */}

        <View style={styles.actions}>

          {/* Notification */}

          <NotificationButton />


          {/* Profile */}

          <TouchableOpacity
            activeOpacity={0.8}
            style={styles.profileButton}
            onPress={handleProfilePress}>

            <UserCircle
              size={22}
              color="#172033"
              weight="regular"
            />

          </TouchableOpacity>

        </View>

      </View>

    </SafeAreaView>
  );
};

export default Header;


// =====================================================
// STYLES
// =====================================================

const styles = StyleSheet.create({

  safeArea: {
    backgroundColor: '#FFFFFF',
  },


  header: {
    height: 74,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',

    paddingHorizontal: 18,

    backgroundColor: '#FFFFFF',

    borderBottomLeftRadius: 22,
    borderBottomRightRadius: 22,

    shadowColor: '#000',

    shadowOpacity: 0.06,

    shadowRadius: 8,

    shadowOffset: {
      width: 0,
      height: 3,
    },

    elevation: 3,
  },


  // ===================================================
  // LOCATION
  // ===================================================

  locationSection: {
    flex: 1,

    flexDirection: 'row',
    alignItems: 'center',

    marginRight: 10,
  },


  locationIcon: {
    width: 40,
    height: 40,

    borderRadius: 20,

    backgroundColor: '#FFF4E8',

    alignItems: 'center',
    justifyContent: 'center',

    marginRight: 10,
  },


  locationText: {
    flex: 1,

    justifyContent: 'center',
  },


  locationName: {
    fontSize: 17,

    fontWeight: '800',

    color: '#172033',

    lineHeight: 21,
  },


  locationArea: {
    marginTop: 2,

    fontSize: 12,

    fontWeight: '500',

    color: '#8A8F98',
  },


  // ===================================================
  // ACTIONS
  // ===================================================

  actions: {
    flexDirection: 'row',

    alignItems: 'center',
  },


  profileButton: {
    width: 42,
    height: 42,

    borderRadius: 21,

    marginLeft: 8,

    backgroundColor: '#F7F8FA',

    alignItems: 'center',
    justifyContent: 'center',
  },

});