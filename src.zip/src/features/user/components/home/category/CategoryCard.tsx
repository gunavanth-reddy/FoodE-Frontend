import React from 'react';
import {
  Image,
  ImageSourcePropType,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';

interface Props {
  item: {
    id: string;
    name: string;
    image: ImageSourcePropType;
  };
  selected: boolean;
  onPress: () => void;
}

const CategoryCard: React.FC<Props> = ({
  item,
  selected,
  onPress,
}) => {
  return (
    <Pressable
      onPress={onPress}
      style={({pressed}) => [
        styles.container,
        pressed && styles.pressed,
      ]}>

      <View
        style={[
          styles.imageContainer,
          selected && styles.selectedContainer,
        ]}>

        <Image
          source={item.image}
          style={styles.image}
          resizeMode="contain"
        />

      </View>

      <Text
        numberOfLines={1}
        style={[
          styles.title,
          selected && styles.selectedTitle,
        ]}>
        {item.name}
      </Text>

    </Pressable>
  );
};

export default CategoryCard;

const styles = StyleSheet.create({
  container: {
    width: 72,

    alignItems: 'center',

    marginRight: 14,
  },

  pressed: {
    opacity: 0.75,
  },

  imageContainer: {
    width: 64,
    height: 64,

    borderRadius: 32,

    alignItems: 'center',
    justifyContent: 'center',

    backgroundColor: '#FFFFFF',

    borderWidth: 1,
    borderColor: '#F2F2F2',

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 2,
    },
    shadowOpacity: 0.08,
    shadowRadius: 6,

    elevation: 4,
  },

  selectedContainer: {
    backgroundColor: '#FFF4EB',

    borderWidth: 2,
    borderColor: '#FF7A00',

    shadowColor: '#FF7A00',
    shadowOffset: {
      width: 0,
      height: 3,
    },
    shadowOpacity: 0.18,
    shadowRadius: 8,

    elevation: 6,

    transform: [
      {
        scale: 1.04,
      },
    ],
  },

  image: {
    width: 46,
    height: 46,
  },

  title: {
    marginTop: 8,

    fontSize: 12,
    fontWeight: '600',

    color: '#333333',

    textAlign: 'center',
  },

  selectedTitle: {
    color: '#FF7A00',
    fontWeight: '700',
  },
});
