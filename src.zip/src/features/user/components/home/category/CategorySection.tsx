import React, {useState} from 'react';
import {
  FlatList,
  StyleSheet,
  View,
} from 'react-native';

import {useNavigation} from '@react-navigation/native';
import {
  NativeStackNavigationProp,
} from '@react-navigation/native-stack';

import {
  RootStackParamList,
} from '../../../../../navigation/AppNavigator';

import CategoryCard from './CategoryCard';
import {categories} from './categoryData';

// =====================================================
// NAVIGATION TYPE
// =====================================================

type CategoryNavigationProp =
  NativeStackNavigationProp<
    RootStackParamList,
    'Main'
  >;

// =====================================================
// CATEGORY SECTION
// =====================================================

const CategorySection: React.FC = () => {
  const navigation =
    useNavigation<CategoryNavigationProp>();

  const [selected, setSelected] =
    useState(categories[0]?.id ?? '');

// ===================================================
// CATEGORY PRESS
// ===================================================

  const handleCategoryPress = (
    item: (typeof categories)[number],
  ) => {
    setSelected(item.id);

    navigation.navigate('CategoryFoods', {
      categoryName: item.name,
    });
  };

// ===================================================
// RENDER CATEGORY
// ===================================================

  const renderItem = ({
    item,
  }: {
    item: (typeof categories)[number];
  }) => {
    return (
      <CategoryCard
        item={item}
        selected={selected === item.id}
        onPress={() =>
          handleCategoryPress(item)
        }
      />
    );
  };

// ===================================================
// RENDER
// ===================================================

  return (
    <View style={styles.container}>
      <FlatList
        horizontal
        data={categories}
        renderItem={renderItem}
        keyExtractor={item => item.id}
        showsHorizontalScrollIndicator={false}
        contentContainerStyle={styles.list}
        decelerationRate="fast"
        snapToAlignment="start"
        bounces={false}
      />
    </View>
  );
};

export default CategorySection;

// =====================================================
// STYLES
// =====================================================

const styles = StyleSheet.create({
  container: {
    marginTop: 6,
  },

  list: {
    paddingHorizontal: 20,
    paddingRight: 24,
    paddingTop: 8,
    paddingBottom: 6,
  },
});