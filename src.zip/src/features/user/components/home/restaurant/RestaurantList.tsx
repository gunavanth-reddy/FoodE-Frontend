import React, {useEffect, useState} from 'react';

import {
  Alert,
  FlatList,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import AsyncStorage from '@react-native-async-storage/async-storage';

import {useNavigation} from '@react-navigation/native';

import {
  NativeStackNavigationProp,
} from '@react-navigation/native-stack';

import RestaurantCard from './RestaurantCard';

import {
  Restaurant,
} from './restaurantData';

import {useAuth} from '../../../../../context/AuthContext';

import {
  RootStackParamList,
} from '../../../../../navigation/AppNavigator';

// =====================================================
// STORAGE KEY
// =====================================================

const FAVORITE_RESTAURANTS_KEY =
  '@foode_favorite_restaurants';

// =====================================================
// TYPES
// =====================================================

interface RestaurantListProps {
  title: string;

  data: Restaurant[];

  onRestaurantPress: (
    restaurant: Restaurant,
  ) => void;

  onSeeAll?: () => void;
}

// =====================================================
// NAVIGATION
// =====================================================

type RestaurantNavigationProp =
  NativeStackNavigationProp<
    RootStackParamList
  >;

// =====================================================
// RESTAURANT LIST
// =====================================================

const RestaurantList: React.FC<
  RestaurantListProps
> = ({
  title,
  data,
  onRestaurantPress,
  onSeeAll,
}) => {
  // ===================================================
  // NAVIGATION
  // ===================================================

  const navigation =
    useNavigation<RestaurantNavigationProp>();

  // ===================================================
  // AUTH
  // ===================================================

  const {isLoggedIn} = useAuth();

  // ===================================================
  // FAVORITES
  // ===================================================

  const [
    favorites,
    setFavorites,
  ] = useState<Restaurant[]>([]);

  // ===================================================
  // LOAD FAVORITES
  // ===================================================

  useEffect(() => {
    let mounted = true;

    const loadFavorites = async () => {
      try {
        const stored =
          await AsyncStorage.getItem(
            FAVORITE_RESTAURANTS_KEY,
          );

        if (!mounted) {
          return;
        }

        if (!stored) {
          setFavorites([]);
          return;
        }

        const parsed =
          JSON.parse(stored);

        if (Array.isArray(parsed)) {
          setFavorites(parsed);
        } else {
          setFavorites([]);
        }
      } catch (error) {
        console.log(
          'FoodE: Failed to load restaurant favorites:',
          error,
        );

        if (mounted) {
          setFavorites([]);
        }
      }
    };

    loadFavorites();

    return () => {
      mounted = false;
    };
  }, []);

  // ===================================================
  // GET ID
  // ===================================================

  const getRestaurantId = (
    restaurant: Restaurant,
  ): string => {
    const item =
      restaurant as Restaurant & {
        _id?: string;
        id?: string;
      };

    return String(
      item._id ||
        item.id ||
        '',
    );
  };

  // ===================================================
  // CHECK FAVORITE
  // ===================================================

  const isRestaurantFavorite = (
    restaurant: Restaurant,
  ): boolean => {
    const restaurantId =
      getRestaurantId(
        restaurant,
      );

    if (!restaurantId) {
      return false;
    }

    return favorites.some(
      favorite =>
        getRestaurantId(
          favorite,
        ) === restaurantId,
    );
  };

  // ===================================================
  // SAVE
  // ===================================================

  const persistFavorites = async (
    updatedFavorites: Restaurant[],
  ) => {
    try {
      await AsyncStorage.setItem(
        FAVORITE_RESTAURANTS_KEY,
        JSON.stringify(
          updatedFavorites,
        ),
      );
    } catch (error) {
      console.log(
        'FoodE: Failed to save restaurant favorites:',
        error,
      );
    }
  };

  // ===================================================
  // FAVORITE BUTTON
  // ===================================================

  const handleFavoritePress = async (
    restaurant: Restaurant,
  ) => {
    // -------------------------------------------------
    // LOGIN
    // -------------------------------------------------

    if (!isLoggedIn) {
      Alert.alert(
        'Login Required',
        'Please login to save restaurants to your favorites.',
        [
          {
            text: 'Cancel',
            style: 'cancel',
          },
          {
            text: 'Login',
            onPress: () => {
              navigation.navigate(
                'Login',
              );
            },
          },
        ],
      );

      return;
    }

    // -------------------------------------------------
    // ID
    // -------------------------------------------------

    const restaurantId =
      getRestaurantId(
        restaurant,
      );

    if (!restaurantId) {
      console.log(
        'FoodE: Restaurant ID missing.',
      );

      return;
    }

    // -------------------------------------------------
    // REMOVE
    // -------------------------------------------------

    if (
      isRestaurantFavorite(
        restaurant,
      )
    ) {
      const updatedFavorites =
        favorites.filter(
          favorite =>
            getRestaurantId(
              favorite,
            ) !== restaurantId,
        );

      setFavorites(
        updatedFavorites,
      );

      await persistFavorites(
        updatedFavorites,
      );

      return;
    }

    // -------------------------------------------------
    // ADD
    // -------------------------------------------------

    const updatedFavorites = [
      ...favorites,
      restaurant,
    ];

    setFavorites(
      updatedFavorites,
    );

    await persistFavorites(
      updatedFavorites,
    );
  };

  // ===================================================
  // EMPTY
  // ===================================================

  if (data.length === 0) {
    return null;
  }

  // ===================================================
  // RENDER
  // ===================================================

  return (
    <View
      style={styles.container}>

      {/* =================================================
          HEADER
      ================================================= */}

      <View
        style={styles.header}>

        <View
          style={styles.leftSection}>

          <View
            style={styles.accentBar}
          />

          <Text
            style={styles.title}
            numberOfLines={1}>
            {title}
          </Text>

        </View>

        {/* =================================================
            SEE ALL
        ================================================= */}

        {onSeeAll && (
          <Pressable
            onPress={onSeeAll}
            hitSlop={8}
            style={({pressed}) => [
              styles.seeAllButton,
              pressed &&
                styles.pressed,
            ]}>

            <Text
              style={styles.seeAll}>
              See All
            </Text>

          </Pressable>
        )}

      </View>

      {/* =================================================
          RESTAURANT LIST
      ================================================= */}

      <FlatList
        data={data}

        keyExtractor={item =>
          getRestaurantId(item)
        }

        scrollEnabled={false}

        showsVerticalScrollIndicator={
          false
        }

        contentContainerStyle={
          styles.list
        }

        renderItem={({item}) => (
          <RestaurantCard
            restaurant={item}

            onPress={() =>
              onRestaurantPress(
                item,
              )
            }

            isFavorite={
              isRestaurantFavorite(
                item,
              )
            }

            onFavoritePress={() =>
              handleFavoritePress(
                item,
              )
            }
          />
        )}

        removeClippedSubviews
      />

    </View>
  );
};

export default RestaurantList;

// =====================================================
// STYLES
// =====================================================

const styles =
  StyleSheet.create({

    container: {
      marginTop: 30,
    },

    // =================================================
    // HEADER
    // =================================================

    header: {
      flexDirection: 'row',

      justifyContent:
        'space-between',

      alignItems: 'center',

      paddingHorizontal: 20,

      marginBottom: 18,
    },

    leftSection: {
      flex: 1,

      flexDirection: 'row',

      alignItems: 'center',

      marginRight: 12,
    },

    accentBar: {
      width: 4,

      height: 22,

      borderRadius: 20,

      backgroundColor:
        '#FF7A00',

      marginRight: 10,
    },

    title: {
      fontSize: 22,

      fontWeight: '700',

      color: '#1F2937',
    },

    // =================================================
    // SEE ALL
    // =================================================

    seeAllButton: {
      paddingVertical: 4,

      paddingHorizontal: 2,
    },

    seeAll: {
      fontSize: 14,

      fontWeight: '600',

      color: '#FF7A00',
    },

    pressed: {
      opacity: 0.6,
    },

    // =================================================
    // LIST
    // =================================================

    list: {
      paddingHorizontal: 16,

      paddingBottom: 10,
    },
  });
