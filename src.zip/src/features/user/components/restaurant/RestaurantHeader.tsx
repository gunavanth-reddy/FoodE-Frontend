import React, {useState} from 'react';

import {
  ImageBackground,
  Pressable,
  StyleSheet,
  Text,
  View,
} from 'react-native';

import {useNavigation} from '@react-navigation/native';

import type {Restaurant} from '../home/restaurant/restaurantData';

// =====================================================
// PROPS
// =====================================================

interface RestaurantHeaderProps {
  restaurant: Restaurant;
}

// =====================================================
// COMPONENT
// =====================================================

const RestaurantHeader: React.FC<RestaurantHeaderProps> = ({
  restaurant,
}) => {
  const navigation = useNavigation();

  const [isFavorite, setIsFavorite] = useState(false);
  const [imageError, setImageError] = useState(false);

  // Safely support image fields returned by the backend.
  const restaurantData = restaurant as Restaurant & {
    coverImage?: string | null;
    logo?: string | null;
    image?: string | null;
    imageUrl?: string | null;
  };

  const imageUri =
    restaurantData.coverImage?.trim() ||
    restaurantData.image?.trim() ||
    restaurantData.imageUrl?.trim() ||
    restaurantData.logo?.trim() ||
    '';

  const hasImage = imageUri.length > 0 && !imageError;

  // ===================================================
  // RENDER
  // ===================================================

  return (
    <View style={styles.container}>
      {/* RESTAURANT COVER IMAGE */}

      {hasImage ? (
        <ImageBackground
          source={{uri: imageUri}}
          style={styles.coverImage}
          resizeMode="cover"
          onError={() => setImageError(true)}>
          <View style={styles.imageOverlay} />
        </ImageBackground>
      ) : (
        <View style={[styles.coverImage, styles.imageFallback]}>
          <Text style={styles.fallbackIcon}>🍽️</Text>
          <Text style={styles.fallbackText}>FoodE</Text>
        </View>
      )}

      {/* BACK BUTTON */}

      <Pressable
        accessibilityRole="button"
        accessibilityLabel="Go back"
        onPress={() => navigation.goBack()}
        style={({pressed}) => [
          styles.iconButton,
          styles.backButton,
          pressed && styles.pressed,
        ]}>
        <Text style={styles.backIcon}>‹</Text>
      </Pressable>

      {/* FAVOURITE BUTTON */}

      <Pressable
        accessibilityRole="button"
        accessibilityLabel={
          isFavorite ? 'Remove favourite' : 'Add to favourites'
        }
        onPress={() => setIsFavorite(previous => !previous)}
        style={({pressed}) => [
          styles.iconButton,
          styles.favoriteButton,
          pressed && styles.pressed,
        ]}>
        <Text
          style={[
            styles.heart,
            isFavorite && styles.heartActive,
          ]}>
          {isFavorite ? '♥' : '♡'}
        </Text>
      </Pressable>

      {/* BOTTOM LABEL */}

      <View style={styles.imageLabel}>
        <View style={styles.statusDot} />

        <Text style={styles.imageLabelText}>
          FRESHLY MADE FOR YOU
        </Text>
      </View>
    </View>
  );
};

// =====================================================
// STYLES
// =====================================================

const styles = StyleSheet.create({
  container: {
    width: '100%',
    height: 260,
    position: 'relative',
    backgroundColor: '#FFF1E4',
    overflow: 'hidden',
  },

  coverImage: {
    width: '100%',
    height: '100%',
    position: 'absolute',
    top: 0,
    left: 0,
  },

  imageFallback: {
    backgroundColor: '#FFE8D2',
    alignItems: 'center',
    justifyContent: 'center',
  },

  fallbackIcon: {
    fontSize: 54,
    marginBottom: 8,
  },

  fallbackText: {
    fontSize: 20,
    fontWeight: '800',
    color: '#C85C00',
  },

  imageOverlay: {
  position: 'absolute',
  top: 0,
  right: 0,
  bottom: 0,
  left: 0,
  backgroundColor: 'rgba(0, 0, 0, 0.12)',
},

  // ICON BUTTONS

  iconButton: {
    position: 'absolute',
    top: 18,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    elevation: 5,
  },

  backButton: {
    left: 16,
  },

  favoriteButton: {
    right: 16,
  },

  backIcon: {
    fontSize: 35,
    lineHeight: 39,
    color: '#171B24',
    fontWeight: '500',
    marginTop: -3,
  },

  heart: {
    fontSize: 27,
    color: '#171B24',
  },

  heartActive: {
    color: '#FF7A00',
  },

  pressed: {
    opacity: 0.75,
    transform: [{scale: 0.95}],
  },

  // IMAGE LABEL

  imageLabel: {
    position: 'absolute',
    bottom: 16,
    left: 16,
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 9,
    borderRadius: 20,
    backgroundColor: '#FFFFFF',
  },

  statusDot: {
    width: 7,
    height: 7,
    borderRadius: 4,
    backgroundColor: '#22C55E',
    marginRight: 7,
  },

  imageLabelText: {
    fontSize: 10,
    fontWeight: '800',
    color: '#333333',
    letterSpacing: 0.6,
  },
});

export default RestaurantHeader;
