import React, {useEffect, useState} from 'react';

import {
  Image,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  Text as RNText,
} from 'react-native';

import {MenuItem} from '../../data/menu/types';
import QuantitySelector from './QuantitySelector';

interface MenuItemCardProps {
  item: MenuItem;
  onPress?: (item: MenuItem) => void;
}

const MenuItemCard: React.FC<MenuItemCardProps> = ({
  item,
  onPress,
}) => {
  const [imageError, setImageError] = useState(false);

  const imageValue = item?.image;

  useEffect(() => {
    setImageError(false);
  }, [imageValue]);

  const imageSource =
    typeof imageValue === 'string' && imageValue.trim().length > 0
      ? {uri: imageValue.trim()}
      : imageValue &&
          typeof imageValue === 'object' &&
          'uri' in imageValue
        ? imageValue
        : null;

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={styles.container}
      onPress={() => onPress?.(item)}>

      {/* Left Section */}
      <View style={styles.content}>
        {/* Veg / Non-Veg */}
        <View
          style={[
            styles.foodType,
            {
              borderColor: item.isVeg ? '#16A34A' : '#B91C1C',
            },
          ]}>
          <View
            style={[
              styles.foodDot,
              {
                backgroundColor: item.isVeg ? '#16A34A' : '#B91C1C',
              },
            ]}
          />
        </View>

        {/* Name */}
        <Text style={styles.name}>{item.name}</Text>

        {/* Rating */}
        <View style={styles.ratingRow}>
          <Text style={styles.star}>⭐</Text>
          <Text style={styles.rating}>
            {Number(item.rating ?? 0).toFixed(1)}
          </Text>
        </View>

        {/* Price */}
        <Text style={styles.price}>₹{item.price}</Text>

        {/* Description */}
        <Text numberOfLines={3} style={styles.description}>
          {item.description}
        </Text>
      </View>

      {/* Right Section */}
      <View style={styles.imageSection}>
        {imageSource && !imageError ? (
          <Image
            source={imageSource}
            style={styles.image}
            resizeMode="cover"
            onError={() => {
              console.warn('Menu item image failed:', imageSource);
              setImageError(true);
            }}
          />
        ) : (
          <View style={[styles.image, styles.imagePlaceholder]}>
            <Text style={styles.placeholderIcon}>🍽️</Text>
            <RNText style={styles.placeholderText}>
              Image unavailable
            </RNText>
          </View>
        )}

        <QuantitySelector item={item} />
      </View>
    </TouchableOpacity>
  );
};

export default MenuItemCard;

const styles = StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    backgroundColor: '#FFFFFF',
    marginHorizontal: 20,
    marginBottom: 16,
    padding: 18,
    borderRadius: 18,
    shadowColor: '#000',
    shadowOpacity: 0.05,
    shadowRadius: 8,
    shadowOffset: {
      width: 0,
      height: 3,
    },
    elevation: 3,
  },

  content: {
    flex: 1,
    paddingRight: 16,
  },

  foodType: {
    width: 18,
    height: 18,
    borderWidth: 1.5,
    justifyContent: 'center',
    alignItems: 'center',
    marginBottom: 10,
  },

  foodDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },

  name: {
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },

  ratingRow: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 8,
  },

  star: {
    fontSize: 14,
  },

  rating: {
    marginLeft: 5,
    color: '#16A34A',
    fontWeight: '700',
  },

  price: {
    marginTop: 10,
    fontSize: 18,
    fontWeight: '700',
    color: '#111827',
  },

  description: {
    marginTop: 10,
    color: '#6B7280',
    fontSize: 14,
    lineHeight: 22,
  },

  imageSection: {
    alignItems: 'center',
    position: 'relative',
  },

  image: {
    width: 120,
    height: 120,
    borderRadius: 16,
  },

  imagePlaceholder: {
    backgroundColor: '#F3F4F6',
    justifyContent: 'center',
    alignItems: 'center',
  },

  placeholderIcon: {
    fontSize: 30,
  },

  placeholderText: {
    color: '#9CA3AF',
    fontSize: 10,
    marginTop: 4,
  },
});
