import {QuickAction} from '../types';

export const QUICK_ACTIONS: QuickAction[] = [
  {
    id: '1',
    title: 'Orders',
    icon: 'receipt-long',
    color: '#3B82F6',
    route: 'Orders',
  },
  {
    id: '2',
    title: 'Favorites',
    icon: 'favorite-outline',
    color: '#EF4444',
    route: 'Favorites',
  },
  {
    id: '3',
    title: 'Address',
    icon: 'location-on',
    color: '#22C55E',
    route: 'Addresses',
  },
  {
    id: '4',
    title: 'Wallet',
    icon: 'account-balance-wallet',
    color: '#F59E0B',
    route: 'Wallet',
  },
];