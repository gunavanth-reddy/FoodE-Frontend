import React from 'react';
import {Image, StyleSheet, View} from 'react-native';

import {COLORS, SPACING} from '../../styles';

interface Props {
  uri?: string;
  size?: number;
}

const Avatar = ({uri, size = 72}: Props) => {
  return (
    <View
      style={[
        styles.container,
        {
          width: size,
          height: size,
          borderRadius: size / 2,
        },
      ]}>
      {uri ? (
        <Image
          source={{uri}}
          style={{
            width: size,
            height: size,
            borderRadius: size / 2,
          }}
        />
      ) : (
        <View
          style={[
            styles.placeholder,
            {
              width: size,
              height: size,
              borderRadius: size / 2,
            },
          ]}
        />
      )}
    </View>
  );
};

export default Avatar;

const styles = StyleSheet.create({
  container: {
    overflow: 'hidden',
  },

  placeholder: {
    backgroundColor: COLORS.primaryLight,
    borderWidth: 2,
    borderColor: COLORS.primary,
  },
});
