import {StyleSheet} from 'react-native';

import {
  COLORS,
  SHADOWS,
  SPACING,
  TYPOGRAPHY,
} from '../../styles';

export default StyleSheet.create({
  container: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',

    marginBottom: SPACING.xl,
    paddingTop: SPACING.xs,
  },

  textContainer: {
    flex: 1,
    marginRight: SPACING.md,
  },

  title: {
    color: COLORS.textPrimary,
    ...TYPOGRAPHY.h1,
  },

  subtitle: {
    marginTop: SPACING.xs,

    color: COLORS.textSecondary,
    ...TYPOGRAPHY.body,
  },

  notificationButton: {
    width: 50,
    height: 50,

    borderRadius: 16,
    backgroundColor: COLORS.surface,

    justifyContent: 'center',
    alignItems: 'center',

    ...SHADOWS.card,
  },

  badge: {
    position: 'absolute',
    top: 10,
    right: 10,

    width: 9,
    height: 9,
    borderRadius: 5,

    backgroundColor: COLORS.primary,

    borderWidth: 1.5,
    borderColor: COLORS.surface,
  },
});
