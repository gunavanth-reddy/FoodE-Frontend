import {StyleSheet} from 'react-native';

import {
  COLORS,
  SHADOWS,
  SPACING,
  TYPOGRAPHY,
} from '../../styles';

export default StyleSheet.create({
  // Quick Actions Grid
  grid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginTop: SPACING.md,
    marginBottom: SPACING.sm,
  },

  // Individual Quick Action Card
  card: {
    width: '48.2%',
    minHeight: 158,

    backgroundColor: COLORS.surface,

    borderRadius: 20,

    paddingVertical: SPACING.lg,
    paddingHorizontal: SPACING.md,

    alignItems: 'center',
    justifyContent: 'center',

    marginBottom: SPACING.md,

    borderWidth: 1,
    borderColor: COLORS.divider,

    ...SHADOWS.card,
  },

  // Icon Background
  iconContainer: {
    width: 58,
    height: 58,

    borderRadius: 19,

    justifyContent: 'center',
    alignItems: 'center',

    marginBottom: SPACING.md,
  },

  // Action Title
  title: {
    color: COLORS.textPrimary,

    textAlign: 'center',

    ...TYPOGRAPHY.title,
  },

  // Action Subtitle
  subtitle: {
    color: COLORS.textSecondary,

    textAlign: 'center',

    marginTop: 5,

    ...TYPOGRAPHY.caption,
  },
});
