import {StyleSheet} from 'react-native';

import {
  COLORS,
  SHADOWS,
  SPACING,
  TYPOGRAPHY,
} from '../../styles';

export default StyleSheet.create({
  // Main menu card
  container: {
    backgroundColor: COLORS.surface,

    borderRadius: 22,

    overflow: 'hidden',

    marginBottom: SPACING.xl,

    borderWidth: 1,
    borderColor: COLORS.divider,

    ...SHADOWS.card,
  },

  // Individual menu row
  itemContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',

    paddingHorizontal: SPACING.cardPadding,
    paddingVertical: 16,

    minHeight: 78,
  },

  // Left side: icon + text
  leftContainer: {
    flexDirection: 'row',
    alignItems: 'center',

    flex: 1,

    marginRight: SPACING.sm,
  },

  // Icon background
  iconContainer: {
    width: 46,
    height: 46,

    borderRadius: 16,

    justifyContent: 'center',
    alignItems: 'center',

    marginRight: SPACING.md,
  },

  // Title and subtitle wrapper
  textContainer: {
    flex: 1,
  },

  title: {
    color: COLORS.textPrimary,

    ...TYPOGRAPHY.title,
  },

  subtitle: {
    color: COLORS.textSecondary,

    marginTop: 4,

    ...TYPOGRAPHY.caption,
  },

  // Right-side arrow
  arrowContainer: {
    width: 28,
    height: 28,

    borderRadius: 14,

    backgroundColor: COLORS.background,

    justifyContent: 'center',
    alignItems: 'center',
  },
});
