import {StyleSheet} from 'react-native';

import {
  COLORS,
  SHADOWS,
  SPACING,
  TYPOGRAPHY,
} from '../../styles';

export default StyleSheet.create({
  container: {
    backgroundColor: COLORS.surface,
    borderRadius: 26,
    padding: SPACING.xxl,
    alignItems: 'center',
    marginBottom: SPACING.xxl,
    ...SHADOWS.large,
  },

  avatarContainer: {
    marginBottom: SPACING.lg,
  },

  name: {
    color: COLORS.textPrimary,
    textAlign: 'center',
    ...TYPOGRAPHY.h2,
  },

  email: {
    color: COLORS.textSecondary,
    marginTop: 6,
    textAlign: 'center',
    ...TYPOGRAPHY.body,
  },

  badgeContainer: {
    marginTop: SPACING.md,
  },

  divider: {
    height: 1,
    width: '100%',
    backgroundColor: COLORS.divider,
    marginVertical: SPACING.xl,
  },

  statsRow: {
    width: '100%',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },

  stat: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },

  statValue: {
    color: COLORS.textPrimary,
    ...TYPOGRAPHY.h2,
  },

  statLabel: {
    color: COLORS.textSecondary,
    marginTop: 5,
    textAlign: 'center',
    ...TYPOGRAPHY.caption,
  },

  statDivider: {
    width: 1,
    height: 32,
    backgroundColor: COLORS.divider,
  },

  editProfileButton: {
    width: '100%',
    minHeight: 50,
    marginTop: SPACING.xl,
    borderRadius: 14,
    backgroundColor: COLORS.primary,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.sm,
  },

  editProfileButtonText: {
    color: '#FFFFFF',
    ...TYPOGRAPHY.button,
  },
});
