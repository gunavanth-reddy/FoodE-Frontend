export {default} from './Footer';
