export const COLORS = {
  // Brand
  primary: '#FF6B00',
  primaryDark: '#E65F00',
  primaryLight: '#FFF3EB',

  // Backgrounds
  background: '#F8F9FB',
  surface: '#FFFFFF',
  card: '#FFFFFF',

  // Text
  textPrimary: '#1E1E1E',
  textSecondary: '#757575',
  textLight: '#A8A8A8',

  // Status
  success: '#22C55E',
  warning: '#F59E0B',
  error: '#EF4444',
  info: '#3B82F6',

  // Borders
  border: '#ECECEC',
  divider: '#F2F2F2',

  // Others
  white: '#FFFFFF',
  black: '#000000',
  transparent: 'transparent',

  overlay: 'rgba(0,0,0,0.25)',
};
