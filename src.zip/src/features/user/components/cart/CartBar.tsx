import React from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';

import {useNavigation} from '@react-navigation/native';

import {ArrowRight} from 'phosphor-react-native';

import {useCart} from '../../../../context/CartContext';

const CartBar = () => {
  const navigation = useNavigation();

  const {
    totalItems,
    totalAmount,
  } = useCart();

  if (totalItems === 0) {
    return null;
  }

  return (
    <TouchableOpacity
      activeOpacity={0.9}
      style={styles.container}
      onPress={() =>
        navigation.navigate('Cart' as never)
      }>
      <View>
        <Text style={styles.items}>
          {totalItems} Item{totalItems > 1 ? 's' : ''}
        </Text>

        <Text style={styles.amount}>
          ₹{totalAmount}
        </Text>
      </View>

      <View style={styles.viewCartContainer}>
        <Text style={styles.viewCart}>
          View Cart
        </Text>

        <ArrowRight
          size={20}
          weight="bold"
          color="#FFFFFF"
        />
      </View>
    </TouchableOpacity>
  );
};

export default CartBar;

const styles = StyleSheet.create({
  container: {
    position: 'absolute',

    left: 16,
    right: 16,
    bottom: 20,

    height: 64,

    backgroundColor: '#16A34A',

    borderRadius: 16,

    paddingHorizontal: 20,

    flexDirection: 'row',

    alignItems: 'center',

    justifyContent: 'space-between',

    elevation: 10,
  },

  items: {
    color: '#FFFFFF',
    fontSize: 16,
    fontWeight: '700',
  },

  amount: {
    color: '#FFFFFF',
    fontSize: 14,
    marginTop: 2,
  },

  viewCartContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },

  viewCart: {
    color: '#FFFFFF',
    fontWeight: '700',
    fontSize: 16,
  },
});