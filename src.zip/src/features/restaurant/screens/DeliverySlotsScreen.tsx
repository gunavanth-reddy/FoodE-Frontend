import React, {useCallback, useEffect, useState} from 'react';
import {
  ActivityIndicator,
  Alert,
  ScrollView,
  StatusBar,
  StyleSheet,
  Switch,
  Text,
  TextInput,
  TouchableOpacity,
  View,
} from 'react-native';

import {SafeAreaView} from 'react-native-safe-area-context';

import {useAuth} from '../../../context/AuthContext';
import {Clock, Plus, Trash, CheckCircle} from 'phosphor-react-native';
import API_BASE_URL from '../../../config/api';

// =====================================================
// TYPES
// =====================================================

interface DeliverySlot {
  _id?: string;
  startTime: string;
  endTime: string;
  isActive: boolean;
  cutoffMinutes: number;
}

interface ApiResponse {
  success: boolean;
  message?: string;
  deliverySlots?: DeliverySlot[];
  deliverySlot?: DeliverySlot;
}

// =====================================================
// DEFAULT SLOTS
// =====================================================

const DEFAULT_SLOTS: DeliverySlot[] = [
  {
    startTime: '07:00',
    endTime: '07:30',
    isActive: true,
    cutoffMinutes: 10,
  },
  {
    startTime: '12:00',
    endTime: '12:30',
    isActive: true,
    cutoffMinutes: 10,
  },
  {
    startTime: '16:00',
    endTime: '16:30',
    isActive: true,
    cutoffMinutes: 10,
  },
  {
    startTime: '20:00',
    endTime: '20:30',
    isActive: false,
    cutoffMinutes: 10,
  },
];

// =====================================================
// HELPERS
// =====================================================

const isValidTime = (value: string) =>
  /^([01]\d|2[0-3]):[0-5]\d$/.test(value);

const timeToMinutes = (time: string) => {
  const [hours, minutes] = time.split(':').map(Number);
  return hours * 60 + minutes;
};

// =====================================================
// SCREEN
// =====================================================

const DeliverySlotsScreen: React.FC = () => {
  const {token} = useAuth();

  const [deliverySlots, setDeliverySlots] =
    useState<DeliverySlot[]>(DEFAULT_SLOTS);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  // =====================================================
  // LOAD SLOTS
  // =====================================================

  const fetchDeliverySlots = useCallback(async () => {
    if (!token) {
      setLoading(false);
      return;
    }

    try {
      setLoading(true);

      const response = await fetch(
        `${API_BASE_URL}/delivery-slots/my`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
          },
        },
      );

      const data: ApiResponse = await response.json();

      console.log('OWNER DELIVERY SLOTS:', data);

      if (!response.ok || !data.success) {
        throw new Error(
          data.message || 'Unable to load delivery slots.',
        );
      }

      if (
        Array.isArray(data.deliverySlots) &&
        data.deliverySlots.length > 0
      ) {
        setDeliverySlots(
          data.deliverySlots.map(slot => ({
            _id: slot._id,
            startTime: slot.startTime,
            endTime: slot.endTime,
            isActive: slot.isActive,
            // New default cutoff = 10 minutes
            cutoffMinutes: slot.cutoffMinutes ?? 10,
          })),
        );
      } else {
        setDeliverySlots(DEFAULT_SLOTS);
      }
    } catch (error: any) {
      console.log(
        'FETCH OWNER DELIVERY SLOTS ERROR:',
        error,
      );

      Alert.alert(
        'Unable to Load',
        error?.message || 'Could not load delivery slots.',
      );
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchDeliverySlots();
  }, [fetchDeliverySlots]);

  // =====================================================
  // UPDATE SLOT
  // =====================================================

  const updateSlot = (
    index: number,
    field: keyof DeliverySlot,
    value: string | boolean | number,
  ) => {
    setDeliverySlots(previous =>
      previous.map((slot, slotIndex) =>
        slotIndex === index
          ? {...slot, [field]: value}
          : slot,
      ),
    );
  };

  // =====================================================
  // ADD SLOT
  // =====================================================

  const addCustomSlot = () => {
    setDeliverySlots(previous => [
      ...previous,
      {
        startTime: '09:00',
        endTime: '09:30',
        isActive: true,
        cutoffMinutes: 10,
      },
    ]);
  };

  // =====================================================
  // REMOVE SLOT
  // =====================================================

  const removeSlot = (index: number) => {
    setDeliverySlots(previous =>
      previous.filter((_, slotIndex) => slotIndex !== index),
    );
  };

  // =====================================================
  // VALIDATE
  // =====================================================

  const validateSlots = () => {
    const activeSlots = deliverySlots.filter(
      slot => slot.isActive,
    );

    if (activeSlots.length === 0) {
      Alert.alert(
        'No Active Slots',
        'Enable at least one delivery slot.',
      );

      return false;
    }

    for (const slot of activeSlots) {
      if (
        !isValidTime(slot.startTime) ||
        !isValidTime(slot.endTime)
      ) {
        Alert.alert(
          'Invalid Time',
          `Use HH:MM format. Example: 12:00`,
        );

        return false;
      }

      const start = timeToMinutes(slot.startTime);
      const end = timeToMinutes(slot.endTime);

      if (end <= start) {
        Alert.alert(
          'Invalid Slot',
          `${slot.startTime} - ${slot.endTime}: End time must be after start time.`,
        );

        return false;
      }

      // Every delivery slot must be exactly 30 minutes.
      if (end - start !== 30) {
        Alert.alert(
          'Invalid Slot',
          `${slot.startTime} - ${slot.endTime} must be exactly 30 minutes.`,
        );

        return false;
      }

      // =================================================
      // CUTOFF
      // =================================================

      if (slot.cutoffMinutes !== 10) {
        Alert.alert(
          'Invalid Cutoff',
          'Booking cutoff must be exactly 10 minutes before the slot starts.',
        );

        return false;
      }
    }

    // ===================================================
    // CHECK OVERLAPS
    // ===================================================

    const sorted = [...activeSlots].sort(
      (a, b) =>
        timeToMinutes(a.startTime) -
        timeToMinutes(b.startTime),
    );

    for (let i = 1; i < sorted.length; i++) {
      const previousEnd = timeToMinutes(
        sorted[i - 1].endTime,
      );

      const currentStart = timeToMinutes(
        sorted[i].startTime,
      );

      if (currentStart < previousEnd) {
        Alert.alert(
          'Overlapping Slots',
          `${sorted[i - 1].startTime}-${sorted[i - 1].endTime} overlaps with ${sorted[i].startTime}-${sorted[i].endTime}.`,
        );

        return false;
      }
    }

    return true;
  };

  // =====================================================
  // DELETE OLD SLOT
  // =====================================================

  const deleteSlotFromServer = async (
    slotId: string,
  ) => {
    const response = await fetch(
      `${API_BASE_URL}/delivery-slots/${slotId}`,
      {
        method: 'DELETE',
        headers: {
          Authorization: `Bearer ${token}`,
          Accept: 'application/json',
        },
      },
    );

    const data = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(
        data.message || 'Failed to delete old slot.',
      );
    }
  };

  // =====================================================
  // CREATE SLOT
  // =====================================================

  const createSlotOnServer = async (
    slot: DeliverySlot,
  ) => {
    const response = await fetch(
      `${API_BASE_URL}/delivery-slots`,
      {
        method: 'POST',
        headers: {
          Authorization: `Bearer ${token}`,
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          startTime: slot.startTime,
          endTime: slot.endTime,

          // IMPORTANT:
          // Customers can book only until
          // 10 minutes before slot start.
          cutoffMinutes: 10,
        }),
      },
    );

    const data: ApiResponse = await response.json();

    if (!response.ok || !data.success) {
      throw new Error(
        data.message || 'Failed to create delivery slot.',
      );
    }

    return data.deliverySlot;
  };

  // =====================================================
  // SAVE
  // =====================================================

  const saveDeliverySlots = async () => {
    if (!token) {
      Alert.alert(
        'Login Required',
        'Please log in as a restaurant owner.',
      );

      return;
    }

    if (!validateSlots()) {
      return;
    }

    try {
      setSaving(true);

      // -------------------------------------------------
      // 1. DELETE EXISTING SERVER SLOTS
      // -------------------------------------------------

      const existingResponse = await fetch(
        `${API_BASE_URL}/delivery-slots/my`,
        {
          method: 'GET',
          headers: {
            Authorization: `Bearer ${token}`,
            Accept: 'application/json',
          },
        },
      );

      const existingData: ApiResponse =
        await existingResponse.json();

      if (
        !existingResponse.ok ||
        !existingData.success
      ) {
        throw new Error(
          existingData.message ||
            'Failed to load existing delivery slots.',
        );
      }

      const existingSlots =
        existingData.deliverySlots || [];

      for (const oldSlot of existingSlots) {
        if (oldSlot._id) {
          await deleteSlotFromServer(oldSlot._id);
        }
      }

      // -------------------------------------------------
      // 2. CREATE ACTIVE SLOTS
      // -------------------------------------------------

      const activeSlots = deliverySlots.filter(
        slot => slot.isActive,
      );

      const createdSlots: DeliverySlot[] = [];

      for (const slot of activeSlots) {
        const created =
          await createSlotOnServer({
            ...slot,
            cutoffMinutes: 10,
          });

        if (created) {
          createdSlots.push(created);
        }
      }

      // -------------------------------------------------
      // 3. REFRESH FROM SERVER
      // -------------------------------------------------

      setDeliverySlots(
        createdSlots.map(slot => ({
          ...slot,
          cutoffMinutes: slot.cutoffMinutes ?? 10,
        })),
      );

      Alert.alert(
        'Success',
        `${createdSlots.length} delivery slot${
          createdSlots.length === 1 ? '' : 's'
        } saved successfully.`,
      );
    } catch (error: any) {
      console.log(
        'SAVE DELIVERY SLOTS ERROR:',
        error,
      );

      Alert.alert(
        'Save Failed',
        error?.message ||
          'Unable to save delivery slots.',
      );

      // Reload server state
      fetchDeliverySlots();
    } finally {
      setSaving(false);
    }
  };

  // =====================================================
  // LOADING
  // =====================================================

  if (loading) {
    return (
      <SafeAreaView style={styles.loadingContainer} edges={["top", "left", "right"]}>
        <StatusBar
          backgroundColor="#FFF8F1"
          barStyle="dark-content"
        />

        <ActivityIndicator
          size="large"
          color="#FF7A00"
        />

        <Text style={styles.loadingText}>
          Loading delivery slots...
        </Text>
      </SafeAreaView>
    );
  }

  // =====================================================
  // UI
  // =====================================================

  return (
    <SafeAreaView style={styles.safeArea} edges={["top", "left", "right"]}>
      <StatusBar
        backgroundColor="#FFF8F1"
        barStyle="dark-content"
      />

      <ScrollView
        style={styles.container}
        contentContainerStyle={styles.contentContainer}
        showsVerticalScrollIndicator={false}
        keyboardShouldPersistTaps="handled">

        {/* HEADER */}

        <View style={styles.header}>
          <Text style={styles.headerTitle}>
            Delivery Slots
          </Text>

          <Text style={styles.headerSubtitle}>
            Create 30-minute delivery slots for your
            customers.
          </Text>
        </View>

        {/* INFO */}

        <View style={styles.infoBox}>
          <Text style={styles.infoTitle}>
            How it works
          </Text>

          <Text style={styles.infoText}>
            Customers can book a delivery slot until
            10 minutes before its start time.
          </Text>

          <Text style={styles.infoExample}>
            Example: 12:00 - 12:30 → booking closes
            at 11:50.
          </Text>
        </View>

        {/* SLOTS */}

        <View style={styles.section}>
          <View style={styles.sectionHeader}>
            <View>
              <Text style={styles.sectionTitle}>
                Delivery Time Slots
              </Text>

              <Text style={styles.sectionDescription}>
                Each slot must be exactly 30 minutes.
              </Text>
            </View>
          </View>

          {deliverySlots.map((slot, index) => (
            <View
              key={`${slot._id || 'new'}-${index}`}
              style={[
                styles.slotCard,
                !slot.isActive &&
                  styles.inactiveSlotCard,
              ]}>

              {/* SLOT HEADER */}

              <View style={styles.slotHeader}>
                <View>
                  <Text style={styles.slotNumber}>
                    SLOT {index + 1}
                  </Text>

                  <Text style={styles.slotTitle}>
                    {slot.startTime} - {slot.endTime}
                  </Text>
                </View>

                <Switch
                  value={slot.isActive}
                  onValueChange={value =>
                    updateSlot(
                      index,
                      'isActive',
                      value,
                    )
                  }
                  trackColor={{
                    false: '#D5D5D5',
                    true: '#FFB36B',
                  }}
                  thumbColor={
                    slot.isActive
                      ? '#FF7A00'
                      : '#F4F3F4'
                  }
                />
              </View>

              {/* TIME */}

              <View style={styles.rangeRow}>
                <View
                  style={
                    styles.rangeInputContainer
                  }>
                  <Text style={styles.inputLabel}>
                    Start Time
                  </Text>

                  <TextInput
                    style={styles.input}
                    value={slot.startTime}
                    onChangeText={value =>
                      updateSlot(
                        index,
                        'startTime',
                        value,
                      )
                    }
                    placeholder="12:00"
                    placeholderTextColor="#A0A0A0"
                    maxLength={5}
                    keyboardType="numbers-and-punctuation"
                  />
                </View>

                <View
                  style={
                    styles.rangeInputContainer
                  }>
                  <Text style={styles.inputLabel}>
                    End Time
                  </Text>

                  <TextInput
                    style={styles.input}
                    value={slot.endTime}
                    onChangeText={value =>
                      updateSlot(
                        index,
                        'endTime',
                        value,
                      )
                    }
                    placeholder="12:30"
                    placeholderTextColor="#A0A0A0"
                    maxLength={5}
                    keyboardType="numbers-and-punctuation"
                  />
                </View>
              </View>

              {/* CUTOFF INFO */}

              <View style={styles.cutoffBox}>
                <View style={styles.cutoffTitleRow}>
                  <Clock size={16} color="#8A4B13" weight="regular" />
                  <Text style={styles.cutoffTitle}>Booking Cutoff</Text>
                </View>

                <Text style={styles.cutoffText}>
                  Customers can book until 10 minutes
                  before this slot starts.
                </Text>
              </View>

              {/* SLOT INFO */}

              <View style={styles.slotInfo}>
                <View
                  style={[
                    styles.statusDot,
                    {
                      backgroundColor:
                        slot.isActive
                          ? '#22A06B'
                          : '#999999',
                    },
                  ]}
                />

                <View style={styles.statusContent}>
                  {slot.isActive ? (
                    <CheckCircle size={16} color="#168653" weight="fill" />
                  ) : null}
                  <Text
                    style={[
                      styles.statusText,
                      {
                        color: slot.isActive ? '#168653' : '#888888',
                      },
                    ]}>
                    {slot.isActive ? 'Active' : 'Inactive'}
                  </Text>
                </View>

                <Text style={styles.durationText}>
                  30 minutes
                </Text>

                <TouchableOpacity
                  style={styles.removeButton}
                  onPress={() =>
                    removeSlot(index)
                  }
                  activeOpacity={0.7}>
                  <View style={styles.removeButtonContent}>
                    <Trash size={16} color="#D93636" weight="regular" />
                    <Text style={styles.removeButtonText}>Remove</Text>
                  </View>
                </TouchableOpacity>
              </View>
            </View>
          ))}

          {/* ADD */}

          <TouchableOpacity
            style={styles.addButton}
            activeOpacity={0.8}
            onPress={addCustomSlot}>
            <View style={styles.addButtonContent}>
              <Plus size={18} color="#FF7A00" weight="bold" />
              <Text style={styles.addButtonText}>Add 30-Minute Slot</Text>
            </View>
          </TouchableOpacity>
        </View>

        {/* SAVE */}

        <TouchableOpacity
          style={[
            styles.saveButton,
            saving && styles.disabledButton,
          ]}
          activeOpacity={0.8}
          onPress={saveDeliverySlots}
          disabled={saving}>

          {saving ? (
            <ActivityIndicator color="#FFFFFF" />
          ) : (
            <Text style={styles.saveButtonText}>
              Save Delivery Slots
            </Text>
          )}
        </TouchableOpacity>

        <Text style={styles.bottomNote}>
          Only active future slots that have not reached
          their 10-minute cutoff will appear to customers
          at checkout.
        </Text>
      </ScrollView>
    </SafeAreaView>
  );
};

// =====================================================
// STYLES
// =====================================================

const styles = StyleSheet.create({
  safeArea: {
    flex: 1,
    backgroundColor: '#FFF8F1',
  },

  container: {
    flex: 1,
  },

  contentContainer: {
    paddingHorizontal: 18,
    paddingTop: 16,
    paddingBottom: 40,
  },

  loadingContainer: {
    flex: 1,
    backgroundColor: '#FFF8F1',
    alignItems: 'center',
    justifyContent: 'center',
  },

  loadingText: {
    marginTop: 12,
    fontSize: 14,
    color: '#777777',
  },

  header: {
    marginBottom: 20,
  },

  headerTitle: {
    fontSize: 25,
    fontWeight: '800',
    color: '#222222',
  },

  headerSubtitle: {
    fontSize: 14,
    color: '#777777',
    marginTop: 6,
    lineHeight: 20,
  },

  infoBox: {
    backgroundColor: '#FFF4E8',
    borderRadius: 14,
    padding: 14,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#FFE0C2',
  },

  infoTitle: {
    fontSize: 14,
    fontWeight: '700',
    color: '#8A4B13',
    marginBottom: 5,
  },

  infoText: {
    fontSize: 12,
    color: '#8A4B13',
    lineHeight: 18,
  },

  infoExample: {
    fontSize: 12,
    fontWeight: '700',
    color: '#8A4B13',
    lineHeight: 18,
    marginTop: 5,
  },

  section: {
    backgroundColor: '#FFFFFF',
    borderRadius: 18,
    padding: 16,
    marginBottom: 18,
    borderWidth: 1,
    borderColor: '#F1E7DE',
  },

  sectionHeader: {
    marginBottom: 14,
  },

  sectionTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: '#222222',
  },

  sectionDescription: {
    fontSize: 13,
    color: '#777777',
    marginTop: 5,
    lineHeight: 19,
  },

  slotCard: {
    borderWidth: 1,
    borderColor: '#F0E3D8',
    borderRadius: 14,
    padding: 14,
    marginBottom: 14,
    backgroundColor: '#FFFCF9',
  },

  inactiveSlotCard: {
    opacity: 0.65,
    backgroundColor: '#F7F7F7',
  },

  slotHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 8,
  },

  slotNumber: {
    fontSize: 10,
    fontWeight: '700',
    color: '#FF7A00',
    letterSpacing: 1,
    marginBottom: 4,
  },

  slotTitle: {
    fontSize: 16,
    fontWeight: '700',
    color: '#222222',
  },

  rangeRow: {
    flexDirection: 'row',
    gap: 12,
    marginBottom: 10,
  },

  rangeInputContainer: {
    flex: 1,
    minWidth: 0,
  },

  inputLabel: {
    fontSize: 12,
    fontWeight: '600',
    color: '#555555',
    marginBottom: 7,
    marginTop: 10,
  },

  input: {
    height: 48,
    borderWidth: 1,
    borderColor: '#E5E5E5',
    borderRadius: 10,
    paddingHorizontal: 12,
    fontSize: 14,
    color: '#222222',
    backgroundColor: '#FFFFFF',
  },

  cutoffBox: {
    backgroundColor: '#FFF4E8',
    borderRadius: 10,
    padding: 10,
    marginTop: 4,
  },

  cutoffTitleRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 3,
  },

  cutoffTitle: {
    fontSize: 12,
    fontWeight: '700',
    color: '#8A4B13',
  },

  cutoffText: {
    fontSize: 11,
    color: '#8A4B13',
    lineHeight: 16,
  },

  slotInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginTop: 10,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#F0E3D8',
  },

  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
    marginRight: 6,
  },

  statusContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },

  statusText: {
    fontSize: 12,
    fontWeight: '600',
  },

  durationText: {
    fontSize: 12,
    color: '#777777',
    marginLeft: 12,
  },

  removeButton: {
    marginLeft: 'auto',
    paddingVertical: 6,
    paddingHorizontal: 10,
  },

  removeButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
  },

  removeButtonText: {
    fontSize: 12,
    fontWeight: '700',
    color: '#D93636',
  },

  addButton: {
    height: 48,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: '#FF7A00',
    borderStyle: 'dashed',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 2,
  },

  addButtonContent: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 7,
  },

  addButtonText: {
    fontSize: 14,
    fontWeight: '700',
    color: '#FF7A00',
  },

  saveButton: {
    height: 54,
    borderRadius: 14,
    backgroundColor: '#FF7A00',
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 4,
    elevation: 3,
    shadowOpacity: 0.2,
    shadowRadius: 5,
    shadowOffset: {
      width: 0,
      height: 3,
    },
  },

  disabledButton: {
    opacity: 0.65,
  },

  saveButtonText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#FFFFFF',
  },

  bottomNote: {
    fontSize: 11,
    color: '#999999',
    textAlign: 'center',
    marginTop: 14,
    lineHeight: 17,
  },
});

export default DeliverySlotsScreen;
