import React from "react";
import {
    StyleSheet,
    Text,
    TouchableOpacity,
    View,
} from "react-native";


// =====================================================
// TYPES
// =====================================================

interface OwnerHeaderProps {
    restaurantName?: string;
    notificationCount?: number;
    onNotificationPress?: () => void;
}


// =====================================================
// COMPONENT
// =====================================================

const OwnerHeader: React.FC<OwnerHeaderProps> = ({
    restaurantName = "Your Restaurant",
    notificationCount = 0,
    onNotificationPress,
}) => {

    return (
        <View style={styles.container}>

            {/* =========================================
                GREETING
            ========================================= */}

            <View style={styles.leftSection}>

                <Text style={styles.greeting}>
                    Welcome back 👋
                </Text>

                <Text
                    style={styles.restaurantName}
                    numberOfLines={1}
                >
                    {restaurantName}
                </Text>

            </View>


            {/* =========================================
                NOTIFICATION
            ========================================= */}

            <TouchableOpacity
                activeOpacity={0.75}
                onPress={onNotificationPress}
                style={styles.notificationButton}
            >

                <Text style={styles.notificationIcon}>
                    🔔
                </Text>


                {notificationCount > 0 && (
                    <View style={styles.badge}>

                        <Text style={styles.badgeText}>
                            {notificationCount > 9
                                ? "9+"
                                : notificationCount}
                        </Text>

                    </View>
                )}

            </TouchableOpacity>

        </View>
    );
};


// =====================================================
// STYLES
// =====================================================

const styles = StyleSheet.create({

    container: {
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 22,
    },


    // ================================================
    // LEFT
    // ================================================

    leftSection: {
        flex: 1,
        marginRight: 15,
    },

    greeting: {
        fontSize: 13,
        color: "#8A8A93",
        marginBottom: 5,
    },

    restaurantName: {
        fontSize: 25,
        fontWeight: "800",
        color: "#17171B",
    },


    // ================================================
    // NOTIFICATION
    // ================================================

    notificationButton: {
        width: 48,
        height: 48,
        borderRadius: 16,
        backgroundColor: "#FFFFFF",
        alignItems: "center",
        justifyContent: "center",
        position: "relative",
    },

    notificationIcon: {
        fontSize: 21,
    },

    badge: {
        position: "absolute",
        top: 6,
        right: 6,
        minWidth: 17,
        height: 17,
        paddingHorizontal: 4,
        borderRadius: 10,
        backgroundColor: "#FF7A00",
        alignItems: "center",
        justifyContent: "center",
    },

    badgeText: {
        color: "#FFFFFF",
        fontSize: 9,
        fontWeight: "800",
    },

});


export default OwnerHeader;
