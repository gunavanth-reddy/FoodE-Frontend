import React, {useEffect, useState} from 'react';
import {Alert, SafeAreaView, View} from 'react-native';

import {
  AppButton,
  AppInput,
  AppText,
} from '../../../components';

import {
  verifyEmailOTP,
  verifyPhoneOTP,
  resendEmailOTP,
  resendPhoneOTP,
} from '../../../api/auth';

const OTPVerificationScreen = ({
  navigation,
  route,
}: any) => {
  const {
    type,
    identifier,
    developmentOTP,
  } = route.params;

  const [otp, setOtp] = useState('');
  const [countdown, setCountdown] = useState(60);
  const [loading, setLoading] = useState(false);

  // =========================
  // Countdown
  // =========================

  useEffect(() => {
    if (countdown <= 0) {
      return;
    }

    const timer = setInterval(() => {
      setCountdown(prev => prev - 1);
    }, 1000);

    return () => clearInterval(timer);
  }, [countdown]);

  // =========================
  // Verify OTP
  // =========================

  const handleVerify = async () => {
    if (otp.length !== 6) {
      Alert.alert(
        'Invalid OTP',
        'Please enter the 6-digit OTP.',
      );
      return;
    }

    try {
      setLoading(true);

      let response;

      if (type === 'email') {
        response = await verifyEmailOTP(
          identifier,
          otp,
        );
      } else {
        response = await verifyPhoneOTP(
          identifier,
          otp,
        );
      }

      if (!response.success) {
        Alert.alert(
          'Verification Failed',
          response.message ||
            'Invalid OTP.',
        );
        return;
      }

      Alert.alert(
        'Verified Successfully 🎉',
        type === 'email'
          ? 'Your email has been verified.'
          : 'Your phone number has been verified.',
        [
          {
            text: 'Continue',
            onPress: () =>
              navigation.replace('Login'),
          },
        ],
      );

    } catch (error: any) {
      console.log(
        'OTP Verification Error:',
        error.response?.data || error,
      );

      Alert.alert(
        'Verification Failed',
        error.response?.data?.message ||
          'Unable to verify OTP.',
      );
    } finally {
      setLoading(false);
    }
  };

  // =========================
  // Resend OTP
  // =========================

  const handleResend = async () => {
    try {
      setLoading(true);

      let response;

      if (type === 'email') {
        response = await resendEmailOTP(
          identifier,
        );
      } else {
        response = await resendPhoneOTP(
          identifier,
        );
      }

      if (!response.success) {
        Alert.alert(
          'Resend Failed',
          response.message ||
            'Unable to resend OTP.',
        );
        return;
      }

      setOtp('');
      setCountdown(60);

      Alert.alert(
        'OTP Sent',
        'A new OTP has been generated.',
      );

      // Temporary development testing
      if (response.developmentOTP) {
        console.log(
          'New FoodE Development OTP:',
          response.developmentOTP,
        );
      }

    } catch (error: any) {
      console.log(
        'Resend OTP Error:',
        error.response?.data || error,
      );

      Alert.alert(
        'Resend Failed',
        error.response?.data?.message ||
          'Unable to resend OTP.',
      );
    } finally {
      setLoading(false);
    }
  };

  return (
    <SafeAreaView style={{flex: 1}}>

      <View
        style={{
          flex: 1,
          padding: 24,
          justifyContent: 'center',
        }}>

        {/* =========================
            Title
        ========================= */}

        <AppText
          style={{
            fontSize: 28,
            fontWeight: '700',
            textAlign: 'center',
            marginBottom: 12,
          }}>

          Verify Your Account

        </AppText>

        {/* =========================
            Description
        ========================= */}

        <AppText
          style={{
            textAlign: 'center',
            marginBottom: 8,
          }}>

          We sent a 6-digit OTP to

        </AppText>

        <AppText
          style={{
            textAlign: 'center',
            fontWeight: '700',
            marginBottom: 30,
          }}>

          {identifier}

        </AppText>

        {/* =========================
            Development OTP
        ========================= */}

        {developmentOTP && (
          <AppText
            style={{
              textAlign: 'center',
              marginBottom: 20,
              fontWeight: '600',
            }}>

            Development OTP: {developmentOTP}

          </AppText>
        )}

        {/* =========================
            OTP Input
        ========================= */}

        <AppInput
          label="OTP"
          placeholder="Enter 6-digit OTP"
          value={otp}
          onChangeText={value =>
            setOtp(
              value
                .replace(/[^0-9]/g, '')
                .slice(0, 6),
            )
          }
          keyboardType="number-pad"
          leftIcon="keypad-outline"
        />

        {/* =========================
            Verify
        ========================= */}

        <AppButton
          title={
            loading
              ? 'Verifying...'
              : 'Verify OTP'
          }
          onPress={handleVerify}
          disabled={loading}
        />

        {/* =========================
            Resend
        ========================= */}

        <View
          style={{
            alignItems: 'center',
            marginTop: 20,
          }}>

          {countdown > 0 ? (

            <AppText>
              Resend OTP in {countdown}s
            </AppText>

          ) : (

            <AppText
              onPress={handleResend}
              style={{
                fontWeight: '700',
              }}>

              Resend OTP

            </AppText>

          )}

        </View>

      </View>

    </SafeAreaView>
  );
};

export default OTPVerificationScreen;
