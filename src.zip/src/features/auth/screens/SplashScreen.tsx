import React, {useEffect} from 'react';

import {
  View,
  Text,
  StyleSheet,
  Image,
  ActivityIndicator,
  StatusBar,
} from 'react-native';

import Colors from '../../../constants/colors';
import Strings from '../../../constants/strings';

import {useAuth} from '../../../context/AuthContext';

// =====================================================
// SPLASH SCREEN
// =====================================================

const SplashScreen = ({
  navigation,
}: any) => {

  const {
    user,
    token,
    loading,
  } = useAuth();

  // ===================================================
  // AUTH ROUTING
  // ===================================================

  useEffect(() => {

    // Wait until AuthContext
    // finishes loading AsyncStorage.
    if (loading) {
      return;
    }

    const timer =
      setTimeout(() => {

        // =============================================
        // NOT LOGGED IN
        // =============================================

        if (!user || !token) {

          navigation.replace(
            'Login',
          );

          return;
        }

        // =============================================
        // RESTAURANT OWNER
        // =============================================

        if (
          user.role ===
          'restaurant_owner'
        ) {

          navigation.replace(
            'RestaurantOwner',
          );

          return;
        }

        // =============================================
        // NORMAL USER
        // =============================================

        navigation.replace(
          'Main',
        );

      }, 2000);

    return () => {
      clearTimeout(timer);
    };

  }, [
    loading,
    user,
    token,
    navigation,
  ]);

  // ===================================================
  // UI
  // ===================================================

  return (
    <View
      style={
        styles.container
      }>

      {/* =============================================
          STATUS BAR
      ============================================= */}

      <StatusBar
        barStyle="dark-content"
        backgroundColor={
          Colors.white
        }
        translucent={false}
      />

      {/* =============================================
          LOGO
      ============================================= */}

      <Image
        source={require(
          '../../../assets/images/logo.png',
        )}
        style={
          styles.logo
        }
      />

      {/* =============================================
          APP NAME
      ============================================= */}

      <Text
        style={
          styles.title
        }>
        {Strings.appName}
      </Text>

      {/* =============================================
          TAGLINE
      ============================================= */}

      <Text
        style={
          styles.tagline
        }>
        {Strings.tagline}
      </Text>

      {/* =============================================
          LOADING
      ============================================= */}

      <ActivityIndicator
        size="large"
        color={
          Colors.primary
        }
        style={
          styles.loader
        }
      />

    </View>
  );
};

// =====================================================
// STYLES
// =====================================================

const styles =
  StyleSheet.create({

    container: {
      flex: 1,
      backgroundColor:
        Colors.white,
      justifyContent:
        'center',
      alignItems:
        'center',
      padding: 20,
    },

    logo: {
      width: 130,
      height: 130,
      resizeMode:
        'contain',
      marginBottom: 20,
    },

    title: {
      fontSize: 36,
      fontWeight:
        'bold',
      color:
        Colors.primary,
    },

    tagline: {
      marginTop: 8,
      fontSize: 16,
      color:
        Colors.textSecondary,
    },

    loader: {
      marginTop: 40,
    },

  });

export default SplashScreen;
