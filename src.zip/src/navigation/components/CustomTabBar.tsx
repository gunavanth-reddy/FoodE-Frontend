import React from 'react';
import {Alert, View} from 'react-native';
import {BottomTabBarProps} from '@react-navigation/bottom-tabs';
import {useSafeAreaInsets} from 'react-native-safe-area-context';

import {useAuth} from '../../context/AuthContext';

import TabButton from './TabButton';
import styles from './TabBar.styles';

const CustomTabBar: React.FC<BottomTabBarProps> = ({
  state,
  navigation,
}) => {
  const {isLoggedIn} = useAuth();
  const insets = useSafeAreaInsets();

  const tabs = [
    {
      name: 'Home',
      active: 'home',
      inactive: 'home-outline',
    },
    {
      name: 'Search',
      active: 'search',
      inactive: 'search-outline',
    },
    {
      name: 'Favorites',
      active: 'heart',
      inactive: 'heart-outline',
    },
    {
      name: 'Orders',
      active: 'receipt',
      inactive: 'receipt-outline',
    },
    {
      name: 'Profile',
      active: 'person',
      inactive: 'person-outline',
    },
  ] as const;

  const protectedTabs = [
    'Favorites',
    'Orders',
    'Profile',
  ];

  const handleTabPress = (
    tabName: string,
    index: number,
  ) => {
    // -----------------------------------------------
    // LOGIN PROTECTION
    // -----------------------------------------------

    const isProtected = protectedTabs.includes(tabName);

    if (isProtected && !isLoggedIn) {
      Alert.alert(
        'Login Required',
        'Please login to continue.',
        [
          {
            text: 'Cancel',
            style: 'cancel',
          },
          {
            text: 'Login',
            onPress: () => {
              navigation
                .getParent()
                ?.navigate('Login' as never);
            },
          },
        ],
      );

      return;
    }

    // -----------------------------------------------
    // TAB PRESS EVENT
    // -----------------------------------------------

    const event = navigation.emit({
      type: 'tabPress',
      target: state.routes[index].key,
      canPreventDefault: true,
    });

    if (event.defaultPrevented) {
      return;
    }

    // -----------------------------------------------
    // NAVIGATE TO TAB
    // -----------------------------------------------

    navigation.navigate(state.routes[index].name);
  };

  return (
    <View
      style={[
        styles.container,
        {
          paddingBottom: Math.max(insets.bottom, 6),
        },
      ]}>
      {tabs.map((tab, index) => {
        const focused = state.index === index;

        return (
          <TabButton
            key={tab.name}
            label={tab.name}
            icon={focused ? tab.active : tab.inactive}
            focused={focused}
            onPress={() =>
              handleTabPress(tab.name, index)
            }
          />
        );
      })}
    </View>
  );
};

export default CustomTabBar;