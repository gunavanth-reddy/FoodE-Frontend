import React from 'react';
import {Pressable, Text} from 'react-native';

import {
  House,
  MagnifyingGlass,
  Heart,
  Receipt,
  UserCircle,
  Icon,
} from 'phosphor-react-native';

import styles from './TabBar.styles';

type Props = {
  label: string;
  icon: string;
  focused: boolean;
  onPress: () => void;
};

const getTabIcon = (icon: string): Icon => {
  switch (icon) {
    case 'home':
    case 'home-outline':
      return House;

    case 'search':
    case 'search-outline':
      return MagnifyingGlass;

    case 'heart':
    case 'heart-outline':
      return Heart;

    case 'receipt':
    case 'receipt-outline':
      return Receipt;

    case 'person':
    case 'person-outline':
      return UserCircle;

    default:
      return House;
  }
};

const TabButton: React.FC<Props> = ({
  label,
  icon,
  focused,
  onPress,
}) => {
  const IconComponent = getTabIcon(icon);

  return (
    <Pressable
      onPress={onPress}
      style={({pressed}) => [
        styles.tabButton,
        focused ? styles.activeTab : styles.inactiveTab,
        pressed && {opacity: 0.8},
      ]}>

      <IconComponent
        size={22}
        color={focused ? '#FFFFFF' : '#8E8E93'}
        weight={focused ? 'fill' : 'regular'}
      />

      {focused && (
        <Text style={styles.label}>
          {label}
        </Text>
      )}

    </Pressable>
  );
};

export default TabButton;