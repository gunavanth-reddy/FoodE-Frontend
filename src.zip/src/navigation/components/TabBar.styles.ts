import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  container: {
    position: 'absolute',

    left: 18,
    right: 18,
    bottom: 18,

    minHeight: 72,

    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-around',

    paddingHorizontal: 10,
    paddingVertical: 10,

    backgroundColor: '#FFFFFF',

    borderRadius: 36,

    borderWidth: 1,
    borderColor: '#EEEEEE',

    elevation: 12,

    shadowColor: '#000',
    shadowOffset: {
      width: 0,
      height: 6,
    },
    shadowOpacity: 0.08,
    shadowRadius: 10,
  },

  tabButton: {
    height: 48,

    minWidth: 48,

    paddingHorizontal: 14,

    borderRadius: 24,

    justifyContent: 'center',
    alignItems: 'center',

    flexDirection: 'row',
  },

  activeTab: {
    backgroundColor: '#FF7A00',
  },

  inactiveTab: {
    backgroundColor: 'transparent',
  },

  label: {
    marginLeft: 8,

    fontSize: 14,

    fontWeight: '700',

    color: '#FFFFFF',
  },
});

export default styles;
