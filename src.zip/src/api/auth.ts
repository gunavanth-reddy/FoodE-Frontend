import api from './api';

// =========================
// Register
// =========================

export interface RegisterData {
  name: string;
  email?: string;
  phone?: string;
  password: string;
}

export interface RegisterResponse {
  success: boolean;
  message: string;

  user: {
    id: string;
    name: string;
    email?: string;
    phone?: string;
    role: string;
    isEmailVerified: boolean;
    isPhoneVerified: boolean;
  };

  developmentOTP?: string;
}


// =========================
// Login
// =========================

export interface LoginData {
  email?: string;
  phone?: string;
  password: string;
}

export interface LoginResponse {
  success: boolean;
  message: string;
  token: string;

  user: {
    id: string;
    name: string;
    email?: string;
    phone?: string;
    role: string;
    isEmailVerified: boolean;
    isPhoneVerified: boolean;
  };
}


// =========================
// Register User
// =========================

export const registerUser = async (
  user: RegisterData,
): Promise<RegisterResponse> => {
  const response = await api.post(
    '/auth/register',
    user,
  );

  return response.data;
};


// =========================
// Login User
// =========================

export const loginUser = async (
  data: LoginData,
): Promise<LoginResponse> => {
  const response = await api.post(
    '/auth/login',
    data,
  );

  return response.data;
};


// =========================
// Verify Email OTP
// =========================

export const verifyEmailOTP = async (
  email: string,
  otp: string,
) => {
  const response = await api.post(
    '/auth/verify-email',
    {
      email,
      otp,
    },
  );

  return response.data;
};


// =========================
// Verify Phone OTP
// =========================

export const verifyPhoneOTP = async (
  phone: string,
  otp: string,
) => {
  const response = await api.post(
    '/auth/verify-phone',
    {
      phone,
      otp,
    },
  );

  return response.data;
};


// =========================
// Resend Email OTP
// =========================

export const resendEmailOTP = async (
  email: string,
) => {
  const response = await api.post(
    '/auth/resend-email-otp',
    {
      email,
    },
  );

  return response.data;
};


// =========================
// Resend Phone OTP
// =========================

export const resendPhoneOTP = async (
  phone: string,
) => {
  const response = await api.post(
    '/auth/resend-phone-otp',
    {
      phone,
    },
  );

  return response.data;
};


// =========================
// Get Profile
// =========================

export const getProfile = async (
  token: string,
) => {
  const response = await api.get(
    '/auth/profile',
    {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    },
  );

  return response.data;
};
