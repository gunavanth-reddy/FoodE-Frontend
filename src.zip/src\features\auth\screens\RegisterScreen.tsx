
import React, {useState} from 'react';
import {
  View,
  Alert,
  TouchableOpacity,
  KeyboardAvoidingView,
  Platform,
  ScrollView,
  StatusBar,
  StyleSheet,
} from 'react-native';

import {
  registerUser,
  verifySRMAPStudent,
} from '../../../api/auth';
import {ArrowLeft} from 'phosphor-react-native';

import {
  AppInput,
  AppButton,
  AppText,
} from '../../../components';

const ORANGE = '#FF5A00';
const GREEN = '#16803D';

const RegisterScreen = ({navigation}: any) => {
  // SRM AP ERP verification
  const [erpUsername, setErpUsername] = useState('');
  const [erpPassword, setErpPassword] = useState('');
  const [isVerified, setIsVerified] = useState(false);
  const [verificationToken, setVerificationToken] = useState('');
  const [isVerifying, setIsVerifying] = useState(false);
  const [verificationError, setVerificationError] = useState('');

  // FoodE account details
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [password, setPassword] = useState('');

  const [nameError, setNameError] = useState('');
  const [phoneError, setPhoneError] = useState('');
  const [passwordError, setPasswordError] = useState('');
  const [isRegistering, setIsRegistering] = useState(false);

  const getErrorMessage = (
    error: any,
    fallback: string,
  ): string => {
    const message = error?.response?.data?.message || error?.message;
    return typeof message === 'string' && message.trim()
      ? message
      : fallback;
  };

  // ==========================================
  // VERIFY SRM AP STUDENT
  // ==========================================
  const handleVerifyStudent = async () => {
    if (isVerifying || isVerified) {
      return;
    }

    if (!erpUsername.trim() || !erpPassword) {
      setVerificationError(
        'Enter your SRM AP registration number and ERP password.',
      );
      return;
    }

    setIsVerifying(true);
    setVerificationError('');
    setIsVerified(false);
    setVerificationToken('');

    try {
      const response = await verifySRMAPStudent({
        username: erpUsername.trim(),
        password: erpPassword,
      });

      if (
        response?.success !== true ||
        !response?.verificationToken
      ) {
        setVerificationError(
          response?.message || 'Student verification failed.',
        );
        return;
      }

      setVerificationToken(response.verificationToken);
      setIsVerified(true);

      // Do not retain the ERP password after verification.
      setErpPassword('');

      Alert.alert(
        'Student Verified',
        'Your SRM AP student identity has been verified.',
      );
    } catch (error: any) {
      setVerificationError(
        getErrorMessage(
          error,
          'Unable to verify your student identity. Please try again.',
        ),
      );
    } finally {
      setIsVerifying(false);
    }
  };

  // ==========================================
  // REGISTER FOOD E ACCOUNT
  // ==========================================
  const handleRegister = async () => {
    if (!isVerified || !verificationToken) {
      Alert.alert(
        'Verification Required',
        'Verify your SRM AP student identity before creating your account.',
      );
      return;
    }

    if (isRegistering || isVerifying) {
      return;
    }

    const trimmedName = name.trim();
    const trimmedPhone = phone.trim();

    setNameError('');
    setPhoneError('');
    setPasswordError('');

    if (trimmedName.length < 2) {
      setNameError('Name must be at least 2 characters.');
      return;
    }

    if (!/^\d{10}$/.test(trimmedPhone)) {
      setPhoneError('Enter a valid 10-digit mobile number.');
      return;
    }

    if (password.length < 8) {
      setPasswordError(
        'Password must contain at least 8 characters.',
      );
      return;
    }

    setIsRegistering(true);

    try {
      const response = await registerUser({
        name: trimmedName,
        phone: trimmedPhone,
        password,
        verificationToken,
      });

      if (response?.success !== true) {
        Alert.alert(
          'Registration Failed',
          response?.message || 'Unable to create your account.',
        );
        return;
      }

      // Clear the verification token and sensitive form values.
      setIsVerified(false);
      setVerificationToken('');
      setErpPassword('');
      setPassword('');

      Alert.alert(
        'Account Created',
        'Your FoodE account has been created. You can now log in using your mobile number and password.',
        [
          {
            text: 'OK',
            onPress: () => navigation.replace('Login'),
          },
        ],
      );
    } catch (error: any) {
      Alert.alert(
        'Registration Failed',
        getErrorMessage(
          error,
          'Unable to connect to the FoodE server.',
        ),
      );
    } finally {
      setIsRegistering(false);
    }
  };

  // Changing the username invalidates the current verification.
  const handleERPUsernameChange = (text: string) => {
    if (isVerified || isVerifying) {
      return;
    }

    setErpUsername(text);
    setVerificationError('');
  };

  const handleERPPasswordChange = (text: string) => {
    if (isVerified || isVerifying) {
      return;
    }

    setErpPassword(text);
    setVerificationError('');
  };

  return (
    <View style={styles.screen}>
      <StatusBar hidden={true} />

      <KeyboardAvoidingView
        style={styles.keyboardContainer}
        behavior={Platform.OS === 'ios' ? 'padding' : 'height'}>

        {navigation.canGoBack() && (
          <TouchableOpacity
            onPress={() => navigation.goBack()}
            style={{
              position: 'absolute',
              top: 16,
              left: 16,
              zIndex: 10,
              width: 40,
              height: 40,
              borderRadius: 20,
              backgroundColor: 'rgba(255, 255, 255, 0.25)',
              justifyContent: 'center',
              alignItems: 'center',
            }}
            activeOpacity={0.7}>
            <ArrowLeft size={22} color="#FFFFFF" weight="bold" />
          </TouchableOpacity>
        )}

        <ScrollView
          showsVerticalScrollIndicator={false}
          keyboardShouldPersistTaps="handled"
          bounces={false}
          overScrollMode="never"
          contentContainerStyle={styles.scrollContent}>

          {/* HERO */}
          <View style={styles.hero}>
            <View style={styles.heroCircleLarge} />
            <View style={styles.heroCircleSmall} />
            <View style={styles.heroDot} />
            <View style={styles.heroLine} />

            <View style={styles.brand}>
              <AppText style={styles.brandText}>FoodE</AppText>
              <View style={styles.brandLine} />
              <AppText style={styles.brandTagline}>
                FOOD. FAST. FRESH.
              </AppText>
            </View>
          </View>

          {/* REGISTER CARD */}
          <View style={styles.registerCard}>
            <View style={styles.handle} />

            <View style={styles.header}>
              <AppText style={styles.title}>
                Create Account
              </AppText>
              <AppText style={styles.subtitle}>
                Verify your SRM AP student identity to join FoodE.
              </AppText>
            </View>

            {/* STEP 1: ERP VERIFICATION */}
            <View style={styles.sectionHeader}>
              <AppText style={styles.sectionTitle}>
                1. SRM AP Student Verification
              </AppText>
              <AppText style={styles.sectionSubtitle}>
                Use your college ERP credentials.
              </AppText>
            </View>

            <View style={styles.field}>
              <AppInput
                label="ERP Username / Registration Number"
                placeholder="Enter your ERP username"
                value={erpUsername}
                onChangeText={handleERPUsernameChange}
                autoCapitalize="none"
                editable={!isVerified && !isVerifying}
              />
            </View>

            <View style={styles.field}>
              <AppInput
                label="ERP Password"
                placeholder="Enter your ERP password"
                value={erpPassword}
                onChangeText={handleERPPasswordChange}
                secureTextEntry
                autoCapitalize="none"
                editable={!isVerified && !isVerifying}
              />
            </View>

            <View
              pointerEvents={
                isVerifying || isVerified ? 'none' : 'auto'
              }
              style={
                isVerifying || isVerified
                  ? styles.disabledButton
                  : undefined
              }>
              <AppButton
                title={
                  isVerifying
                    ? 'Verifying Student...'
                    : 'Verify SRM AP Student'
                }
                onPress={handleVerifyStudent}
              />
            </View>

            {isVerified && (
              <View style={styles.verifiedBox}>
                <AppText style={styles.verifiedTitle}>
                  ✓ Verified SRM AP Student
                </AppText>
                <AppText style={styles.verifiedSubtitle}>
                  You can now create your FoodE account.
                </AppText>
              </View>
            )}

            {!!verificationError && (
              <AppText style={styles.errorText}>
                {verificationError}
              </AppText>
            )}

            {/* STEP 2: FOOD E ACCOUNT */}
            <View style={styles.sectionHeader}>
              <AppText style={styles.sectionTitle}>
                2. FoodE Account Details
              </AppText>
              <AppText style={styles.sectionSubtitle}>
                {isVerified
                  ? 'Complete your account details.'
                  : 'Complete verification to unlock these fields.'}
              </AppText>
            </View>

            <View
              pointerEvents={isVerified ? 'auto' : 'none'}
              style={
                !isVerified ? styles.disabledFields : undefined
              }>

              {/* NAME */}
              <View style={styles.field}>
                <AppInput
                  label="Full Name"
                  placeholder="Enter your full name"
                  value={name}
                  editable={isVerified}
                  onChangeText={text => {
                    setName(text);
                    setNameError('');
                  }}
                  leftIcon="person-outline"
                  autoCapitalize="words"
                />

                {!!nameError && (
                  <AppText style={styles.errorText}>
                    {nameError}
                  </AppText>
                )}
              </View>

              {/* MOBILE NUMBER */}
              <View style={styles.field}>
                <AppInput
                  label="Mobile Number"
                  placeholder="Enter your 10-digit mobile number"
                  value={phone}
                  editable={isVerified}
                  onChangeText={text => {
                    setPhone(text.replace(/\D/g, '').slice(0, 10));
                    setPhoneError('');
                  }}
                  leftIcon="call-outline"
                  keyboardType="phone-pad"
                  autoCapitalize="none"
                />

                {!!phoneError && (
                  <AppText style={styles.errorText}>
                    {phoneError}
                  </AppText>
                )}
              </View>

              {/* FOOD E PASSWORD */}
              <View style={styles.field}>
                <AppInput
                  label="FoodE Password"
                  placeholder="Create a password (minimum 8 characters)"
                  value={password}
                  editable={isVerified}
                  onChangeText={text => {
                    setPassword(text);
                    setPasswordError('');
                  }}
                  leftIcon="lock-closed-outline"
                  secureTextEntry
                  autoCapitalize="none"
                />

                {!!passwordError && (
                  <AppText style={styles.errorText}>
                    {passwordError}
                  </AppText>
                )}
              </View>
            </View>

            {/* CREATE ACCOUNT */}
            <View
              pointerEvents={
                isVerified && !isRegistering ? 'auto' : 'none'
              }
              style={
                !isVerified || isRegistering
                  ? styles.disabledButton
                  : undefined
              }>
              <AppButton
                title={
                  isRegistering
                    ? 'Creating Account...'
                    : 'Create Account'
                }
                onPress={handleRegister}
              />
            </View>

            {/* LOGIN */}
            <TouchableOpacity
              activeOpacity={0.7}
              style={styles.loginButton}
              onPress={() => navigation.navigate('Login')}>
              <AppText style={styles.loginText}>
                Already have an account?{' '}
                <AppText style={styles.loginHighlight}>
                  Sign In
                </AppText>
              </AppText>
            </TouchableOpacity>

            <AppText style={styles.version}>
              Version 1.0.0
            </AppText>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </View>
  );
};

export default RegisterScreen;

// ==========================================
// STYLES
// ==========================================
const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: '#FFFFFF',
  },

  keyboardContainer: {
    flex: 1,
  },

  scrollContent: {
    flexGrow: 1,
    paddingBottom: 28,
  },

  hero: {
    minHeight: 190,
    backgroundColor: ORANGE,
    overflow: 'hidden',
    alignItems: 'center',
    justifyContent: 'center',
    position: 'relative',
  },

  brand: {
    alignItems: 'center',
    justifyContent: 'center',
    marginTop: 8,
  },

  brandText: {
    color: '#FFFFFF',
    fontSize: 56,
    fontWeight: '900',
    letterSpacing: -2.5,
  },

  brandLine: {
    width: 42,
    height: 4,
    borderRadius: 4,
    backgroundColor: '#FFFFFF',
    marginTop: 4,
  },

  brandTagline: {
    color: '#FFFFFF',
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 3,
    marginTop: 10,
  },

  heroCircleLarge: {
    position: 'absolute',
    width: 210,
    height: 210,
    borderRadius: 105,
    backgroundColor: 'rgba(255,255,255,0.08)',
    top: -100,
    right: -65,
  },

  heroCircleSmall: {
    position: 'absolute',
    width: 120,
    height: 120,
    borderRadius: 60,
    backgroundColor: 'rgba(255,255,255,0.09)',
    bottom: -55,
    left: -30,
  },

  heroDot: {
    position: 'absolute',
    width: 9,
    height: 9,
    borderRadius: 5,
    backgroundColor: 'rgba(255,255,255,0.7)',
    top: 35,
    left: '18%',
  },

  heroLine: {
    position: 'absolute',
    width: 42,
    height: 3,
    borderRadius: 2,
    backgroundColor: 'rgba(255,255,255,0.35)',
    top: 55,
    right: '17%',
    transform: [{rotate: '-35deg'}],
  },

  registerCard: {
    backgroundColor: '#FFFFFF',
    borderTopLeftRadius: 28,
    borderTopRightRadius: 28,
    marginTop: -22,
    paddingHorizontal: 22,
    paddingTop: 12,
    paddingBottom: 28,
    minHeight: 500,
  },

  handle: {
    alignSelf: 'center',
    width: 42,
    height: 5,
    borderRadius: 3,
    backgroundColor: '#E5E7EB',
    marginBottom: 24,
  },

  header: {
    marginBottom: 26,
  },

  title: {
    color: '#171717',
    fontSize: 28,
    fontWeight: '900',
    letterSpacing: -0.6,
  },

  subtitle: {
    color: '#737373',
    fontSize: 13,
    lineHeight: 20,
    marginTop: 7,
  },

  sectionHeader: {
    marginBottom: 14,
    marginTop: 4,
  },

  sectionTitle: {
    color: '#262626',
    fontSize: 15,
    fontWeight: '800',
  },

  sectionSubtitle: {
    color: '#737373',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 4,
  },

  field: {
    marginBottom: 15,
  },

  verifiedBox: {
    borderRadius: 14,
    borderWidth: 1,
    borderColor: '#BBF7D0',
    backgroundColor: '#F0FDF4',
    paddingVertical: 13,
    paddingHorizontal: 14,
    marginTop: 13,
    marginBottom: 24,
  },

  verifiedTitle: {
    color: GREEN,
    fontSize: 14,
    fontWeight: '800',
  },

  verifiedSubtitle: {
    color: '#166534',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 5,
  },

  errorText: {
    color: '#DC2626',
    fontSize: 12,
    lineHeight: 18,
    marginTop: 5,
    marginBottom: 8,
  },

  disabledFields: {
    opacity: 0.45,
  },

  disabledButton: {
    opacity: 0.5,
  },

  loginButton: {
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
  },

  loginText: {
    color: '#737373',
    fontSize: 13,
  },

  loginHighlight: {
    color: ORANGE,
    fontWeight: '800',
  },

  version: {
    color: '#A3A3A3',
    fontSize: 11,
    textAlign: 'center',
    marginTop: 4,
  },
});
