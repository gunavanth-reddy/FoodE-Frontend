import React from 'react';
import {
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
  useWindowDimensions,
} from 'react-native';
import {ArrowLeft} from 'phosphor-react-native';
import {useNavigation} from '@react-navigation/native';

interface ScreenHeaderProps {
  title: string;
  subtitle?: string;
  rightAction?: React.ReactNode;
  showBack?: boolean;
  onBackPress?: () => void;
  icon?: React.ReactNode;
  backgroundColor?: string;
  titleColor?: string;
}

const ORANGE = '#FF6B00';

const ScreenHeader: React.FC<ScreenHeaderProps> = ({
  title,
  subtitle,
  rightAction,
  showBack = true,
  onBackPress,
  icon,
  backgroundColor = '#F7F8FA',
  titleColor = '#1A1D26',
}) => {
  const navigation = useNavigation<any>();
  const {width} = useWindowDimensions();
  const isCompact = width < 360;

  const handleBack = () => {
    if (onBackPress) {
      onBackPress();
    } else if (navigation.canGoBack()) {
      navigation.goBack();
    }
  };

  const canGoBack = showBack && (Boolean(onBackPress) || navigation.canGoBack());

  return (
    <View style={[styles.headerContainer, {backgroundColor}]}>
      <View style={styles.topRow}>
        {canGoBack && (
          <TouchableOpacity
            accessibilityRole="button"
            accessibilityLabel="Go back"
            activeOpacity={0.75}
            onPress={handleBack}
            style={styles.backButton}>
            <ArrowLeft size={isCompact ? 20 : 22} color="#1E232C" weight="bold" />
          </TouchableOpacity>
        )}

        {icon && !canGoBack && (
          <View style={styles.iconContainer}>{icon}</View>
        )}

        <View style={styles.titleContainer}>
          <Text
            style={[
              styles.title,
              {
                color: titleColor,
                fontSize: isCompact ? 20 : 23,
              },
            ]}
            numberOfLines={1}>
            {title}
          </Text>

          {Boolean(subtitle) && (
            <Text style={styles.subtitle} numberOfLines={1}>
              {subtitle}
            </Text>
          )}
        </View>

        {rightAction ? (
          <View style={styles.rightAction}>{rightAction}</View>
        ) : canGoBack ? (
          <View style={styles.spacer} />
        ) : null}
      </View>
    </View>
  );
};

export default ScreenHeader;

const styles = StyleSheet.create({
  headerContainer: {
    width: '100%',
    paddingHorizontal: 16,
    paddingTop: 12,
    paddingBottom: 10,
    zIndex: 10,
  },
  topRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    minHeight: 44,
  },
  backButton: {
    width: 42,
    height: 42,
    borderRadius: 21,
    backgroundColor: '#FFFFFF',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
    shadowColor: '#000',
    shadowOffset: {width: 0, height: 2},
    shadowOpacity: 0.06,
    shadowRadius: 5,
    elevation: 3,
  },
  iconContainer: {
    width: 42,
    height: 42,
    borderRadius: 14,
    backgroundColor: '#FFF2E6',
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  titleContainer: {
    flex: 1,
    justifyContent: 'center',
  },
  title: {
    fontWeight: '800',
    letterSpacing: -0.3,
  },
  subtitle: {
    fontSize: 12,
    fontWeight: '500',
    color: '#717886',
    marginTop: 2,
  },
  rightAction: {
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: 8,
  },
  spacer: {
    width: 42,
  },
});
